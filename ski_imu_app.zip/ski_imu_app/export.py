"""
export.py

Eksport sesji:
  * CSV z surowymi próbkami -- ten sam format wczytuje csv_import.py (można go odtworzyć w aplikacji),
  * CSV ze skrętami,
  * raport PDF (podsumowanie, wskaźniki, wykres sygnałów ze skrętami, tabela skrętów).

Ścieżki plików podaje wywołujący; moduł nie zależy od GUI.
"""

from __future__ import annotations

import csv
import io
import os

RAW_HEADER = ["t_s", "ax_ms2", "ay_ms2", "az_ms2", "gx_dps", "gy_dps", "gz_dps"]
TURN_HEADER = ["turn", "direction", "start_s", "end_s", "duration_s", "score",
               "max_lateral_accel_ms2", "max_edge_angle_deg"]

DIRECTION_PL = {"left": "lewo", "right": "prawo"}


def _fmt(value, dialect):
    if isinstance(value, float):
        text = f"{value:.4f}".rstrip("0").rstrip(".")   # stała precyzja: czas rzędu godzin nie traci dokładności
        text = "0" if text in ("", "-0") else text
    else:
        text = str(value)
    return text.replace(".", ",") if dialect == "excel_pl" else text


def _writer(f, dialect):
    # excel_pl: średnik + przecinek dziesiętny (tak otwiera się poprawnie w polskim Excelu)
    return csv.writer(f, delimiter=";" if dialect == "excel_pl" else ",", lineterminator="\n")


def export_raw_csv(path: str, rows, dialect: str = "standard") -> int:
    """rows: (t, ax, ay, az, gx, gy, gz) w SI. Zwraca liczbę zapisanych wierszy."""
    n = 0
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = _writer(f, dialect)
        w.writerow(RAW_HEADER)
        for r in rows:
            w.writerow([_fmt(round(float(v), 4), dialect) for v in r])
            n += 1
    return n


def export_turns_csv(path: str, turns, dialect: str = "standard") -> int:
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = _writer(f, dialect)
        w.writerow(TURN_HEADER)
        for tu in turns:
            w.writerow([
                tu.index + 1, tu.direction, _fmt(round(tu.start_t, 3), dialect), _fmt(round(tu.end_t, 3), dialect),
                _fmt(round(tu.end_t - tu.start_t, 3), dialect), _fmt(round(tu.score, 1), dialect),
                _fmt(round(tu.max_lateral_accel, 3), dialect), _fmt(round(tu.max_edge_angle, 1), dialect),
            ])
    return len(turns)


# -------------------------------------------------------------------- #
# PDF
# -------------------------------------------------------------------- #
_FONTS_READY = False


def _register_fonts():
    """DejaVu Sans jest w pakiecie matplotlib, więc polskie znaki działają na każdym systemie."""
    global _FONTS_READY
    if _FONTS_READY:
        return
    import matplotlib
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    d = os.path.join(matplotlib.get_data_path(), "fonts", "ttf")
    pdfmetrics.registerFont(TTFont("DejaVu", os.path.join(d, "DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont("DejaVu-Bold", os.path.join(d, "DejaVuSans-Bold.ttf")))
    pdfmetrics.registerFontFamily("DejaVu", normal="DejaVu", bold="DejaVu-Bold")
    _FONTS_READY = True


def _signal_figure_png(t, ax, gz, turns, max_points=4000) -> bytes:
    """Wykres przyspieszenia bocznego i prędkości kątowej z zaznaczonymi skrętami (jasny, do druku)."""
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg

    step = max(1, len(t) // max_points)
    ts, axs, gzs = t[::step], ax[::step], gz[::step]
    fig = Figure(figsize=(7.2, 3.8), dpi=150)
    FigureCanvasAgg(fig)
    top, bottom = fig.subplots(2, 1, sharex=True)
    top.plot(ts, axs, color="#0b7fb8", linewidth=0.9)
    bottom.plot(ts, gzs, color="#6d4fc7", linewidth=0.9)
    for tu in turns:
        color = "#2e9e6b" if tu.direction == "right" else "#e08a1e"
        for a in (top, bottom):
            a.axvspan(tu.start_t, tu.end_t, color=color, alpha=0.12, linewidth=0)
    top.set_ylabel("Przysp. boczne [m/s²]", fontsize=8)
    bottom.set_ylabel("Prędk. kątowa [°/s]", fontsize=8)
    bottom.set_xlabel("Czas [s]", fontsize=8)
    for a in (top, bottom):
        a.grid(True, alpha=0.3)
        a.tick_params(labelsize=7)
    fig.suptitle("Sygnały i wykryte skręty (zielone = prawo, pomarańczowe = lewo)", fontsize=9)
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    return buf.getvalue()


def export_report_pdf(path: str, loaded: dict, user_name: str = "") -> None:
    """
    loaded: wynik session_service.load_session(). Zgłasza ValueError dla sesji bez danych.
    """
    if not loaded or not loaded.get("analysis"):
        raise ValueError("Ta sesja nie ma zapisanych danych z czujnika.")
    _register_fonts()

    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether,
    )

    s, a, turns = loaded["session"], loaded["analysis"], loaded["turns"]

    h1 = ParagraphStyle("h1", fontName="DejaVu-Bold", fontSize=18, leading=22, spaceAfter=2)
    h2 = ParagraphStyle("h2", fontName="DejaVu-Bold", fontSize=12, leading=15, spaceBefore=10, spaceAfter=4)
    body = ParagraphStyle("body", fontName="DejaVu", fontSize=9, leading=12)
    muted = ParagraphStyle("muted", parent=body, textColor=colors.HexColor("#5b6773"))
    note = ParagraphStyle("note", parent=body, backColor=colors.HexColor("#f2f5f8"), borderPadding=6, leading=13)

    def esc(text):
        return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br/>")

    m, sec = divmod(int(a["duration_s"]), 60)
    story = [
        Paragraph(f"SkiSense — raport zjazdu #{s['id']}", h1),
        Paragraph(esc(f"{s['date'].replace('T', ' ')} · czas {m:02d}:{sec:02d} · {a['turn_count']} skrętów"
                      + (f" · {user_name}" if user_name else "")), muted),
        Spacer(1, 6),
    ]
    if s.get("notes"):
        story += [Paragraph(f"<b>Notatka:</b> {esc(s['notes'])}", note), Spacer(1, 4)]

    ssi_tbl = Table([[Paragraph(f"<font size=30><b>{a['ssi']}</b></font>", body),
                      Paragraph(f"<b>SkiSense Index</b><br/>Styl: <b>{esc(a['style_label'])}</b><br/>"
                                f"<font color='#5b6773'>Skala ok. 70–160, przeciętny rekreacyjny narciarz ok. 100.</font>",
                                body)]],
                    colWidths=[35 * mm, 135 * mm])
    ssi_tbl.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                 ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#c8d0d8")),
                                 ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8)]))
    story += [ssi_tbl, Paragraph("Kategorie umiejętności", h2)]

    def grid(rows, widths):
        t = Table(rows, colWidths=widths)
        t.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), "DejaVu"), ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#d5dbe1")),
            ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
            ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
        return t

    story.append(grid([
        ["Balans (stabilność)", f"{a['balance_pct']:.0f} / 100"],
        ["Kontrola krawędzi", f"{a['edge_pct']:.0f} / 100"],
        ["Kształt skrętu (płynność)", f"{a['turn_shape_pct']:.0f} / 100"],
        ["Rytm", f"{a['rhythm_pct']:.0f} / 100"],
    ], [110 * mm, 60 * mm]))

    story.append(Paragraph("Wskaźniki techniczne", h2))
    story.append(grid([
        ["Kadencja", f"{a['cadence_per_min']:.1f} skrętów/min"],
        ["Średnia ocena skrętu", f"{a['avg_score']:.1f} / 100"],
        ["Skręty w lewo / w prawo", f"{a['left_count']} / {a['right_count']}"],
        ["Symetria lewo–prawo", f"{a['symmetry']:.0f} / 100"],
        ["Średni kąt krawędziowania", f"{a['avg_edge_angle']:.1f}°"],
        ["Pozycja przód/tył (pitch)", f"{a['pitch_deg'] + 0.0:.1f}°"],
        ["Intensywność", f"{a['intensity']:.0f} / 100"],
        ["Poziom drgań", f"{a['vibration']:.0f} / 100"],
    ], [110 * mm, 60 * mm]))

    png = _signal_figure_png(loaded["t"], loaded["ax"], loaded["gz"], turns)
    story += [Paragraph("Sygnały", h2), Image(io.BytesIO(png), width=170 * mm, height=170 * mm * 3.8 / 7.2)]

    if turns:
        rows = [["#", "Kierunek", "Start [s]", "Czas [s]", "Ocena", "Maks. przysp. [m/s²]", "Kąt krawędzi [°]"]]
        for tu in turns:
            rows.append([str(tu.index + 1), DIRECTION_PL.get(tu.direction, tu.direction), f"{tu.start_t:.1f}",
                         f"{tu.end_t - tu.start_t:.2f}", f"{tu.score:.0f}", f"{tu.max_lateral_accel:.2f}",
                         f"{tu.max_edge_angle:.1f}"])
        tbl = Table(rows, repeatRows=1, colWidths=[10 * mm, 24 * mm, 22 * mm, 22 * mm, 20 * mm, 40 * mm, 32 * mm])
        tbl.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), "DejaVu"), ("FONTNAME", (0, 0), (-1, 0), "DejaVu-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8), ("ALIGN", (2, 0), (-1, -1), "RIGHT"),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8edf2")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f7f9fb")]),
            ("LINEBELOW", (0, 0), (-1, -1), 0.25, colors.HexColor("#d5dbe1")),
            ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
        story += [Paragraph("Skręty", h2), tbl]

    story += [Spacer(1, 10), Paragraph(
        "Oceny i SkiSense Index to wskaźniki heurystyczne, wyliczane regułami z danych czujnika IMU na bucie. "
        "Służą do porównywania własnych zjazdów między sobą; nie są pomiarem naukowym.", muted)]

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("DejaVu", 7.5)
        canvas.setFillColor(colors.HexColor("#7a8794"))
        canvas.drawString(20 * mm, 10 * mm, f"SkiSense · zjazd #{s['id']}")
        canvas.drawRightString(190 * mm, 10 * mm, f"Strona {doc.page}")
        canvas.restoreState()

    doc = SimpleDocTemplate(path, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm,
                            topMargin=16 * mm, bottomMargin=18 * mm,
                            title=f"SkiSense — zjazd #{s['id']}", author=user_name or "SkiSense")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
