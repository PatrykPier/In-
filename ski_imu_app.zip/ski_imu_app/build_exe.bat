@echo off
REM Buduje folder dist\SkiSense\ z programem SkiSense.exe (wymaga Pythona 3.10+ w PATH).
REM Uruchom z folderu projektu:  build_exe.bat
setlocal
cd /d "%~dp0"

echo === 1/4 Srodowisko wirtualne ===
if not exist .venv\Scripts\python.exe (
    python -m venv .venv || goto :error
)
call .venv\Scripts\activate.bat || goto :error

echo === 2/4 Instalacja bibliotek ===
python -m pip install --upgrade pip || goto :error
python -m pip install -r requirements.txt pyinstaller || goto :error

echo === 3/4 Testy ===
set QT_QPA_PLATFORM=offscreen
python -m unittest discover -s tests || goto :error
set QT_QPA_PLATFORM=

echo === 4/4 Budowanie ===
pyinstaller --noconfirm --clean skisense.spec || goto :error

echo === Test dymny zbudowanego programu ===
REM SkiSense.exe jest aplikacja okienkowa: "start /wait" czeka na jej koniec i zwraca kod wyjscia.
start "" /wait dist\SkiSense\SkiSense.exe --smoke-test
if errorlevel 1 goto :error

echo.
echo GOTOWE: dist\SkiSense\SkiSense.exe
echo Dane programu (baza, kalibracja) zapisuja sie w %%APPDATA%%\SkiSense
echo Caly folder dist\SkiSense mozna spakowac do ZIP i przekazac dalej.
exit /b 0

:error
echo.
echo BLAD: budowanie nie powiodlo sie (patrz komunikaty wyzej).
exit /b 1
