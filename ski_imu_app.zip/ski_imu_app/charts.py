"""
charts.py
Wykresy matplotlib osadzone w Qt, w ciemnym motywie spójnym z resztą
aplikacji: podgląd na żywo, wykres sesji ze skrętami, histogram ocen,
wykres radarowy stylu jazdy, trend ocen między sesjami.
"""

import math
import matplotlib
import numpy as np
import pyqtgraph as pg
from PyQt5.QtCore import QTimer
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

C_BG = "#121820"
C_GRID = "#1f2733"
C_TEXT = "#c7cdd6"
C_MUTED = "#8b96a5"
C_CYAN = "#38bdf8"
C_GREEN = "#34d399"
C_AMBER = "#fbbf24"
C_RED = "#f87171"
C_VIOLET = "#a78bfa"

pg.setConfigOptions(antialias=True, foreground=C_MUTED)

matplotlib.rcParams.update({
    "figure.facecolor": C_BG,
    "axes.facecolor": C_BG,
    "axes.edgecolor": C_GRID,
    "axes.labelcolor": C_TEXT,
    "xtick.color": C_MUTED,
    "ytick.color": C_MUTED,
    "text.color": C_TEXT,
    "grid.color": C_GRID,
    "font.size": 9,
})


class LiveChart(pg.GraphicsLayoutWidget):
    """
    Wykres na żywo (pyqtgraph): przyspieszenie boczne + prędkość kątowa.

    Próbki trafiają do bufora (add_sample), a rysowanie odbywa się co ~33 ms
    (30 FPS) niezależnie od tempa próbek -- dzięki temu 50-100 Hz z czujnika
    nie przeciąża GUI.
    """

    WINDOW_S = 8.0      # tyle sekund widać na wykresie
    CAPACITY = 1000     # maks. liczba próbek w buforze (do 100 Hz)
    REFRESH_MS = 33

    def __init__(self):
        super().__init__()
        self.setBackground(C_BG)
        self.setMinimumHeight(260)

        self._t = np.zeros(self.CAPACITY)
        self._a = np.zeros(self.CAPACITY)
        self._g = np.zeros(self.CAPACITY)
        self._n = 0
        self._dirty = False

        self.p_accel = self._make_plot(0, "Przyspieszenie boczne (oś X)", "m/s²")
        self.p_gyro = self._make_plot(1, "Prędkość kątowa (oś Z)", "°/s", with_x_label=True)
        self.curve_accel = self.p_accel.plot(pen=pg.mkPen(C_CYAN, width=2))
        self.curve_gyro = self.p_gyro.plot(pen=pg.mkPen(C_VIOLET, width=2))

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh)
        self._timer.start(self.REFRESH_MS)

    def _make_plot(self, row, title, unit, with_x_label=False):
        plot = self.addPlot(row=row, col=0)
        plot.setTitle(title, color=C_TEXT, size="10pt")
        plot.setLabel("left", unit)
        if with_x_label:
            plot.setLabel("bottom", "Czas [s]")
        plot.showGrid(x=True, y=True, alpha=0.25)
        plot.setMouseEnabled(x=False, y=False)
        plot.hideButtons()
        plot.enableAutoRange(axis="y", enable=True)
        return plot

    def add_sample(self, t, accel, gyro):
        if self._n < self.CAPACITY:
            i = self._n
            self._n += 1
        else:  # bufor pełny: przesuwamy o jedną próbkę
            self._t[:-1] = self._t[1:]
            self._a[:-1] = self._a[1:]
            self._g[:-1] = self._g[1:]
            i = self.CAPACITY - 1
        self._t[i], self._a[i], self._g[i] = t, accel, gyro
        self._dirty = True

    def reset(self):
        """Czyści bufor próbek. (Nie nazywać clear(): to nazwa metody pyqtgraph, nadpisanie psuje rysowanie.)"""
        self._n = 0
        self._dirty = True

    def _refresh(self):
        if not self._dirty:
            return
        self._dirty = False
        n = self._n
        if n == 0:
            self.curve_accel.setData([], [])
            self.curve_gyro.setData([], [])
            return
        t = self._t[:n]
        t_last = t[-1]
        first = np.searchsorted(t, t_last - self.WINDOW_S)
        t_win = t[first:]
        self.curve_accel.setData(t_win, self._a[:n][first:])
        self.curve_gyro.setData(t_win, self._g[:n][first:])
        x_min = max(t_win[0], t_last - self.WINDOW_S)
        for plot in (self.p_accel, self.p_gyro):
            plot.setXRange(x_min, x_min + self.WINDOW_S, padding=0)


class ResultChart(FigureCanvas):
    """Wykres przyspieszenia bocznego całej sesji z zaznaczonymi skrętami."""

    def __init__(self):
        self.fig = Figure(figsize=(6, 3.2), tight_layout=True)
        super().__init__(self.fig)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_xlabel("Czas [s]")
        self.ax.set_ylabel("Przyspieszenie boczne [m/s²]")
        self.ax.grid(True, alpha=0.3)

    def plot_session(self, t_vals, accel_vals, turns):
        self.ax.clear()
        self.ax.plot(t_vals, accel_vals, color=C_CYAN, linewidth=1)
        colors = {"left": C_GREEN, "right": C_AMBER}
        for tu in turns:
            self.ax.axvspan(tu.start_t, tu.end_t, color=colors.get(tu.direction, "gray"), alpha=0.15)
        self.ax.set_xlabel("Czas [s]")
        self.ax.set_ylabel("Przyspieszenie boczne [m/s²]")
        self.ax.grid(True, alpha=0.3)
        self.draw_idle()


class HistogramChart(FigureCanvas):
    """Rozkład ocen skrętów w sesji."""

    def __init__(self):
        self.fig = Figure(figsize=(5, 3), tight_layout=True)
        super().__init__(self.fig)
        self.ax = self.fig.add_subplot(111)

    def plot(self, scores):
        self.ax.clear()
        self.ax.set_xlabel("Ocena skrętu (0-100)")
        self.ax.set_ylabel("Liczba skrętów")
        self.ax.grid(True, alpha=0.3, axis="y")
        if scores:
            self.ax.hist(scores, bins=10, range=(0, 100), color=C_CYAN, edgecolor=C_BG)
        self.draw_idle()


class RadarChart(FigureCanvas):
    """Profil stylu jazdy: płynność / rytm / symetria / stabilność."""

    def __init__(self):
        self.fig = Figure(figsize=(4, 4), tight_layout=True)
        super().__init__(self.fig)
        self.ax = self.fig.add_subplot(111, polar=True)
        self.fig.patch.set_facecolor(C_BG)

    def plot(self, labels, values):
        n = len(labels)
        angles = [i / n * 2 * math.pi for i in range(n)]
        angles += angles[:1]
        vals = list(values) + values[:1]

        self.ax.clear()
        self.ax.set_facecolor(C_BG)
        self.ax.set_theta_offset(math.pi / 2)
        self.ax.set_theta_direction(-1)
        self.ax.set_ylim(0, 100)
        self.ax.set_yticks([25, 50, 75, 100])
        self.ax.set_yticklabels(["25", "50", "75", "100"], color=C_MUTED, fontsize=7)
        self.ax.plot(angles, vals, color=C_CYAN, linewidth=2)
        self.ax.fill(angles, vals, color=C_CYAN, alpha=0.25)
        self.ax.set_xticks(angles[:-1])
        self.ax.set_xticklabels(labels, color=C_TEXT, fontsize=9)
        self.ax.grid(True, alpha=0.3)
        self.draw_idle()


class TrendChart(FigureCanvas):
    """Trend średniej oceny w czasie, pomiędzy sesjami."""

    def __init__(self):
        self.fig = Figure(figsize=(6, 3), tight_layout=True)
        super().__init__(self.fig)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_ylabel("Śr. ocena sesji")
        self.ax.grid(True, alpha=0.3)

    def plot(self, labels, scores):
        self.ax.clear()
        self.ax.set_ylabel("SkiSense Index")
        self.ax.grid(True, alpha=0.3)
        if scores:
            x = list(range(len(scores)))
            self.ax.plot(x, scores, marker="o", color=C_GREEN, linewidth=2)
            self.ax.axhline(100, color=C_MUTED, linewidth=1, linestyle="--", alpha=0.5)
            self.ax.set_xticks(x)
            self.ax.set_xticklabels(labels, rotation=40, ha="right", fontsize=8)
            lo, hi = min(scores), max(scores)
            pad = max(5.0, (hi - lo) * 0.2)
            self.ax.set_ylim(lo - pad, hi + pad)
        self.draw_idle()


class CompareChart(FigureCanvas):
    """Porównanie dwóch sesji na czterech kategoriach umiejętności (słupki obok siebie)."""

    COLOR_A = "#38bdf8"
    COLOR_B = "#a78bfa"

    def __init__(self):
        self.fig = Figure(figsize=(6, 3), tight_layout=True)
        super().__init__(self.fig)
        self.ax = self.fig.add_subplot(111)
        self.fig.patch.set_facecolor(C_BG)
        self.setMinimumHeight(220)

    def plot(self, labels, values_a, values_b, name_a, name_b):
        ax = self.ax
        ax.clear()
        ax.set_facecolor(C_BG)
        x = np.arange(len(labels))
        w = 0.38
        ax.bar(x - w / 2, values_a, w, label=name_a, color=self.COLOR_A)
        ax.bar(x + w / 2, values_b, w, label=name_b, color=self.COLOR_B)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, color=C_TEXT, fontsize=9)
        ax.set_ylim(0, 118)
        ax.set_yticks([0, 20, 40, 60, 80, 100])
        ax.tick_params(axis="y", colors=C_MUTED, labelsize=8)
        ax.grid(True, axis="y", alpha=0.25)
        for spine in ax.spines.values():
            spine.set_color(C_GRID)
        ax.legend(facecolor=C_BG, edgecolor=C_GRID, labelcolor=C_TEXT, fontsize=8, loc="upper center", ncol=2)
        self.draw_idle()
