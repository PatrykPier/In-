"""
database.py
Warstwa bazy danych SQLite zgodna z diagramem ERD z planu pracy:
USER -> TRAINING_SESSION -> SENSOR_DATA
                         -> TURN_ANALYSIS
"""

import sqlite3
import os
import sys
from datetime import datetime



def app_data_dir() -> str:
    """
    Gdzie trzymać bazę i kalibrację. Z kodu źródłowego: obok programu (jak dotąd).
    Z wersji .exe (PyInstaller): %APPDATA%\\SkiSense, bo katalog programu jest tymczasowy
    albo tylko do odczytu i dane zniknęłyby po zamknięciu.
    """
    if getattr(sys, "frozen", False):
        base = os.environ.get("APPDATA") or os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
        path = os.path.join(base, "SkiSense")
        os.makedirs(path, exist_ok=True)
        return path
    return os.path.dirname(os.path.abspath(__file__))


DB_PATH = os.path.join(app_data_dir(), "ski_imu.db")


class Database:
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute("PRAGMA foreign_keys = ON")
        self._create_tables()

    # ------------------------------------------------------------------ #
    # Schema
    # ------------------------------------------------------------------ #
    def _create_tables(self):
        cur = self.conn.cursor()
        cur.executescript(
            """
            CREATE TABLE IF NOT EXISTS USER (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS TRAINING_SESSION (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                date TEXT NOT NULL,
                sensor_placement TEXT DEFAULT 'boot_shin',
                notes TEXT,
                duration_s REAL DEFAULT 0,
                turn_count INTEGER DEFAULT 0,
                overall_score REAL DEFAULT 0,
                style_label TEXT DEFAULT '',
                FOREIGN KEY (user_id) REFERENCES USER(id)
            );

            CREATE TABLE IF NOT EXISTS SENSOR_DATA (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                t REAL NOT NULL,
                accel_x REAL, accel_y REAL, accel_z REAL,
                gyro_x REAL, gyro_y REAL, gyro_z REAL,
                FOREIGN KEY (session_id) REFERENCES TRAINING_SESSION(id)
            );

            CREATE TABLE IF NOT EXISTS TURN_ANALYSIS (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                turn_index INTEGER,
                start_t REAL,
                end_t REAL,
                direction TEXT,
                score REAL,
                max_lateral_accel REAL,
                max_edge_angle REAL,
                FOREIGN KEY (session_id) REFERENCES TRAINING_SESSION(id)
            );

            CREATE INDEX IF NOT EXISTS idx_sensor_session ON SENSOR_DATA(session_id, t);
            CREATE INDEX IF NOT EXISTS idx_turn_session ON TURN_ANALYSIS(session_id, turn_index);
            """
        )
        # migracja starszych baz: dodajemy brakujące kolumny
        existing = {r[1] for r in cur.execute("PRAGMA table_info(TRAINING_SESSION)")}
        for col, ddl in (("notes", "TEXT"), ("duration_s", "REAL DEFAULT 0"), ("turn_count", "INTEGER DEFAULT 0"),
                         ("overall_score", "REAL DEFAULT 0"), ("style_label", "TEXT DEFAULT ''")):
            if col not in existing:
                cur.execute(f"ALTER TABLE TRAINING_SESSION ADD COLUMN {col} {ddl}")
        self.conn.commit()

    # ------------------------------------------------------------------ #
    # USER
    # ------------------------------------------------------------------ #
    def get_or_create_user(self, username: str) -> int:
        cur = self.conn.cursor()
        cur.execute("SELECT id FROM USER WHERE username = ?", (username,))
        row = cur.fetchone()
        if row:
            return row[0]
        cur.execute("INSERT INTO USER (username) VALUES (?)", (username,))
        self.conn.commit()
        return cur.lastrowid

    # ------------------------------------------------------------------ #
    # TRAINING_SESSION
    # ------------------------------------------------------------------ #
    def create_session(self, user_id: int, sensor_placement: str = "boot_shin") -> int:
        cur = self.conn.cursor()
        cur.execute(
            "INSERT INTO TRAINING_SESSION (user_id, date, sensor_placement) VALUES (?, ?, ?)",
            (user_id, datetime.now().isoformat(timespec="seconds"), sensor_placement),
        )
        self.conn.commit()
        return cur.lastrowid

    def list_sessions(self, user_id: int | None = None):
        cur = self.conn.cursor()
        cols = "id, date, sensor_placement, notes, duration_s, turn_count, overall_score, style_label"
        if user_id is not None:
            cur.execute(
                f"SELECT {cols} FROM TRAINING_SESSION WHERE user_id = ? ORDER BY id DESC",
                (user_id,),
            )
        else:
            cur.execute(f"SELECT {cols} FROM TRAINING_SESSION ORDER BY id DESC")
        return cur.fetchall()

    def update_session_summary(self, session_id: int, duration_s: float, turn_count: int,
                                overall_score: float, style_label: str):
        self.conn.execute(
            "UPDATE TRAINING_SESSION SET duration_s = ?, turn_count = ?, "
            "overall_score = ?, style_label = ? WHERE id = ?",
            (duration_s, turn_count, overall_score, style_label, session_id),
        )
        self.conn.commit()

    def get_session(self, session_id: int):
        """Słownik z danymi sesji albo None, gdy taka nie istnieje."""
        cur = self.conn.cursor()
        cur.execute(
            "SELECT id, user_id, date, sensor_placement, notes, duration_s, turn_count, "
            "overall_score, style_label FROM TRAINING_SESSION WHERE id = ?", (session_id,))
        r = cur.fetchone()
        if r is None:
            return None
        keys = ("id", "user_id", "date", "sensor_placement", "notes", "duration_s",
                "turn_count", "overall_score", "style_label")
        return dict(zip(keys, r))

    def update_notes(self, session_id: int, notes: str):
        self.conn.execute("UPDATE TRAINING_SESSION SET notes = ? WHERE id = ?",
                          (notes.strip() or None, session_id))
        self.conn.commit()

    def delete_session(self, session_id: int) -> bool:
        """Usuwa sesję razem z jej danymi z czujnika i skrętami (w jednej transakcji)."""
        with self.conn:
            self.conn.execute("DELETE FROM SENSOR_DATA WHERE session_id = ?", (session_id,))
            self.conn.execute("DELETE FROM TURN_ANALYSIS WHERE session_id = ?", (session_id,))
            cur = self.conn.execute("DELETE FROM TRAINING_SESSION WHERE id = ?", (session_id,))
        return cur.rowcount > 0

    # ------------------------------------------------------------------ #
    # SENSOR_DATA
    # ------------------------------------------------------------------ #
    def insert_sensor_batch(self, session_id: int, rows):
        """rows: iterable of tuples (t, ax, ay, az, gx, gy, gz)"""
        self.conn.executemany(
            "INSERT INTO SENSOR_DATA (session_id, t, accel_x, accel_y, accel_z, "
            "gyro_x, gyro_y, gyro_z) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [(session_id, *r) for r in rows],
        )
        self.conn.commit()

    def get_sensor_data(self, session_id: int):
        cur = self.conn.cursor()
        cur.execute(
            "SELECT t, accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z "
            "FROM SENSOR_DATA WHERE session_id = ? ORDER BY t",
            (session_id,),
        )
        return cur.fetchall()

    # ------------------------------------------------------------------ #
    # TURN_ANALYSIS
    # ------------------------------------------------------------------ #
    def insert_turns(self, session_id: int, turns):
        """turns: iterable of dicts with keys matching TURN_ANALYSIS columns"""
        self.conn.executemany(
            "INSERT INTO TURN_ANALYSIS (session_id, turn_index, start_t, end_t, "
            "direction, score, max_lateral_accel, max_edge_angle) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [
                (
                    session_id,
                    t["turn_index"],
                    t["start_t"],
                    t["end_t"],
                    t["direction"],
                    t["score"],
                    t["max_lateral_accel"],
                    t["max_edge_angle"],
                )
                for t in turns
            ],
        )
        self.conn.commit()

    def get_turns(self, session_id: int):
        cur = self.conn.cursor()
        cur.execute(
            "SELECT turn_index, start_t, end_t, direction, score, max_lateral_accel, "
            "max_edge_angle FROM TURN_ANALYSIS WHERE session_id = ? ORDER BY turn_index",
            (session_id,),
        )
        return cur.fetchall()

    def close(self):
        self.conn.close()
