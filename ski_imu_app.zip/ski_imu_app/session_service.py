"""
session_service.py

Wczytanie zapisanej sesji z bazy razem z pełną analizą. Używane przez zakładkę
Wyniki, eksport (CSV/PDF) i porównanie sesji, żeby wszędzie liczyć to samo.
"""

from __future__ import annotations

from data_analysis import Turn, full_session_analysis


def load_session(db, session_id: int):
    """
    Zwraca słownik: session (wiersz z bazy), data (surowe próbki), t, ax, ay, az, gx, gy, gz,
    turns (lista Turn), analysis (full_session_analysis). None, gdy sesja nie istnieje.
    Sesja bez próbek ma puste listy i analysis=None.
    """
    session = db.get_session(session_id)
    if session is None:
        return None
    data = db.get_sensor_data(session_id)
    cols = list(zip(*data)) if data else [[] for _ in range(7)]
    t, ax, ay, az, gx, gy, gz = (list(c) for c in cols)

    turns = [
        Turn(index=i, start_t=r[1], end_t=r[2], direction=r[3],
             score=r[4], max_lateral_accel=r[5], max_edge_angle=r[6])
        for i, r in enumerate(db.get_turns(session_id))
    ]
    analysis = full_session_analysis(t, ax, ay, az, gz, turns) if data else None
    return {"session": session, "data": data, "t": t, "ax": ax, "ay": ay, "az": az,
            "gx": gx, "gy": gy, "gz": gz, "turns": turns, "analysis": analysis}
