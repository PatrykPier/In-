"""
widgets.py
Niestandardowe widżety UI: karty, kafelki statystyk, kołowy wskaźnik
oceny (ScoreBadge), gauge kąta krawędziowania (SemiGauge), pasek
jakości (QualityBar). Wspólny ciemny motyw wizualny całej aplikacji.
"""

import math
from PyQt5.QtWidgets import QFrame, QVBoxLayout, QHBoxLayout, QLabel, QWidget, QProgressBar
from PyQt5.QtCore import Qt, QRectF
from PyQt5.QtGui import QPainter, QPen, QColor, QFont

# -- paleta kolorów współdzielona z main_window.py --
C_BG = "#0b0f14"
C_CARD = "#121820"
C_CARD_ALT = "#161d26"
C_BORDER = "#1f2733"
C_TEXT = "#e5e7eb"
C_MUTED = "#8b96a5"
C_CYAN = "#38bdf8"
C_GREEN = "#34d399"
C_AMBER = "#fbbf24"
C_RED = "#f87171"
C_VIOLET = "#a78bfa"


def score_color(pct_0_100: float) -> str:
    if pct_0_100 >= 70:
        return C_GREEN
    if pct_0_100 >= 45:
        return C_AMBER
    return C_RED


class Card(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        self.setStyleSheet(
            f"QFrame#Card {{ background:{C_CARD}; border:1px solid {C_BORDER}; "
            f"border-radius:14px; }}"
        )


class StatTile(Card):
    def __init__(self, label: str, value: str, value_color: str = C_TEXT, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(4)
        cap = QLabel(label.upper())
        cap.setStyleSheet(f"color:{C_MUTED}; font-size:10.5px; font-weight:700; letter-spacing:1px; border:none;")
        self.value_label = QLabel(value)
        self.value_label.setStyleSheet(f"color:{value_color}; font-size:22px; font-weight:800; border:none;")
        layout.addWidget(cap)
        layout.addWidget(self.value_label)

    def set_value(self, value: str, value_color: str = None):
        self.value_label.setText(value)
        if value_color:
            self.value_label.setStyleSheet(f"color:{value_color}; font-size:22px; font-weight:800; border:none;")


class ScoreBadge(QWidget):
    """
    Kołowy wskaźnik wyniku (np. SkiSense Index). Skala dowolna --
    poda­jesz wartość i wartość odniesienia dla pełnego pierścienia
    (nie jest to twardy limit, wynik tekstowy może ją przekroczyć).
    """

    def __init__(self, score: float = 0.0, ref_value: float = 160.0,
                 size: int = 64, decimals: int = 0, sublabel: str = "", parent=None):
        super().__init__(parent)
        self._score = score
        self._ref = ref_value
        self._decimals = decimals
        self._sublabel = sublabel
        self.setFixedSize(size, size)

    def set_score(self, score: float):
        self._score = score
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(self.rect()).adjusted(4, 4, -4, -4)

        pen_bg = QPen(QColor(C_BORDER), 5)
        pen_bg.setCapStyle(Qt.RoundCap)
        painter.setPen(pen_bg)
        painter.drawEllipse(rect)

        pct = max(0.0, min(1.0, self._score / self._ref)) if self._ref else 0.0
        color = QColor(score_color(pct * 100))
        pen_fg = QPen(color, 5)
        pen_fg.setCapStyle(Qt.RoundCap)
        painter.setPen(pen_fg)
        painter.drawArc(rect, 90 * 16, -int(360 * 16 * pct))

        painter.setPen(QColor(C_TEXT))
        f = QFont()
        f.setBold(True)
        f.setPointSize(max(9, int(self.height() / 4.5)))
        painter.setFont(f)
        text = f"{self._score:.{self._decimals}f}"
        if self._sublabel:
            painter.drawText(QRectF(self.rect()).adjusted(0, -6, 0, -6), Qt.AlignCenter, text)
            f2 = QFont(); f2.setPointSize(max(6, int(self.height() / 11)))
            painter.setFont(f2)
            painter.setPen(QColor(C_MUTED))
            painter.drawText(QRectF(self.rect()).adjusted(0, self.height() * 0.3, 0, 0),
                              Qt.AlignCenter, self._sublabel)
        else:
            painter.drawText(self.rect(), Qt.AlignCenter, text)


class SemiGauge(QWidget):
    """Półokrągły gauge, np. do kąta krawędziowania."""

    def __init__(self, value: float = 0.0, max_value: float = 40.0,
                 label: str = "", unit: str = "°", parent=None):
        super().__init__(parent)
        self.value = value
        self.max_value = max_value
        self.label = label
        self.unit = unit
        self.setMinimumHeight(120)

    def set_value(self, v: float):
        self.value = v
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        size = min(w - 20, (h - 10) * 2)
        rect = QRectF((w - size) / 2, 8, size, size)

        pen_bg = QPen(QColor(C_BORDER), 10)
        pen_bg.setCapStyle(Qt.RoundCap)
        painter.setPen(pen_bg)
        painter.drawArc(rect, 0, 180 * 16)

        pct = max(0.0, min(1.0, self.value / self.max_value if self.max_value else 0))
        pen_fg = QPen(QColor(C_CYAN), 10)
        pen_fg.setCapStyle(Qt.RoundCap)
        painter.setPen(pen_fg)
        painter.drawArc(rect, 180 * 16, -int(180 * 16 * pct))

        painter.setPen(QColor(C_TEXT))
        f = QFont(); f.setBold(True); f.setPointSize(15)
        painter.setFont(f)
        painter.drawText(QRectF(0, size * 0.32, w, 30), Qt.AlignCenter, f"{self.value:.1f}{self.unit}")

        f2 = QFont(); f2.setPointSize(9)
        painter.setFont(f2)
        painter.setPen(QColor(C_MUTED))
        painter.drawText(QRectF(0, size * 0.32 + 26, w, 20), Qt.AlignCenter, self.label)


class QualityBar(QWidget):
    """Wiersz: etykieta ... procent, pasek postępu poniżej. Jak w mockupie 'Jakość techniki'."""

    def __init__(self, label: str, value_pct: float = 0, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 6, 0, 6)
        layout.setSpacing(6)

        row = QHBoxLayout()
        self.label = QLabel(label)
        self.label.setStyleSheet(f"color:{C_TEXT}; font-size:13px; border:none;")
        self.value_label = QLabel(f"{value_pct:.0f}%")
        self.value_label.setStyleSheet(f"color:{C_MUTED}; font-size:12.5px; border:none;")
        row.addWidget(self.label)
        row.addStretch()
        row.addWidget(self.value_label)
        layout.addLayout(row)

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(int(value_pct))
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(8)
        layout.addWidget(self.bar)
        self._apply_color(value_pct)

    def set_value(self, value_pct: float):
        self.value_label.setText(f"{value_pct:.0f}%")
        self.bar.setValue(int(value_pct))
        self._apply_color(value_pct)

    def _apply_color(self, value_pct: float):
        color = score_color(value_pct)
        self.bar.setStyleSheet(
            f"QProgressBar {{ background:{C_BORDER}; border:none; border-radius:4px; }}"
            f"QProgressBar::chunk {{ background:{color}; border-radius:4px; }}"
        )


class PillBadge(QLabel):
    """Mały kolorowy znacznik, np. kierunek skrętu L/R albo status połączenia."""

    def __init__(self, text: str, color: str = C_CYAN, parent=None):
        super().__init__(text, parent)
        self.setAlignment(Qt.AlignCenter)
        self.setFixedSize(26, 26)
        self.setStyleSheet(
            f"background:{color}22; color:{color}; border-radius:13px; "
            f"font-weight:800; font-size:11px; border:none;"
        )
