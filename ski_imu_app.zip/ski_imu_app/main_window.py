"""
main_window.py

GUI aplikacji (PyQt5), stylizowane na ciemny, "aplikacyjny" wygląd
(karty, gradientowe przyciski, kołowe wskaźniki wyniku, gauge, radar).

Trzy główne zakładki:
  1. Trening    - status połączenia, timer, start/stop treningu, live wykres
  2. Historia   - statystyki zbiorcze + lista sesji z oceną
  3. Wyniki     - szczegółowa analiza sesji: Raport / Skręty / Sygnały / Trend
"""

import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QTabWidget, QListWidget, QListWidgetItem, QTableWidget,
    QTableWidgetItem, QSlider, QMessageBox, QFrame, QComboBox, QFileDialog, QDialog,
    QDialogButtonBox, QCheckBox, QMenu, QInputDialog, QAbstractItemView, QHeaderView,
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QColor

from database import Database
import os
from data_source import SimulatedDataSource, ESP32BLEDataSource, CsvDataSource
from csv_import import parse_csv_file, CsvFormatError
from signal_tools import (
    AxisMap, Calibration, calibrate_from_rest, load_calibration, save_calibration,
)
from data_analysis import moving_average, detect_turns, full_session_analysis, Turn
from charts import LiveChart, ResultChart, HistogramChart, RadarChart, TrendChart, CompareChart
from session_service import load_session
import export
from widgets import (
    Card, StatTile, ScoreBadge, SemiGauge, QualityBar, PillBadge,
    C_BG, C_CARD, C_BORDER, C_TEXT, C_MUTED, C_CYAN, C_GREEN, C_AMBER, C_RED,
    score_color,
)

C_VIOLET = "#a78bfa"

APP_QSS = f"""
QWidget {{ background-color: {C_BG}; color: {C_TEXT}; font-family: -apple-system, "Segoe UI", Arial; font-size: 13px; }}
QMainWindow {{ background-color: {C_BG}; }}

QTabWidget::pane {{ border: none; top: -1px; }}
QTabBar::tab {{
    background: {C_CARD}; color: {C_MUTED}; padding: 10px 20px;
    border-top-left-radius: 10px; border-top-right-radius: 10px; margin-right: 4px;
    font-weight: 600;
}}
QTabBar::tab:selected {{ background: #1b2430; color: {C_CYAN}; }}

QPushButton#Primary {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {C_CYAN}, stop:1 {C_GREEN});
    color: #06141c; border: none; border-radius: 12px; padding: 14px 20px; font-weight: 800; font-size: 14px;
}}
QPushButton#Primary:disabled {{ background: {C_BORDER}; color: #5b6572; }}
QPushButton#Primary:hover:!disabled {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #5cc9fb, stop:1 #4fe3a8); }}

QPushButton#Secondary {{
    background: {C_CARD}; color: {C_TEXT}; border: 1px solid {C_BORDER};
    border-radius: 10px; padding: 10px 16px; font-weight: 600;
}}
QPushButton#Secondary:hover {{ border-color: {C_CYAN}; color: {C_CYAN}; }}

QListWidget {{ background: transparent; border: none; }}
QListWidget::item {{ border: none; margin-bottom: 10px; }}
QListWidget::item:selected {{ background: transparent; }}

QTableWidget {{ background: {C_CARD}; border: 1px solid {C_BORDER}; border-radius: 10px; gridline-color: {C_BORDER}; }}
QHeaderView::section {{
    background: #161d26; color: {C_MUTED}; border: none; padding: 8px;
    font-size: 10.5px; font-weight: 700; text-transform: uppercase;
}}
QTableWidget::item {{ padding: 6px; }}

QComboBox {{
    background: {C_CARD}; color: {C_TEXT}; border: 1px solid {C_BORDER};
    border-radius: 10px; padding: 8px 12px; min-width: 190px;
}}
QComboBox QAbstractItemView {{
    background: {C_CARD}; color: {C_TEXT}; border: 1px solid {C_BORDER};
    selection-background-color: #1b2430;
}}
QComboBox:disabled {{ color: #5b6572; }}

QSlider::groove:horizontal {{ background: {C_BORDER}; height: 6px; border-radius: 3px; }}
QSlider::handle:horizontal {{ background: {C_CYAN}; width: 16px; margin: -6px 0; border-radius: 8px; }}
"""


# -------------------------------------------------------------------- #
# ZAKŁADKA: TRENING (Live)
# -------------------------------------------------------------------- #
class LiveTab(QWidget):
    """Zakładka Trening: wybór źródła danych, status połączenia, timer, nagrywanie, wykres na żywo."""

    SOURCES = [("Symulacja (bez sprzętu)", "sim"), ("ESP32 przez Bluetooth BLE", "ble"),
               ("Plik CSV (odtwarzanie)", "csv")]
    SOURCE_LABELS = {"sim": "Symulacja", "ble": "ESP32", "csv": "Plik CSV"}
    CALIBRATION_SECONDS = 3.0

    STATE_STYLE = {
        "scanning": (C_AMBER, "● Szukam urządzenia..."),
        "connecting": (C_AMBER, "● Łączę z urządzeniem..."),
        "streaming": (C_GREEN, "● Urządzenie połączone"),
        "disconnected": (C_AMBER, "● Połączenie utracone, ponawiam..."),
        "stopped": (C_RED, "● Rozłączono"),
    }

    def __init__(self, db: Database, user_id: int, on_session_saved, on_connection_changed=None,
                 ble_backend=None, profile_path=None, csv_path_provider=None):
        super().__init__()
        self.db = db
        self.profile_path = profile_path            # gdzie zapisać kalibrację (None = bez zapisu)
        self.calibration = load_calibration(profile_path)
        self._calib_buf = None                      # lista próbek podczas kalibracji
        self._csv_path_provider = csv_path_provider or self._ask_csv_path
        self.csv_speed = 1.0
        self.user_id = user_id
        self.on_session_saved = on_session_saved
        self.on_connection_changed = on_connection_changed
        self._ble_backend = ble_backend  # wstrzykiwany w testach (atrapa ESP32)

        self.source = None
        self.source_kind = "sim"
        self.active = False       # czy użytkownik uruchomił źródło danych
        self.streaming = False    # czy dane aktualnie płyną
        self.recording = False
        self._buf_t, self._buf_ax, self._buf_ay, self._buf_az = [], [], [], []
        self._buf_gx, self._buf_gy, self._buf_gz = [], [], []

        self._rec_timer = QTimer(self)
        self._rec_timer.timeout.connect(self._tick_timer)
        self._elapsed_s = 0

        self._build_ui()
        self._create_source("sim")

    # ---------------------------------------------------------------- #
    # UI
    # ---------------------------------------------------------------- #
    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(16)

        # -- karta połączenia --
        status_card = Card()
        sc = QVBoxLayout(status_card)
        sc.setContentsMargins(18, 14, 18, 14)
        sc.setSpacing(10)

        top_row = QHBoxLayout()
        left_box = QVBoxLayout()
        left_box.setSpacing(2)
        title = QLabel("SkiTracker · czujnik IMU")
        title.setStyleSheet(f"color:{C_MUTED}; font-size:12px; border:none;")
        self.status_label = QLabel("● Rozłączono")
        self.status_label.setStyleSheet(f"color:{C_RED}; font-weight:700; font-size:14px; border:none;")
        self.detail_label = QLabel("")
        self.detail_label.setStyleSheet(f"color:{C_MUTED}; font-size:11px; border:none;")
        left_box.addWidget(title)
        left_box.addWidget(self.status_label)
        left_box.addWidget(self.detail_label)
        top_row.addLayout(left_box, stretch=1)

        self.source_combo = QComboBox()
        for label, kind in self.SOURCES:
            self.source_combo.addItem(label, kind)
        self.source_combo.currentIndexChanged.connect(self._on_source_selected)
        top_row.addWidget(self.source_combo)

        self.connect_btn = QPushButton("Połącz")
        self.connect_btn.setObjectName("Secondary")
        self.connect_btn.clicked.connect(self._toggle_connection)
        top_row.addWidget(self.connect_btn)
        sc.addLayout(top_row)
        outer.addWidget(status_card)

        # -- suwak jakości techniki (tylko symulacja) --
        self.sim_card = Card()
        sim_layout = QVBoxLayout(self.sim_card)
        sim_layout.setContentsMargins(18, 14, 18, 14)
        sim_title = QLabel("SYMULACJA — STYL JAZDY")
        sim_title.setStyleSheet(f"color:{C_MUTED}; font-size:10.5px; font-weight:700; letter-spacing:1px; border:none;")
        sim_layout.addWidget(sim_title)
        self.roughness_slider = QSlider(Qt.Horizontal)
        self.roughness_slider.setRange(0, 100)
        self.roughness_slider.setValue(15)
        self.roughness_slider.valueChanged.connect(self._on_roughness)
        row = QHBoxLayout()
        l1 = QLabel("Gładko"); l1.setStyleSheet(f"color:{C_GREEN}; font-size:11px; border:none;")
        l2 = QLabel("Szarpane"); l2.setStyleSheet(f"color:{C_RED}; font-size:11px; border:none;")
        row.addWidget(l1); row.addWidget(self.roughness_slider); row.addWidget(l2)
        sim_layout.addLayout(row)
        outer.addWidget(self.sim_card)

        # -- karta pliku CSV (tylko odtwarzanie CSV) --
        self.csv_card = Card()
        csv_layout = QHBoxLayout(self.csv_card)
        csv_layout.setContentsMargins(18, 12, 18, 12)
        csv_title = QLabel("ODTWARZANIE — PRĘDKOŚĆ")
        csv_title.setStyleSheet(f"color:{C_MUTED}; font-size:10.5px; font-weight:700; letter-spacing:1px; border:none;")
        csv_layout.addWidget(csv_title)
        csv_layout.addStretch(1)
        self.speed_combo = QComboBox()
        for label, v in (("1×", 1.0), ("2×", 2.0), ("5×", 5.0), ("10×", 10.0)):
            self.speed_combo.addItem(label, v)
        self.speed_combo.currentIndexChanged.connect(self._on_speed)
        csv_layout.addWidget(self.speed_combo)
        outer.addWidget(self.csv_card)

        # -- karta kalibracji i osi --
        cal_card = Card()
        cal_layout = QHBoxLayout(cal_card)
        cal_layout.setContentsMargins(18, 12, 18, 12)
        self.calib_label = QLabel()
        self.calib_label.setStyleSheet(f"color:{C_MUTED}; font-size:12px; border:none;")
        self.calib_label.setWordWrap(True)
        cal_layout.addWidget(self.calib_label, stretch=1)
        self.axes_btn = QPushButton("Osie…")
        self.axes_btn.setObjectName("Secondary")
        self.axes_btn.clicked.connect(self._edit_axes)
        cal_layout.addWidget(self.axes_btn)
        self.calib_btn = QPushButton("Kalibruj (postój)")
        self.calib_btn.setObjectName("Secondary")
        self.calib_btn.clicked.connect(self._start_calibration)
        self.calib_btn.setEnabled(False)
        cal_layout.addWidget(self.calib_btn)
        outer.addWidget(cal_card)
        self._update_calib_label()

        # -- timer --
        timer_card = Card()
        timer_layout = QVBoxLayout(timer_card)
        timer_layout.setContentsMargins(20, 24, 20, 24)
        timer_layout.setAlignment(Qt.AlignCenter)
        self.timer_label = QLabel("00:00")
        f = QFont(); f.setPointSize(40); f.setBold(True)
        self.timer_label.setFont(f)
        self.timer_label.setStyleSheet(f"color:{C_TEXT}; border:none;")
        self.timer_label.setAlignment(Qt.AlignCenter)
        cap = QLabel("CZAS TRENINGU")
        cap.setStyleSheet(f"color:{C_MUTED}; font-size:10.5px; font-weight:700; letter-spacing:2px; border:none;")
        cap.setAlignment(Qt.AlignCenter)
        timer_layout.addWidget(self.timer_label)
        timer_layout.addWidget(cap)
        outer.addWidget(timer_card)

        # -- start / stop treningu --
        self.record_btn = QPushButton("Rozpocznij trening")
        self.record_btn.setObjectName("Primary")
        self.record_btn.clicked.connect(self._toggle_recording)
        self.record_btn.setEnabled(False)
        outer.addWidget(self.record_btn)

        # -- wykres na żywo --
        chart_card = Card()
        chart_layout = QVBoxLayout(chart_card)
        chart_layout.setContentsMargins(12, 12, 12, 12)
        self.chart = LiveChart()
        chart_layout.addWidget(self.chart)
        outer.addWidget(chart_card, stretch=1)

    # ---------------------------------------------------------------- #
    # Źródło danych
    # ---------------------------------------------------------------- #
    def _create_source(self, kind: str):
        if self.source is not None:
            self.source.stop()
            self.source.deleteLater()
        self.source_kind = kind
        if kind == "ble":
            self.source = ESP32BLEDataSource(backend=self._ble_backend)
        elif kind == "csv":
            self.source = CsvDataSource(speed=self.csv_speed)
        else:
            self.source = SimulatedDataSource()
        self.source.finished.connect(self._on_source_finished)
        self.source.sample_ready.connect(self._on_sample)
        self.source.state_changed.connect(self._on_state)
        self.source.status_message.connect(self._on_message)
        self.source.stats_changed.connect(self._on_stats)
        self.sim_card.setVisible(self.source.is_simulated)
        self.csv_card.setVisible(kind == "csv")
        self.detail_label.setText({
            "sim": "", "csv": "Wybierz plik CSV po kliknięciu „Połącz”.",
        }.get(kind, f"Szukam urządzenia „{getattr(self.source, 'device_name', '')}”"))

    def _on_source_selected(self, _index):
        if self.recording:  # nie przełączamy źródła w trakcie nagrywania
            self.source_combo.blockSignals(True)
            self.source_combo.setCurrentIndex(self.source_combo.findData(self.source_kind))
            self.source_combo.blockSignals(False)
            return
        self._set_active(False)
        self._create_source(self.source_combo.currentData())

    def _on_roughness(self, value):
        if isinstance(self.source, SimulatedDataSource):
            self.source.set_roughness(value / 100.0)

    def _toggle_connection(self):
        if self.active:
            if self.recording:
                self._toggle_recording()
            self._set_active(False)
            self.source.stop()
        else:
            if self.source_kind == "csv" and not self._load_csv_into_source():
                return
            self._set_active(True)
            self.chart.reset()
            self.source.start()

    # ---------------------------------------------------------------- #
    # Plik CSV
    # ---------------------------------------------------------------- #
    def _ask_csv_path(self) -> str:
        path, _ = QFileDialog.getOpenFileName(
            self, "Wybierz nagranie CSV", "", "Pliki CSV/tekstowe (*.csv *.txt *.log);;Wszystkie pliki (*)")
        return path

    def _load_csv_into_source(self) -> bool:
        path = self._csv_path_provider()
        if not path:
            return False
        try:
            samples = parse_csv_file(path)
        except (CsvFormatError, OSError) as exc:
            QMessageBox.warning(self, "Nie można wczytać pliku", str(exc))
            return False
        self.source.load(samples)
        self.source.speed = self.csv_speed
        return True

    def _on_speed(self, _i):
        self.csv_speed = self.speed_combo.currentData()
        if isinstance(self.source, CsvDataSource):
            self.source.speed = self.csv_speed

    def _on_source_finished(self):
        """Źródło samo skończyło dane (koniec pliku): zapisujemy trening i rozłączamy."""
        if self.active:
            self._toggle_connection()

    # ---------------------------------------------------------------- #
    # Kalibracja i osie
    # ---------------------------------------------------------------- #
    def _update_calib_label(self):
        am = self.calibration.axis_map
        parts = []
        parts.append("Osie: domyślne" if am.is_identity() else "Osie: zmapowane")
        parts.append("kalibracja: wykonana" if self.calibration.calibrated else "kalibracja: brak")
        self.calib_label.setText(" · ".join(parts))

    def _persist_calibration(self):
        if self.profile_path:
            try:
                save_calibration(self.calibration, self.profile_path)
            except OSError:
                pass

    def _start_calibration(self):
        if not self.streaming or self.recording or self.source_kind == "sim":
            return
        self._calib_buf = []
        self.calib_btn.setEnabled(False)
        self.calib_label.setText(f"Kalibracja… trzymaj nartę nieruchomo przez {self.CALIBRATION_SECONDS:.0f} s")

    def _finish_calibration(self):
        samples, self._calib_buf = self._calib_buf, None
        try:
            self.calibration = calibrate_from_rest(samples, self.calibration.axis_map)
        except ValueError as exc:
            QMessageBox.warning(self, "Kalibracja nieudana", str(exc))
        else:
            self._persist_calibration()
        self._update_calib_label()
        self.calib_btn.setEnabled(self.streaming and self.source_kind != "sim")

    def _edit_axes(self):
        if self.recording:
            return
        dlg = AxisMapDialog(self.calibration.axis_map, self)
        if dlg.exec_() == QDialog.Accepted:
            self.calibration = self.calibration.with_axis_map(dlg.axis_map())
            self._persist_calibration()
            self._update_calib_label()

    def _set_active(self, active: bool):
        self.active = active
        self.connect_btn.setText("Rozłącz" if active else "Połącz")
        self.source_combo.setEnabled(not active)
        if not active:
            if self._calib_buf is not None:   # przerwana kalibracja
                self._calib_buf = None
                self._update_calib_label()
            self._apply_state("stopped")

    # ---------------------------------------------------------------- #
    # Stan połączenia
    # ---------------------------------------------------------------- #
    def _on_state(self, state: str):
        if not self.active and state != "stopped":
            return  # spóźniony sygnał po rozłączeniu
        self._apply_state(state)

    def _apply_state(self, state: str):
        color, text = self.STATE_STYLE.get(state, (C_MUTED, state))
        self.status_label.setText(text)
        self.status_label.setStyleSheet(f"color:{color}; font-weight:700; font-size:14px; border:none;")
        self.streaming = state == "streaming"
        # przycisk nagrywania: aktywny, gdy dane płyną, albo gdy trwa nagrywanie (żeby dało się je zakończyć)
        self.record_btn.setEnabled(self.streaming or self.recording)
        if self.on_connection_changed:
            self.on_connection_changed(self.streaming, self.SOURCE_LABELS.get(self.source_kind, "ESP32"))
        self.calib_btn.setEnabled(self.streaming and self.source_kind != "sim"
                                   and self._calib_buf is None and not self.recording)

    def _on_message(self, message: str):
        self.detail_label.setText(message)

    def _on_stats(self, received: int, lost: int):
        extra = f" · zgubione pakiety: {lost}" if lost else ""
        self.detail_label.setText(f"Odebrane pakiety: {received}{extra}")

    # ---------------------------------------------------------------- #
    # Nagrywanie
    # ---------------------------------------------------------------- #
    def _toggle_recording(self):
        self.recording = not self.recording
        if self.recording:
            self._buf_t.clear(); self._buf_ax.clear(); self._buf_ay.clear(); self._buf_az.clear()
            self._buf_gx.clear(); self._buf_gy.clear(); self._buf_gz.clear()
            self._elapsed_s = 0
            self.timer_label.setText("00:00")
            self._rec_timer.start(1000)
            self.record_btn.setText("Zakończ i zapisz trening")
            self.record_btn.setStyleSheet(f"background:{C_RED}; color:white;")
        else:
            self._rec_timer.stop()
            self.record_btn.setText("Rozpocznij trening")
            self.record_btn.setStyleSheet("")
            self.record_btn.setEnabled(self.streaming)
            self._save_session()

    def _tick_timer(self):
        self._elapsed_s += 1
        m, s = divmod(self._elapsed_s, 60)
        self.timer_label.setText(f"{m:02d}:{s:02d}")

    def _on_sample(self, t, ax, ay, az, gx, gy, gz):
        if not self.active:  # spóźniona próbka z kolejki po rozłączeniu
            return
        if not self.source.is_simulated:   # symulator generuje już dane w osiach aplikacji
            if self._calib_buf is not None:     # zbieramy surowe próbki na postoju
                self._calib_buf.append((t, ax, ay, az, gx, gy, gz))
                if t - self._calib_buf[0][0] >= self.CALIBRATION_SECONDS:
                    self._finish_calibration()
            ax, ay, az, gx, gy, gz = self.calibration.apply(ax, ay, az, gx, gy, gz)
        self.chart.add_sample(t, ax, gz)
        if self.recording:
            self._buf_t.append(t)
            self._buf_ax.append(ax); self._buf_ay.append(ay); self._buf_az.append(az)
            self._buf_gx.append(gx); self._buf_gy.append(gy); self._buf_gz.append(gz)

    def _save_session(self):
        if len(self._buf_t) < 10:
            QMessageBox.information(self, "Za mało danych", "Nagranie było zbyt krótkie, żeby je zapisać.")
            return
        session_id = self.db.create_session(self.user_id, sensor_placement="boot_shin")
        rows = list(zip(self._buf_t, self._buf_ax, self._buf_ay, self._buf_az,
                         self._buf_gx, self._buf_gy, self._buf_gz))
        self.db.insert_sensor_batch(session_id, rows)

        accel_f = moving_average(self._buf_ax, window=5)
        gyro_f = moving_average(self._buf_gz, window=5)
        turns = detect_turns(self._buf_t, gyro_f, accel_f)

        turn_dicts = [
            {"turn_index": tu.index, "start_t": tu.start_t, "end_t": tu.end_t,
             "direction": tu.direction, "score": tu.score,
             "max_lateral_accel": tu.max_lateral_accel, "max_edge_angle": tu.max_edge_angle}
            for tu in turns
        ]
        if turn_dicts:
            self.db.insert_turns(session_id, turn_dicts)

        analysis = full_session_analysis(self._buf_t, self._buf_ax, self._buf_ay,
                                          self._buf_az, gyro_f, turns)
        self.db.update_session_summary(
            session_id, analysis["duration_s"], analysis["turn_count"],
            analysis["ssi"], analysis["style_label"],
        )

        QMessageBox.information(
            self, "Trening zapisany",
            f"Zapisano sesję #{session_id}\nWykryto skrętów: {len(turns)}\n"
            f"SkiSense Index: {analysis['ssi']}  ·  Styl: {analysis['style_label']}",
        )
        self.on_session_saved()

    def shutdown(self):
        """Wywoływane przy zamykaniu okna: zatrzymuje wątek BLE."""
        self._rec_timer.stop()
        if self.source is not None:
            self.source.stop()


# -------------------------------------------------------------------- #
# ZAKŁADKA: HISTORIA
# -------------------------------------------------------------------- #
class SessionListItem(Card):
    def set_selected(self, selected: bool):
        border = C_CYAN if selected else C_BORDER
        bg = "#14202b" if selected else C_CARD
        self.setStyleSheet(f"QFrame#Card {{ background:{bg}; border:{2 if selected else 1}px solid {border}; "
                           f"border-radius:14px; }}")

    def __init__(self, session_id, date, turn_count, duration_s, ssi, style_label, notes=None):
        super().__init__()
        self.session_id = session_id
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)

        left = QVBoxLayout()
        name = QLabel(f"Zjazd #{session_id}")
        name.setStyleSheet(f"color:{C_TEXT}; font-size:15px; font-weight:700; border:none;")
        m, s = divmod(int(duration_s), 60)
        short_date = date[5:16].replace("T", " ") if len(date) >= 16 else date
        meta = QLabel(f"{m:02d}:{s:02d} · {turn_count} skrętów · {short_date}")
        meta.setStyleSheet(f"color:{C_MUTED}; font-size:11.5px; border:none;")
        style_pill = QLabel(style_label)
        style_pill.setStyleSheet(
            f"color:{C_CYAN}; font-size:10.5px; font-weight:700; border:none; "
            f"background:{C_CYAN}1a; border-radius:8px; padding:2px 8px;"
        )
        style_pill.setFixedWidth(style_pill.sizeHint().width())
        left.addWidget(name)
        left.addWidget(meta)
        left.addWidget(style_pill)
        if notes:
            snippet = notes.replace("\n", " ")
            snippet = snippet if len(snippet) <= 60 else snippet[:57] + "…"
            note_lbl = QLabel(f"📝 {snippet}")
            note_lbl.setStyleSheet(f"color:{C_MUTED}; font-size:11px; border:none;")
            left.addWidget(note_lbl)
        left.setSpacing(4)
        layout.addLayout(left, stretch=1)
        layout.addStretch()

        badge = ScoreBadge(ssi, ref_value=160, size=50, decimals=0, sublabel="SSI")
        layout.addWidget(badge)


class HistoryTab(QWidget):
    def __init__(self, db: Database, user_id: int, show_results_callback, on_session_deleted=None):
        super().__init__()
        self.db = db
        self.user_id = user_id
        self.show_results_callback = show_results_callback
        self.on_session_deleted = on_session_deleted

        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(16)

        header = QLabel("Historia")
        hf = QFont(); hf.setPointSize(20); hf.setBold(True)
        header.setFont(hf)
        outer.addWidget(header)

        stats_row = QHBoxLayout()
        self.tile_count = StatTile("Przejazdy", "0")
        self.tile_turns = StatTile("Skręty", "0")
        self.tile_avg = StatTile("Śr. SSI", "0", value_color=C_GREEN)
        stats_row.addWidget(self.tile_count)
        stats_row.addWidget(self.tile_turns)
        stats_row.addWidget(self.tile_avg)
        outer.addLayout(stats_row)

        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.list_widget.itemDoubleClicked.connect(self._open_selected)
        self.list_widget.itemSelectionChanged.connect(self._update_buttons)
        outer.addWidget(self.list_widget, stretch=1)

        self.hint_label = QLabel("Zaznacz dwie sesje (Ctrl), aby je porównać.")
        self.hint_label.setStyleSheet(f"color:{C_MUTED}; font-size:11.5px;")
        outer.addWidget(self.hint_label)

        btn_row = QHBoxLayout()
        self.open_btn = QPushButton("Pokaż wyniki")
        self.open_btn.setObjectName("Primary")
        self.open_btn.clicked.connect(self._open_selected)
        self.compare_btn = QPushButton("Porównaj (2)")
        self.compare_btn.setObjectName("Secondary")
        self.compare_btn.clicked.connect(self._compare_selected)
        self.delete_btn = QPushButton("Usuń")
        self.delete_btn.setObjectName("Secondary")
        self.delete_btn.clicked.connect(self._delete_selected)
        for b in (self.open_btn, self.compare_btn, self.delete_btn):
            btn_row.addWidget(b)
        outer.addLayout(btn_row)
        self._update_buttons()

        self.refresh()

    def refresh(self):
        self.list_widget.clear()
        sessions = self.db.list_sessions(self.user_id)

        total_turns = sum(s[5] or 0 for s in sessions)
        avg_ssi = (sum(s[6] or 0 for s in sessions) / len(sessions)) if sessions else 0.0
        self.tile_count.set_value(str(len(sessions)))
        self.tile_turns.set_value(str(total_turns))
        self.tile_avg.set_value(f"{avg_ssi:.0f}", value_color=score_color(max(0.0, min(100.0, (avg_ssi - 70) / 0.9))))

        for session_id, date, placement, notes, duration_s, turn_count, overall_score, style_label in sessions:
            item = QListWidgetItem()
            widget = SessionListItem(session_id, date, turn_count or 0, duration_s or 0,
                                      overall_score or 0.0, style_label or "—", notes)
            item.setData(Qt.UserRole, session_id)
            item.setSizeHint(widget.sizeHint())
            self.list_widget.addItem(item)
            self.list_widget.setItemWidget(item, widget)
        self._update_buttons()

    def selected_ids(self):
        return [it.data(Qt.UserRole) for it in self.list_widget.selectedItems()]

    def _update_buttons(self):
        selected = set(self.selected_ids())
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            widget = self.list_widget.itemWidget(item)
            if widget is not None:
                widget.set_selected(item.data(Qt.UserRole) in selected)
        n = len(selected)
        self.open_btn.setEnabled(n == 1)
        self.compare_btn.setEnabled(n == 2)
        self.delete_btn.setEnabled(n >= 1)
        self.delete_btn.setText("Usuń" if n <= 1 else f"Usuń ({n})")

    def _open_selected(self, *_):
        ids = self.selected_ids()
        if len(ids) == 1:
            self.show_results_callback(ids[0])
        elif not ids and self.list_widget.currentItem():
            self.show_results_callback(self.list_widget.currentItem().data(Qt.UserRole))

    def _compare_selected(self):
        ids = sorted(self.selected_ids())   # starsza sesja po lewej, nowsza po prawej
        if len(ids) != 2:
            return
        loaded = [load_session(self.db, i) for i in ids]
        if any(l is None or l["analysis"] is None for l in loaded):
            QMessageBox.warning(self, "Porównanie", "Jedna z sesji nie ma zapisanych danych z czujnika.")
            return
        CompareDialog(loaded[0], loaded[1], self).exec_()

    def _delete_selected(self):
        ids = self.selected_ids()
        if not ids:
            return
        what = f"sesję #{ids[0]}" if len(ids) == 1 else f"{len(ids)} sesje/sesji"
        answer = QMessageBox.question(
            self, "Usuń", f"Na pewno usunąć {what}? Dane z czujnika i analiza zostaną skasowane bez możliwości odzyskania.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer != QMessageBox.Yes:
            return
        for sid in ids:
            self.db.delete_session(sid)
            if self.on_session_deleted:
                self.on_session_deleted(sid)
        self.refresh()


# -------------------------------------------------------------------- #
# ZAKŁADKA: WYNIKI (Raport / Skręty / Sygnały / Trend)
# -------------------------------------------------------------------- #
class ReportSubTab(QWidget):
    def __init__(self):
        super().__init__()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 12, 0, 0)
        outer.setSpacing(16)

        # -- hero: SkiSense Index (duży wskaźnik, inspirowany Ski:IQ z Carv) --
        hero = Card()
        hero.setStyleSheet(
            f"QFrame#Card {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:1, "
            f"stop:0 #121820, stop:1 #16202b); border:1px solid {C_BORDER}; border-radius:16px; }}"
        )
        hl = QHBoxLayout(hero)
        hl.setContentsMargins(22, 20, 22, 20)
        hl.setSpacing(18)

        self.hero_badge = ScoreBadge(0, ref_value=160, size=104, decimals=0, sublabel="SSI")
        hl.addWidget(self.hero_badge)

        hero_right = QVBoxLayout()
        cap = QLabel("SKISENSE INDEX")
        cap.setStyleSheet(f"color:{C_MUTED}; font-size:10.5px; font-weight:700; letter-spacing:1.5px; border:none;")
        self.style_label = QLabel("—")
        sf = QFont(); sf.setPointSize(18); sf.setBold(True)
        self.style_label.setFont(sf)
        self.style_label.setStyleSheet(f"color:{C_CYAN}; border:none;")
        self.style_desc = QLabel("Przeciętny rekreacyjny narciarz: ok. 100 pkt")
        self.style_desc.setWordWrap(True)
        self.style_desc.setStyleSheet(f"color:{C_MUTED}; font-size:12px; border:none;")
        hero_right.addWidget(cap)
        hero_right.addWidget(self.style_label)
        hero_right.addWidget(self.style_desc)
        hero_right.addStretch()
        hl.addLayout(hero_right, stretch=1)
        outer.addWidget(hero)

        # -- rozbicie na kategorie umiejętności (jak profil techniki w Carv) --
        skills_card = Card()
        skl = QVBoxLayout(skills_card)
        skl.setContentsMargins(18, 14, 18, 14)
        skl.setSpacing(2)
        scap = QLabel("ROZBICIE NA KATEGORIE")
        scap.setStyleSheet(f"color:{C_MUTED}; font-size:10.5px; font-weight:700; letter-spacing:1px; border:none;")
        skl.addWidget(scap)
        self.bar_balance = QualityBar("⚖️  Balans", 0)
        self.bar_edge = QualityBar("📐  Kontrola krawędzi", 0)
        self.bar_turn_shape = QualityBar("〰️  Kształt skrętu", 0)
        self.bar_rhythm_skill = QualityBar("🥁  Rytm", 0)
        for b in (self.bar_balance, self.bar_edge, self.bar_turn_shape, self.bar_rhythm_skill):
            skl.addWidget(b)
        outer.addWidget(skills_card)

        # -- gauge kąta krawędziowania --
        gauge_card = Card()
        gl = QVBoxLayout(gauge_card)
        gl.setContentsMargins(18, 10, 18, 10)
        gauge_title = QLabel("ŚREDNI KĄT KRAWĘDZIOWANIA")
        gauge_title.setStyleSheet(f"color:{C_MUTED}; font-size:10.5px; font-weight:700; letter-spacing:1px; border:none;")
        gl.addWidget(gauge_title)
        self.gauge = SemiGauge(0, 40, "kąt krawędzi", "°")
        gl.addWidget(self.gauge)
        outer.addWidget(gauge_card)

        # -- surowe metryki (szczegóły techniczne) --
        grid = QGridLayout()
        grid.setSpacing(12)
        self.tile_turns = StatTile("Liczba skrętów", "0")
        self.tile_cadence = StatTile("Kadencja", "0 /min", value_color=C_CYAN)
        self.tile_pitch = StatTile("Pozycja przód/tył", "0°", value_color=C_AMBER)
        self.tile_vibration = StatTile("Poziom drgań", "0 /100", value_color=C_RED)
        grid.addWidget(self.tile_turns, 0, 0)
        grid.addWidget(self.tile_cadence, 0, 1)
        grid.addWidget(self.tile_pitch, 1, 0)
        grid.addWidget(self.tile_vibration, 1, 1)
        outer.addLayout(grid)
        outer.addStretch()

    def show_analysis(self, a: dict):
        self.hero_badge.set_score(a["ssi"])
        self.style_label.setText(a["style_label"])
        self.bar_balance.set_value(a["balance_pct"])
        self.bar_edge.set_value(a["edge_pct"])
        self.bar_turn_shape.set_value(a["turn_shape_pct"])
        self.bar_rhythm_skill.set_value(a["rhythm_pct"])
        self.gauge.set_value(a["avg_edge_angle"])
        self.tile_turns.set_value(str(a["turn_count"]))
        self.tile_cadence.set_value(f"{a['cadence_per_min']:.1f} /min")
        self.tile_pitch.set_value(f"{a['pitch_deg']:.1f}°")
        self.tile_vibration.set_value(f"{a['vibration']:.0f} /100")


class TurnsSubTab(QWidget):
    def __init__(self):
        super().__init__()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 12, 0, 0)
        outer.setSpacing(12)

        hist_card = Card()
        hl = QVBoxLayout(hist_card)
        hl.setContentsMargins(12, 12, 12, 12)
        self.hist_chart = HistogramChart()
        hl.addWidget(self.hist_chart)
        outer.addWidget(hist_card)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Skręt #", "Kier.", "Start [s]", "Koniec [s]", "Ocena", "Kąt krawędzi"]
        )
        self.table.verticalHeader().setVisible(False)
        outer.addWidget(self.table, stretch=1)

    def show_turns(self, turns):
        self.hist_chart.plot([tu.score for tu in turns])
        self.table.setRowCount(len(turns))
        for i, tu in enumerate(turns):
            values = [
                str(i + 1), "L" if tu.direction == "left" else "P",
                f"{tu.start_t:.2f}", f"{tu.end_t:.2f}", f"{tu.score:.1f}", f"{tu.max_edge_angle:.1f}°",
            ]
            for col, val in enumerate(values):
                item = QTableWidgetItem(val)
                item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(i, col, item)


class SignalsSubTab(QWidget):
    def __init__(self):
        super().__init__()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 12, 0, 0)
        card = Card()
        cl = QVBoxLayout(card)
        cl.setContentsMargins(12, 12, 12, 12)
        self.chart = ResultChart()
        cl.addWidget(self.chart)
        outer.addWidget(card)

    def show_signal(self, t_vals, accel_vals, turns):
        self.chart.plot_session(t_vals, accel_vals, turns)


class TrendSubTab(QWidget):
    def __init__(self, db: Database):
        super().__init__()
        self.db = db
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 12, 0, 0)
        outer.setSpacing(16)

        trend_card = Card()
        tl = QVBoxLayout(trend_card)
        tl.setContentsMargins(12, 12, 12, 12)
        cap = QLabel("TREND ŚREDNIEJ OCENY MIĘDZY SESJAMI")
        cap.setStyleSheet(f"color:{C_MUTED}; font-size:10.5px; font-weight:700; letter-spacing:1px; border:none;")
        tl.addWidget(cap)
        self.trend_chart = TrendChart()
        tl.addWidget(self.trend_chart)
        outer.addWidget(trend_card)

        radar_card = Card()
        rl = QVBoxLayout(radar_card)
        rl.setContentsMargins(12, 12, 12, 12)
        rcap = QLabel("PROFIL STYLU JAZDY (BIEŻĄCA SESJA)")
        rcap.setStyleSheet(f"color:{C_MUTED}; font-size:10.5px; font-weight:700; letter-spacing:1px; border:none;")
        rl.addWidget(rcap)
        self.radar_chart = RadarChart()
        rl.addWidget(self.radar_chart)
        outer.addWidget(radar_card)
        outer.addStretch()

    def show_trend(self, user_id: int, current_analysis: dict):
        sessions = list(reversed(self.db.list_sessions(user_id)))[-10:]
        labels = [s[1][5:16] for s in sessions]
        scores = [s[6] or 0 for s in sessions]
        self.trend_chart.plot(labels, scores)

        self.radar_chart.plot(
            ["Płynność", "Rytm", "Symetria", "Stabilność"],
            [current_analysis["fluency_pct"], current_analysis["rhythm_consistency"],
             current_analysis["symmetry"], current_analysis["stability_pct"]],
        )


class ResultsTab(QWidget):
    def __init__(self, db: Database, user_id: int, on_changed=None, save_path_provider=None, user_name=""):
        super().__init__()
        self.db = db
        self.user_id = user_id
        self.on_changed = on_changed                       # wołane po zmianie notatki (odświeża Historię)
        self._save_path_provider = save_path_provider or self._ask_save_path
        self.user_name = user_name
        self.session_id = None
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(10)

        header_row = QHBoxLayout()
        self.title_label = QLabel("Wybierz sesję w zakładce Historia")
        hf = QFont(); hf.setPointSize(18); hf.setBold(True)
        self.title_label.setFont(hf)
        header_row.addWidget(self.title_label)
        header_row.addStretch()
        self.note_btn = QPushButton("Notatka")
        self.note_btn.setObjectName("Secondary")
        self.note_btn.clicked.connect(self.edit_note)
        self.export_btn = QPushButton("Eksport")
        self.export_btn.setObjectName("Secondary")
        menu = QMenu(self.export_btn)
        for label, kind in (("Raport PDF", "pdf"), ("Dane surowe CSV", "raw"),
                            ("Dane surowe CSV (polski Excel)", "raw_pl"), ("Skręty CSV", "turns")):
            menu.addAction(label, lambda k=kind: self.export(k))
        self.export_btn.setMenu(menu)
        header_row.addWidget(self.note_btn)
        header_row.addWidget(self.export_btn)
        outer.addLayout(header_row)
        self.note_btn.setEnabled(False)
        self.export_btn.setEnabled(False)

        self.subtitle_label = QLabel("")
        self.subtitle_label.setStyleSheet(f"color:{C_MUTED}; font-size:12px;")
        outer.addWidget(self.subtitle_label)
        self.notes_label = QLabel("")
        self.notes_label.setWordWrap(True)
        self.notes_label.setStyleSheet(f"color:{C_TEXT}; font-size:12px;")
        self.notes_label.setVisible(False)
        outer.addWidget(self.notes_label)

        self.sub_tabs = QTabWidget()
        self.report_tab = ReportSubTab()
        self.turns_tab = TurnsSubTab()
        self.signals_tab = SignalsSubTab()
        self.trend_tab = TrendSubTab(db)
        self.sub_tabs.addTab(self.report_tab, "Raport")
        self.sub_tabs.addTab(self.turns_tab, "Skręty")
        self.sub_tabs.addTab(self.signals_tab, "Sygnały")
        self.sub_tabs.addTab(self.trend_tab, "Trend")
        outer.addWidget(self.sub_tabs, stretch=1)

    def clear_session(self):
        """Czyści widok (np. po usunięciu wyświetlanej sesji)."""
        self.session_id = None
        self.title_label.setText("Wybierz sesję w zakładce Historia")
        self.subtitle_label.setText("")
        self.notes_label.setVisible(False)
        self.note_btn.setEnabled(False)
        self.export_btn.setEnabled(False)

    def _refresh_notes(self, notes):
        self.notes_label.setText(f"📝 {notes}" if notes else "")
        self.notes_label.setVisible(bool(notes))

    def show_session(self, session_id: int):
        loaded = load_session(self.db, session_id)
        if loaded is None:
            self.clear_session()
            self.subtitle_label.setText("Ta sesja już nie istnieje.")
            return
        self.session_id = session_id
        self.note_btn.setEnabled(True)
        self.title_label.setText(f"Zjazd #{session_id}")
        self._refresh_notes(loaded["session"]["notes"])
        if loaded["analysis"] is None:
            self.export_btn.setEnabled(False)
            self.subtitle_label.setText("Brak danych dla tej sesji.")
            return
        self.export_btn.setEnabled(True)

        data = loaded["data"]
        t_vals, accel_x, turns, analysis = loaded["t"], loaded["ax"], loaded["turns"], loaded["analysis"]
        m, s = divmod(int(analysis["duration_s"]), 60)
        self.subtitle_label.setText(f"{m:02d}:{s:02d}  ·  {len(data)} próbek  ·  {analysis['turn_count']} skrętów")

        self.report_tab.show_analysis(analysis)
        self.turns_tab.show_turns(turns)
        self.signals_tab.show_signal(t_vals, accel_x, turns)
        self.trend_tab.show_trend(self.user_id, analysis)
        self.sub_tabs.setCurrentIndex(0)

    # ---------------------------------------------------------------- #
    # Notatka i eksport
    # ---------------------------------------------------------------- #
    def edit_note(self):
        if self.session_id is None:
            return
        current = (self.db.get_session(self.session_id) or {}).get("notes") or ""
        text, ok = QInputDialog.getMultiLineText(self, "Notatka do zjazdu",
                                                  "Warunki, sprzęt, odczucia (puste = usuń notatkę):", current)
        if not ok:
            return
        self.db.update_notes(self.session_id, text)
        self._refresh_notes(text.strip())
        if self.on_changed:
            self.on_changed()

    def _ask_save_path(self, kind: str, default_name: str) -> str:
        filt = "PDF (*.pdf)" if kind == "pdf" else "CSV (*.csv)"
        path, _ = QFileDialog.getSaveFileName(self, "Zapisz jako", default_name, filt)
        return path

    def export(self, kind: str):
        """kind: pdf | raw | raw_pl | turns"""
        if self.session_id is None:
            return
        loaded = load_session(self.db, self.session_id)
        if loaded is None or loaded["analysis"] is None:
            QMessageBox.warning(self, "Eksport", "Ta sesja nie ma danych do wyeksportowania.")
            return
        names = {"pdf": f"zjazd_{self.session_id}.pdf", "raw": f"zjazd_{self.session_id}.csv",
                 "raw_pl": f"zjazd_{self.session_id}_excel.csv", "turns": f"zjazd_{self.session_id}_skrety.csv"}
        path = self._save_path_provider(kind, names[kind])
        if not path:
            return
        try:
            if kind == "pdf":
                export.export_report_pdf(path, loaded, self.user_name)
            elif kind == "turns":
                export.export_turns_csv(path, loaded["turns"])
            else:
                export.export_raw_csv(path, loaded["data"], "excel_pl" if kind == "raw_pl" else "standard")
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, "Eksport nie powiódł się", str(exc))
            return
        QMessageBox.information(self, "Eksport", f"Zapisano plik:\n{path}")


class TopBar(QWidget):
    """Stały pasek u góry aplikacji: logo/nazwa + status połączenia z czujnikiem."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background:{C_CARD}; border-bottom:1px solid {C_BORDER};")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(18, 10, 18, 10)

        icon = QLabel("⛷")
        icon.setFixedSize(36, 36)
        icon.setAlignment(Qt.AlignCenter)
        icon.setStyleSheet(
            f"background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {C_CYAN}, stop:1 {C_GREEN}); "
            f"border-radius:10px; font-size:17px; border:none;"
        )
        layout.addWidget(icon)

        text_box = QVBoxLayout()
        text_box.setSpacing(0)
        name = QLabel("SkiSense")
        name.setStyleSheet(f"color:{C_TEXT}; font-size:15px; font-weight:800; border:none;")
        subtitle = QLabel("Twój asystent na stoku")
        subtitle.setStyleSheet(f"color:{C_MUTED}; font-size:10.5px; border:none;")
        text_box.addWidget(name)
        text_box.addWidget(subtitle)
        layout.addLayout(text_box)
        layout.addStretch()

        self.status_dot = QLabel("●")
        self.status_text = QLabel("ESP32 · Rozłączono")
        self.status_dot.setStyleSheet(f"color:{C_RED}; font-size:11px; border:none;")
        self.status_text.setStyleSheet(f"color:{C_MUTED}; font-size:11.5px; font-weight:600; border:none;")
        layout.addWidget(self.status_dot)
        layout.addWidget(self.status_text)

    def set_connected(self, is_connected: bool, label: str = "ESP32"):
        if is_connected:
            self.status_dot.setStyleSheet(f"color:{C_GREEN}; font-size:11px; border:none;")
            self.status_text.setText(f"{label} · Połączono")
        else:
            self.status_dot.setStyleSheet(f"color:{C_RED}; font-size:11px; border:none;")
            self.status_text.setText(f"{label} · Rozłączono")


# -------------------------------------------------------------------- #
# GŁÓWNE OKNO
# -------------------------------------------------------------------- #
class CompareDialog(QDialog):
    """Porównanie dwóch sesji: tabela metryk z różnicą (B − A) i wykres kategorii."""

    # (klucz, etykieta, format, czy "więcej = lepiej": True/False/None dla neutralnych)
    METRICS = [
        ("ssi", "SkiSense Index", "{:.0f}", True),
        ("balance_pct", "Balans", "{:.0f}", True),
        ("edge_pct", "Kontrola krawędzi", "{:.0f}", True),
        ("turn_shape_pct", "Kształt skrętu", "{:.0f}", True),
        ("rhythm_pct", "Rytm", "{:.0f}", True),
        ("turn_count", "Liczba skrętów", "{:.0f}", None),
        ("cadence_per_min", "Kadencja [/min]", "{:.1f}", None),
        ("avg_score", "Średnia ocena skrętu", "{:.1f}", True),
        ("symmetry", "Symetria", "{:.0f}", True),
        ("avg_edge_angle", "Kąt krawędziowania [°]", "{:.1f}", None),
        ("intensity", "Intensywność", "{:.0f}", None),
        ("vibration", "Poziom drgań", "{:.0f}", False),
    ]

    def __init__(self, a: dict, b: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Porównanie sesji")
        self.resize(640, 760)
        sa, sb = a["session"], b["session"]
        self.name_a, self.name_b = f"Zjazd #{sa['id']}", f"Zjazd #{sb['id']}"
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 18, 20, 18)
        lay.setSpacing(12)

        title = QLabel(f"{self.name_a}  →  {self.name_b}")
        tf = QFont(); tf.setPointSize(16); tf.setBold(True)
        title.setFont(tf)
        lay.addWidget(title)
        sub = QLabel(f"{sa['date'][:16].replace('T', ' ')}   →   {sb['date'][:16].replace('T', ' ')}")
        sub.setStyleSheet(f"color:{C_MUTED};")
        lay.addWidget(sub)

        aa, ab = a["analysis"], b["analysis"]
        self.table = QTableWidget(len(self.METRICS), 4)
        self.table.setHorizontalHeaderLabels(["Metryka", self.name_a, self.name_b, "Zmiana"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        for col in (1, 2, 3):
            self.table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeToContents)
        for row, (key, label, fmt, better_up) in enumerate(self.METRICS):
            va, vb = float(aa[key]), float(ab[key])
            diff = vb - va
            cells = [label, fmt.format(va), fmt.format(vb), ("+" if diff > 0 else "") + fmt.format(diff)]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                if col:
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table.setItem(row, col, item)
            delta = self.table.item(row, 3)
            if round(diff, 6) == 0 or better_up is None:
                color = C_MUTED
            else:
                color = C_GREEN if (diff > 0) == better_up else C_RED
            delta.setForeground(QColor(color))
            f = delta.font(); f.setBold(True); delta.setFont(f)
        self.table.verticalHeader().setDefaultSectionSize(30)
        self.table.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.table.setFixedHeight(self.table.horizontalHeader().height() + 30 * len(self.METRICS) + 4)
        lay.addWidget(self.table)

        self.chart = CompareChart()
        self.chart.plot(["Balans", "Krawędź", "Kształt", "Rytm"],
                        [aa["balance_pct"], aa["edge_pct"], aa["turn_shape_pct"], aa["rhythm_pct"]],
                        [ab["balance_pct"], ab["edge_pct"], ab["turn_shape_pct"], ab["rhythm_pct"]],
                        self.name_a, self.name_b)
        lay.addWidget(self.chart, stretch=1)

        close = QPushButton("Zamknij")
        close.setObjectName("Secondary")
        close.clicked.connect(self.accept)
        lay.addWidget(close)


# -------------------------------------------------------------------- #
class AxisMapDialog(QDialog):
    """Wybór, której osi czujnika użyć jako X (bok), Y (przód/tył) i Z (pion)."""

    NAMES = ["X", "Y", "Z"]
    ROLES = ["Bok (lewo/prawo)", "Przód / tył", "Pion"]

    def __init__(self, axis_map: AxisMap, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Mapowanie osi czujnika")
        lay = QVBoxLayout(self)
        info = QLabel("Wskaż, której osi czujnika użyć dla każdego kierunku. "
                      "Zmiana osi unieważnia kalibrację postoju.")
        info.setWordWrap(True)
        lay.addWidget(info)
        grid = QGridLayout()
        self.combos, self.checks = [], []
        for i, role in enumerate(self.ROLES):
            grid.addWidget(QLabel(role), i, 0)
            combo = QComboBox()
            for k, name in enumerate(self.NAMES):
                combo.addItem(f"oś {name} czujnika", k)
            combo.setCurrentIndex(axis_map.src[i])
            chk = QCheckBox("odwróć")
            chk.setChecked(axis_map.sign[i] < 0)
            grid.addWidget(combo, i, 1)
            grid.addWidget(chk, i, 2)
            self.combos.append(combo)
            self.checks.append(chk)
        lay.addLayout(grid)
        self.warn = QLabel("")
        self.warn.setStyleSheet(f"color:{C_RED};")
        lay.addWidget(self.warn)
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self._accept)
        self.buttons.rejected.connect(self.reject)
        lay.addWidget(self.buttons)

    def axis_map(self) -> AxisMap:
        return AxisMap([c.currentData() for c in self.combos],
                       [-1 if k.isChecked() else 1 for k in self.checks])

    def _accept(self):
        if not self.axis_map().is_valid():
            self.warn.setText("Każda oś czujnika może być użyta tylko raz.")
            return
        self.accept()


# -------------------------------------------------------------------- #
class MainWindow(QMainWindow):
    def __init__(self, ble_backend=None, db_path=None, csv_path_provider=None, save_path_provider=None):
        super().__init__()
        self.setWindowTitle("SkiSense — Analiza jazdy na nartach (IMU)")
        self.resize(760, 900)

        self.db = Database(db_path) if db_path else Database()
        self.user_id = self.db.get_or_create_user("Patryk")

        central = QWidget()
        central_layout = QVBoxLayout(central)
        central_layout.setContentsMargins(0, 0, 0, 0)
        central_layout.setSpacing(0)

        self.top_bar = TopBar()
        central_layout.addWidget(self.top_bar)

        self.tabs = QTabWidget()
        central_layout.addWidget(self.tabs, stretch=1)
        self.setCentralWidget(central)

        self.history_tab = HistoryTab(self.db, self.user_id, self._show_results,
                                      on_session_deleted=self._on_session_deleted)
        self.results_tab = ResultsTab(self.db, self.user_id, on_changed=self.history_tab.refresh,
                                      save_path_provider=save_path_provider, user_name="Patryk")
        self.live_tab = LiveTab(self.db, self.user_id, self.history_tab.refresh,
                                 on_connection_changed=self.top_bar.set_connected,
                                 ble_backend=ble_backend,
                                 profile_path=os.path.join(
                                     os.path.dirname(os.path.abspath(self.db.db_path)), "calibration.json"),
                                 csv_path_provider=csv_path_provider)

        self.tabs.addTab(self.live_tab, "Trening")
        self.tabs.addTab(self.history_tab, "Historia")
        self.tabs.addTab(self.results_tab, "Wyniki")

    def _on_session_deleted(self, session_id: int):
        if self.results_tab.session_id == session_id:
            self.results_tab.clear_session()

    def _show_results(self, session_id: int):
        self.results_tab.show_session(session_id)
        self.tabs.setCurrentWidget(self.results_tab)

    def closeEvent(self, event):
        self.live_tab.shutdown()  # zatrzymuje wątek BLE, zanim zamkniemy bazę
        self.db.close()
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(APP_QSS)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
