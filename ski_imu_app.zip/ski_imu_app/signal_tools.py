"""
signal_tools.py

Kalibracja czujnika i mapowanie osi -- działają na próbce (t, ax, ay, az, gx, gy, gz)
zanim trafi ona na wykres i do nagrania.

Mapowanie osi: czujnik na bucie może być zamontowany pod dowolnym kątem
(np. złączem do góry albo do przodu). Dla każdej osi aplikacji (X = bok,
Y = przód/tył, Z = pion) wskazujemy, której osi czujnika użyć i czy odwrócić znak.
To samo mapowanie stosujemy do akcelerometru i żyroskopu.

Kalibracja ("postój"): kilka sekund, gdy narta stoi nieruchomo, daje
  * bias żyroskopu (średnia z gx, gy, gz) -- odejmowany od każdej próbki,
  * offset akcelerometru w osiach X i Y (po mapowaniu), tak aby na płaskim
    podłożu boczne i przednie przyspieszenie wynosiło 0. Oś Z (grawitacja)
    zostaje bez zmian.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from typing import Optional

AXES = ("x", "y", "z")


@dataclass
class AxisMap:
    """src[i] -- numer osi czujnika (0=X, 1=Y, 2=Z) używanej jako i-ta oś aplikacji; sign[i] = +1/-1."""
    src: list = field(default_factory=lambda: [0, 1, 2])
    sign: list = field(default_factory=lambda: [1, 1, 1])

    def is_valid(self) -> bool:
        return sorted(self.src) == [0, 1, 2] and all(s in (1, -1) for s in self.sign)

    def is_identity(self) -> bool:
        return self.src == [0, 1, 2] and self.sign == [1, 1, 1]

    def apply3(self, v):
        return tuple(self.sign[i] * v[self.src[i]] for i in range(3))


@dataclass
class Calibration:
    axis_map: AxisMap = field(default_factory=AxisMap)
    gyro_bias: list = field(default_factory=lambda: [0.0, 0.0, 0.0])    # deg/s, po mapowaniu
    accel_offset: list = field(default_factory=lambda: [0.0, 0.0, 0.0])  # m/s^2, po mapowaniu (z zawsze 0)
    calibrated: bool = False

    def apply(self, ax, ay, az, gx, gy, gz):
        """Surowe osie czujnika -> osie aplikacji z korekcją biasu. Zwraca (ax, ay, az, gx, gy, gz)."""
        a = self.axis_map.apply3((ax, ay, az))
        g = self.axis_map.apply3((gx, gy, gz))
        return (
            a[0] - self.accel_offset[0], a[1] - self.accel_offset[1], a[2] - self.accel_offset[2],
            g[0] - self.gyro_bias[0], g[1] - self.gyro_bias[1], g[2] - self.gyro_bias[2],
        )

    def apply_sample(self, sample):
        """(t, ax..gz) -> (t, ax..gz) po kalibracji."""
        return (sample[0], *self.apply(*sample[1:]))

    def with_axis_map(self, axis_map: AxisMap) -> "Calibration":
        """Zmiana mapowania unieważnia kalibrację postoju (offsety zależą od osi)."""
        return Calibration(axis_map=axis_map)

    # --- zapis/odczyt ---
    def to_dict(self):
        return {"axis_map": asdict(self.axis_map), "gyro_bias": self.gyro_bias,
                "accel_offset": self.accel_offset, "calibrated": self.calibrated}

    @staticmethod
    def from_dict(d) -> "Calibration":
        am = AxisMap(list(d["axis_map"]["src"]), list(d["axis_map"]["sign"]))
        if not am.is_valid():
            raise ValueError("Nieprawidłowe mapowanie osi")
        return Calibration(am, [float(x) for x in d["gyro_bias"]],
                           [float(x) for x in d["accel_offset"]], bool(d.get("calibrated", False)))


def calibrate_from_rest(samples, axis_map: Optional[AxisMap] = None, min_samples: int = 25,
                        max_gyro_std: float = 5.0, max_accel_std: float = 1.0) -> Calibration:
    """
    samples: lista (t, ax, ay, az, gx, gy, gz) zebrana na postoju (surowe osie czujnika).
    Zgłasza ValueError, jeśli próbek jest za mało albo czujnik się poruszał.
    """
    import numpy as np

    if len(samples) < min_samples:
        raise ValueError(f"Za mało próbek do kalibracji ({len(samples)} < {min_samples}).")
    am = axis_map or AxisMap()
    arr = np.array([am.apply3(s[1:4]) + am.apply3(s[4:7]) for s in samples], dtype=float)
    acc, gyr = arr[:, :3], arr[:, 3:]
    if gyr.std(axis=0).max() > max_gyro_std or acc.std(axis=0).max() > max_accel_std:
        raise ValueError("Czujnik się poruszał podczas kalibracji. Ustaw nartę nieruchomo i spróbuj ponownie.")
    acc_mean = acc.mean(axis=0)
    return Calibration(
        axis_map=am,
        gyro_bias=[float(x) for x in gyr.mean(axis=0)],
        accel_offset=[float(acc_mean[0]), float(acc_mean[1]), 0.0],
        calibrated=True,
    )


def save_calibration(cal: Calibration, path: str):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cal.to_dict(), f, indent=2)


def load_calibration(path: Optional[str]) -> Calibration:
    """Wczytuje zapisany profil; przy braku pliku albo błędzie zwraca domyślny (bez korekcji)."""
    if not path or not os.path.exists(path):
        return Calibration()
    try:
        with open(path, encoding="utf-8") as f:
            return Calibration.from_dict(json.load(f))
    except (OSError, ValueError, KeyError, TypeError):
        return Calibration()
