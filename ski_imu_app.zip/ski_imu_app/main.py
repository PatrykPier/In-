"""
main.py
Punkt wejścia aplikacji desktopowej do analizy jazdy na nartach (IMU).

Uruchomienie:
    pip install -r requirements.txt
    python main.py

Test dymny (sprawdza, że okno, wykres i symulacja startują; używany do weryfikacji
zbudowanego pliku .exe):
    python main.py --smoke-test
"""

import sys


def smoke_test() -> int:
    import os
    import tempfile
    import time

    from PyQt5.QtWidgets import QApplication

    import main_window

    app = QApplication(sys.argv[:1])
    app.setStyleSheet(main_window.APP_QSS)
    with tempfile.TemporaryDirectory() as tmp:
        w = main_window.MainWindow(db_path=os.path.join(tmp, "smoke.db"))
        w.show()
        live = w.live_tab
        live.connect_btn.click()
        end = time.monotonic() + 1.5
        while time.monotonic() < end:
            app.processEvents()
            time.sleep(0.005)
        got = live.chart._n
        live.connect_btn.click()
        w.close()

        # eksport PDF sprawdza też czcionki i reportlab w zbudowanym programie
        import math
        import export
        from data_analysis import moving_average, detect_turns
        from database import Database
        from session_service import load_session

        db = Database(os.path.join(tmp, "smoke2.db"))
        uid = db.get_or_create_user("smoke")
        sid = db.create_session(uid)
        rows = [(i * 0.02, 2.2 * math.sin(i * 0.09), 0.0, 9.81, 0.0, 0.0, 55 * math.cos(i * 0.09)) for i in range(600)]
        db.insert_sensor_batch(sid, rows)
        turns = detect_turns([r[0] for r in rows], moving_average([r[6] for r in rows]), moving_average([r[1] for r in rows]))
        db.insert_turns(sid, [{"turn_index": t.index, "start_t": t.start_t, "end_t": t.end_t, "direction": t.direction,
                               "score": t.score, "max_lateral_accel": t.max_lateral_accel,
                               "max_edge_angle": t.max_edge_angle} for t in turns])
        pdf = os.path.join(tmp, "smoke.pdf")
        export.export_report_pdf(pdf, load_session(db, sid), "smoke")
        pdf_size = os.path.getsize(pdf)
        db.close()
    if got < 20:
        print(f"SMOKE FAIL: wykres dostał tylko {got} próbek")
        return 1
    if pdf_size < 5000:
        print(f"SMOKE FAIL: PDF ma tylko {pdf_size} B")
        return 1
    print(f"SMOKE OK: {got} próbek na wykresie, PDF {pdf_size} B")
    return 0


if __name__ == "__main__":
    if "--smoke-test" in sys.argv:
        sys.exit(smoke_test())
    from main_window import main
    main()
