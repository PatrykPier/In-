"""
data_source.py

Warstwa abstrakcji źródła danych IMU. Dzięki temu GUI i analiza danych
nie wiedzą, skąd realnie przychodzą dane -- z symulatora (teraz, bez
sprzętu) czy z prawdziwego ESP32 po BLE (później).

Czujnik zamontowany na bucie/goleni -> przyjmujemy:
  - oś X akcelerometru: przyspieszenie boczne (lewo/prawo) -- najważniejsza
    do wykrywania skrętów i oceny ich jakości
  - oś Y akcelerometru: przód/tył (hamowanie/przyspieszanie)
  - oś Z akcelerometru: pionowa (grawitacja + wibracje terenu)
  - oś Z żyroskopu: prędkość kątowa obrotu wokół osi pionowej golenia
    (odpowiada rotacji stopy przy skręcie)
  - kąt przechylenia (roll, z osi X/Z akcelerometru) przybliża kąt
    krawędziowania narty (edge angle)

Każde źródło danych woła callback(t, ax, ay, az, gx, gy, gz) z nowymi
próbkami w pętli zdarzeń Qt (QTimer), więc GUI nie blokuje się na I/O.
"""

from __future__ import annotations
import math
import random
from PyQt5.QtCore import QObject, QTimer, pyqtSignal


class DataSource(QObject):
    """
    Wspólny interfejs źródeł danych.

    Sygnały:
      sample_ready(t, ax, ay, az, gx, gy, gz) -- nowa próbka
      connected(bool)                          -- czy dane aktualnie płyną
      state_changed(str)                       -- scanning/connecting/streaming/disconnected/stopped
      status_message(str)                      -- komunikat czytelny dla człowieka
      stats_changed(odebrane, zgubione)        -- statystyki pakietów (BLE)
    """

    sample_ready = pyqtSignal(float, float, float, float, float, float, float)
    connected = pyqtSignal(bool)
    state_changed = pyqtSignal(str)
    status_message = pyqtSignal(str)
    stats_changed = pyqtSignal(int, int)
    finished = pyqtSignal()   # źródło skończyło dane samo (np. koniec pliku CSV)

    #: czy źródło ma suwak "jakość techniki" (tylko symulator)
    is_simulated = False

    def start(self):
        raise NotImplementedError

    def stop(self):
        raise NotImplementedError


class SimulatedDataSource(DataSource):
    """
    Generuje sztuczne dane IMU przypominające jazdę slalomem: cykliczne
    skręty lewo/prawo z regulowaną "jakością" (płynnością) skrętu, żeby
    można było testować algorytm wykrywania i oceny skrętów bez sprzętu.
    """

    SAMPLE_RATE_HZ = 50
    is_simulated = True

    def __init__(self, turn_period_s: float = 2.2, roughness: float = 0.15, parent=None):
        super().__init__(parent)
        self._t = 0.0
        self._dt = 1.0 / self.SAMPLE_RATE_HZ
        self.turn_period_s = turn_period_s
        self.roughness = roughness  # 0 = idealnie gładkie skręty, 1 = bardzo "szarpane"
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._emit_sample)

    def start(self):
        self._t = 0.0
        self._timer.start(int(self._dt * 1000))
        self.state_changed.emit("streaming")
        self.status_message.emit("Tryb symulacji: generuję sztuczne dane.")
        self.connected.emit(True)

    def stop(self):
        self._timer.stop()
        self.state_changed.emit("stopped")
        self.connected.emit(False)

    def set_roughness(self, value: float):
        """0.0 (dobra technika) .. 1.0 (słaba technika) -- do testów oceny skrętów."""
        self.roughness = max(0.0, min(1.0, value))

    def _emit_sample(self):
        t = self._t
        omega = 2 * math.pi / self.turn_period_s

        # Bazowy, gładki sygnał skrętu (lateral accel + yaw rate)
        lateral_accel = 2.2 * math.sin(omega * t)
        gyro_z = 55.0 * math.cos(omega * t)  # deg/s

        # Szum / "szarpanie" proporcjonalne do roughness -- symuluje zły skręt
        noise_amp = 0.4 + 2.5 * self.roughness
        lateral_accel += random.gauss(0, noise_amp)
        gyro_z += random.gauss(0, noise_amp * 15)

        # Dodatkowe losowe "szarpnięcia" przy złej technice
        if self.roughness > 0.3 and random.random() < 0.02 * self.roughness:
            lateral_accel += random.choice([-1, 1]) * random.uniform(1.0, 2.5)

        accel_x = lateral_accel
        accel_y = 0.3 * math.sin(omega * t * 0.5) + random.gauss(0, 0.1)
        accel_z = 9.81 + random.gauss(0, 0.2)

        gyro_x = random.gauss(0, 3)
        gyro_y = random.gauss(0, 3)

        self.sample_ready.emit(t, accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z)
        self._t += self._dt


class ESP32BLEDataSource(DataSource):
    """
    Prawdziwe źródło danych: ESP32 po Bluetooth BLE (firmware stage2_ble.ino).
    Cała komunikacja działa w osobnym wątku (ble_source.BleWorker), więc GUI
    się nie blokuje. Po utracie połączenia klient sam próbuje połączyć się ponownie.
    """

    def __init__(self, device_name: str = "SKI-IMU", backend=None, parent=None):
        super().__init__(parent)
        self.device_name = device_name
        self._backend = backend
        self._worker = None

    def start(self):
        if self._worker is not None and self._worker.isRunning():
            return
        from ble_source import BleWorker

        worker = BleWorker(self.device_name, backend=self._backend)
        self._worker = worker
        # Przekazujemy dalej tylko sygnały od aktualnego wątku: po stop() spóźnione
        # sygnały starego wątku są odrzucane.
        worker.sample_ready.connect(lambda *a, w=worker: self._forward(w, self.sample_ready, *a))
        worker.message.connect(lambda m, w=worker: self._forward(w, self.status_message, m))
        worker.stats_changed.connect(lambda r, l, w=worker: self._forward(w, self.stats_changed, r, l))
        worker.state_changed.connect(self._on_state)
        worker.start()

    def stop(self):
        worker, self._worker = self._worker, None
        if worker is not None:
            worker.request_stop()
            worker.wait(5000)
        self.state_changed.emit("stopped")
        self.connected.emit(False)

    def _forward(self, worker, signal, *args):
        if worker is self._worker:
            signal.emit(*args)

    def _on_state(self, state: str):
        if self._worker is None:  # po stop() ignorujemy spóźnione sygnały
            return
        self.state_changed.emit(state)
        self.connected.emit(state == "streaming")


class CsvDataSource(DataSource):
    """
    Odtwarza nagranie z pliku CSV tak, jakby płynęło z czujnika (w czasie rzeczywistym
    lub szybciej). Pozwala testować całą aplikację na prawdziwych danych bez sprzętu.
    Po ostatniej próbce emituje finished().
    """

    TICK_MS = 20

    def __init__(self, samples=None, speed: float = 1.0, parent=None):
        super().__init__(parent)
        self._samples = list(samples or [])
        self.speed = speed
        self._pos = 0
        self._clock = 0.0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)

    def load(self, samples):
        self._samples = list(samples)

    def start(self):
        if not self._samples:
            self.status_message.emit("Brak danych do odtworzenia.")
            self.finished.emit()
            return
        self._pos = 0
        self._clock = self._samples[0][0]
        self._timer.start(self.TICK_MS)
        self.state_changed.emit("streaming")
        dur = self._samples[-1][0] - self._samples[0][0]
        self.status_message.emit(f"Odtwarzam plik CSV: {len(self._samples)} próbek, {dur:.0f} s.")
        self.connected.emit(True)

    def stop(self):
        self._timer.stop()
        self.state_changed.emit("stopped")
        self.connected.emit(False)

    def _tick(self):
        self._clock += self.TICK_MS / 1000.0 * self.speed
        samples = self._samples
        while self._pos < len(samples) and samples[self._pos][0] <= self._clock:
            self.sample_ready.emit(*samples[self._pos])
            self._pos += 1
        if self._pos >= len(samples):
            self._timer.stop()
            self.finished.emit()
