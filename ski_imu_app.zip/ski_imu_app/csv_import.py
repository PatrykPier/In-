"""
csv_import.py

Wczytywanie nagrań CSV (np. skopiowanych z Serial Monitora Arduino) do formatu
aplikacji: lista krotek (t [s], ax, ay, az [m/s^2], gx, gy, gz [deg/s]).

Parser jest tolerancyjny:
  * separator: przecinek, średnik, tabulator albo spacje,
  * linie nagłówka, komentarze i śmieci z Serial Monitora są pomijane,
  * 7 kolumn = czas + 6 osi, 6 kolumn = same osie (czas liczony z 50 Hz),
  * czas w milisekundach lub sekundach (wykrywany po medianie odstępu),
  * jednostki: m/s^2 + deg/s albo surowe LSB (wykrywane po wartości az ~ 1 g),
  * przepełnienie uint32 czasu oraz cofnięcie się zegara są obsługiwane.
"""

from __future__ import annotations

import re
from statistics import median

from ble_source import ACC_LSB_PER_G, GYR_LSB_PER_DPS, G, SAMPLE_PERIOD_MS

_NUM = re.compile(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?")


class CsvFormatError(ValueError):
    pass


def _parse_line(line: str):
    line = line.strip()
    if not line or line.startswith(("#", "//")):
        return None
    if ";" in line:   # polski Excel: średnik jako separator, przecinek jako ułamek dziesiętny
        parts = [p.strip().replace(",", ".") for p in line.split(";")]
        parts = [p for p in parts if p != ""]
    else:
        parts = [p for p in re.split(r"[\t, ]+", line) if p != ""]
    vals = []
    for p in parts:
        if not _NUM.fullmatch(p):
            return None
        vals.append(float(p))
    return vals


def parse_csv_text(text: str, units: str = "auto"):
    """
    units: "auto" | "si" (m/s^2, deg/s) | "raw" (LSB jak w pakiecie BLE).
    Zwraca listę (t, ax, ay, az, gx, gy, gz); t zaczyna się od 0.
    """
    rows = []
    for line in text.splitlines():
        v = _parse_line(line)
        if v is not None:
            rows.append(v)
    if len(rows) < 2:
        raise CsvFormatError("Nie znaleziono danych liczbowych w pliku.")

    width = max(set(len(r) for r in rows), key=[len(r) for r in rows].count)  # najczęstsza liczba kolumn
    rows = [r for r in rows if len(r) == width]
    if width not in (6, 7):
        raise CsvFormatError(f"Oczekiwano 6 lub 7 kolumn (czas + 6 osi), znaleziono {width}.")
    if len(rows) < 2:
        raise CsvFormatError("Za mało poprawnych wierszy.")

    if width == 7:
        raw_t = [r[0] for r in rows]
        axes = [r[1:] for r in rows]
        diffs = [b - a for a, b in zip(raw_t, raw_t[1:]) if b > a]
        if not diffs:
            raise CsvFormatError("Kolumna czasu nie rośnie.")
        scale = 1000.0 if median(diffs) >= 1.0 else 1.0   # ms vs s
        t = _unwrap_time(raw_t, scale)
    else:
        axes = [r for r in rows]
        t = [i * SAMPLE_PERIOD_MS / 1000.0 for i in range(len(rows))]

    if units == "auto":
        med_az = median(abs(a[2]) for a in axes)
        med_ay = median(abs(a[1]) for a in axes)
        med_ax = median(abs(a[0]) for a in axes)
        units = "raw" if max(med_ax, med_ay, med_az) > 100 else "si"
    if units == "raw":
        k_a, k_g = G / ACC_LSB_PER_G, 1.0 / GYR_LSB_PER_DPS
    else:
        k_a = k_g = 1.0

    t0 = t[0]
    return [
        (ti - t0, a[0] * k_a, a[1] * k_a, a[2] * k_a, a[3] * k_g, a[4] * k_g, a[5] * k_g)
        for ti, a in zip(t, axes)
    ]


def _unwrap_time(raw_t, scale):
    """Czas w sekundach, rosnący: obsługa przepełnienia uint32 i resetu ESP32 (czas się cofa)."""
    out, offset, prev = [], 0.0, None
    for x in raw_t:
        if prev is not None and x < prev:
            if prev > 2 ** 31 and scale == 1000.0 and x < 2 ** 31:   # przepełnienie uint32 millis()
                offset += 2 ** 32
            else:                                                       # reset licznika: doklej od ostatniego czasu
                offset += prev - x + (SAMPLE_PERIOD_MS if scale == 1000.0 else SAMPLE_PERIOD_MS / 1000.0)
        prev = x
        out.append((x + offset) / scale)
    return out


def parse_csv_file(path: str, units: str = "auto"):
    for enc in ("utf-8-sig", "cp1250", "latin-1"):
        try:
            with open(path, encoding=enc) as f:
                return parse_csv_text(f.read(), units)
        except UnicodeDecodeError:
            continue
    raise CsvFormatError("Nie można odczytać pliku (nieznane kodowanie).")
