"""
data_analysis.py

Filtracja sygnału, wykrywanie skrętów oraz ocena ich jakości
metodami regułowymi (bez uczenia maszynowego -- zgodnie z zakresem
pracy, rozdz. 3.3-3.6 planu).
"""

from __future__ import annotations
import math
from dataclasses import dataclass


def moving_average(values: list[float], window: int = 5) -> list[float]:
    """Prosty filtr dolnoprzepustowy do odszumiania danych IMU."""
    if window <= 1 or len(values) < window:
        return list(values)
    out = []
    acc = sum(values[:window])
    out.extend([values[i] for i in range(window - 1)])  # brzeg bez filtracji
    out.append(acc / window)
    for i in range(window, len(values)):
        acc += values[i] - values[i - window]
        out.append(acc / window)
    return out


def roll_angle_deg(ax: float, az: float) -> float:
    """
    Przybliżony kąt przechylenia (edge angle) z akcelerometru.
    Przy czujniku na bucie/goleni odpowiada w przybliżeniu kątowi
    nachylenia narty na krawędź.
    """
    return math.degrees(math.atan2(ax, az))


@dataclass
class Turn:
    index: int
    start_t: float
    end_t: float
    direction: str  # "left" / "right"
    score: float  # 0-100, wyższy = lepszy (płynniejszy) skręt
    max_lateral_accel: float
    max_edge_angle: float


def detect_turns(t: list[float], gyro_z: list[float], accel_x: list[float],
                  min_turn_duration: float = 0.5, min_peak_dps: float = 15.0) -> list[Turn]:
    """
    Wykrywanie skrętów po zmianie znaku prędkości kątowej (oś Z żyroskopu), z histerezą.

    Zwykłe przejście przez zero daje fałszywe skręty, gdy sygnał drży wokół zera.
    Dlatego kierunek obrotu zmienia się dopiero wtedy, gdy sygnał przekroczy próg
    przeciwnego znaku (+-T). Granicą skrętu jest ostatnie przejście przez zero
    przed tym potwierdzeniem. Próg T = max(min_peak_dps, 25% z 95. percentyla |gyro|),
    więc dopasowuje się do tempa jazdy. Odrzucane są skręty krótsze niż min_turn_duration oraz segmenty,
    w których średnia |gyro| jest mała (szum).
    """
    turns: list[Turn] = []
    n = len(gyro_z)
    if n < 3 or len(t) != n:
        return turns

    mags = sorted(abs(g) for g in gyro_z)
    p95 = mags[min(n - 1, int(0.95 * n))]
    thr = max(min_peak_dps, 0.25 * p95)

    boundaries: list[int] = []   # indeksy granic między kolejnymi półcyklami
    cur_sign = 0
    last_cross = 0
    for i, g in enumerate(gyro_z):
        if i > 0 and gyro_z[i - 1] != 0 and (gyro_z[i - 1] > 0) != (g > 0):
            last_cross = i
        if g >= thr:
            new_sign = 1
        elif g <= -thr:
            new_sign = -1
        else:
            continue
        if new_sign != cur_sign:
            if cur_sign != 0:
                boundaries.append(last_cross)
            cur_sign = new_sign

    turn_idx = 0
    for k in range(len(boundaries) - 1):
        i_start, i_end = boundaries[k], boundaries[k + 1]
        if i_end - i_start < 2:
            continue
        start_t, end_t = t[i_start], t[i_end]
        if end_t - start_t < min_turn_duration:
            continue

        segment_gyro = gyro_z[i_start:i_end + 1]
        # odrzucamy "skręty" będące szumem między pojedynczymi skokami sygnału
        if sum(abs(g) for g in segment_gyro) / len(segment_gyro) < 0.5 * thr:
            continue
        segment_accel = accel_x[i_start:i_end + 1]
        segment_t = t[i_start:i_end + 1]

        direction = "right" if sum(segment_gyro) >= 0 else "left"
        score, max_lat, max_edge = score_turn(segment_t, segment_accel)

        turns.append(
            Turn(
                index=turn_idx,
                start_t=start_t,
                end_t=end_t,
                direction=direction,
                score=score,
                max_lateral_accel=max_lat,
                max_edge_angle=max_edge,
            )
        )
        turn_idx += 1

    return turns


def _centered_moving_average(values: list[float], half: int) -> list[float]:
    """Średnia ruchoma wycentrowana (okno 2*half+1, na brzegach okno się zawęża)."""
    n = len(values)
    prefix = [0.0]
    for v in values:
        prefix.append(prefix[-1] + v)
    out = []
    for i in range(n):
        lo, hi = max(0, i - half), min(n - 1, i + half)
        out.append((prefix[hi + 1] - prefix[lo]) / (hi - lo + 1))
    return out


# Stałe oceny skrętu (heurystyka; do zwalidowania na danych z prawdziwej jazdy)
SMOOTH_WINDOW_S = 0.2     # okno wygładzania: wszystko szybsze niż ~5 Hz to "szarpanie"
ROUGHNESS_FOR_ZERO = 0.4  # chropowatość (RMS szarpania / amplituda skrętu), przy której ocena = 0
MIN_AMPLITUDE = 1.0       # m/s^2, dolna granica amplitudy w mianowniku (cisza nie daje dzielenia przez ~0)


def score_turn(segment_t: list[float], segment_accel_x: list[float]) -> tuple[float, float, float]:
    """
    Ocena jakości skrętu w skali 0-100 na podstawie "chropowatości" przyspieszenia
    bocznego: płynny, łukowaty przebieg = wysoki wynik ("Good Turn" z planu pracy),
    drobne, szybkie szarpnięcia = niski wynik ("Bad Turn").

    Chropowatość = RMS składowej szybkozmiennej (sygnał minus jego wygładzenie
    ~0,2 s) podzielone przez amplitudę skrętu. Jest bezwymiarowa, więc nie zależy
    od częstotliwości próbkowania ani od tego, jak mocny jest skręt (wcześniejsza
    wersja liczyła odchylenie standardowe pochodnej, które rosło z szumem
    i częstotliwością próbkowania, więc nawet czysty łuk dostawał niską ocenę).
    """
    if len(segment_accel_x) < 3 or len(segment_t) != len(segment_accel_x):
        return 0.0, 0.0, 0.0

    span = segment_t[-1] - segment_t[0]
    if span <= 0:
        return 0.0, 0.0, 0.0
    dt = span / (len(segment_t) - 1)
    half = max(1, round(SMOOTH_WINDOW_S / dt / 2))

    smooth = _centered_moving_average(segment_accel_x, half)
    resid_rms = math.sqrt(sum((x - m) ** 2 for x, m in zip(segment_accel_x, smooth)) / len(segment_accel_x))
    max_lateral_accel = max(abs(v) for v in segment_accel_x)

    roughness = resid_rms / max(max_lateral_accel, MIN_AMPLITUDE)
    score = max(0.0, min(100.0, 100.0 * (1.0 - roughness / ROUGHNESS_FOR_ZERO)))

    max_edge_angle = math.degrees(math.atan2(max_lateral_accel, 9.81))
    return round(score, 1), round(max_lateral_accel, 2), round(max_edge_angle, 1)


def session_summary(turns: list[Turn]) -> dict:
    """Zbiorcze statystyki sesji do zakładki wyników."""
    if not turns:
        return {
            "turn_count": 0, "avg_score": 0, "left_count": 0, "right_count": 0,
            "avg_duration": 0, "max_lateral_accel": 0,
        }
    durations = [tu.end_t - tu.start_t for tu in turns]
    return {
        "turn_count": len(turns),
        "avg_score": round(sum(tu.score for tu in turns) / len(turns), 1),
        "left_count": sum(1 for tu in turns if tu.direction == "left"),
        "right_count": sum(1 for tu in turns if tu.direction == "right"),
        "avg_duration": round(sum(durations) / len(durations), 2),
        "max_lateral_accel": round(max(tu.max_lateral_accel for tu in turns), 2),
    }


# ---------------------------------------------------------------------- #
# Dodatkowe metryki (rytm, symetria, pochylenie, intensywność, wibracje,
# klasyfikacja stylu) -- wszystko liczone z już zebranych danych, bez
# dodatkowego sprzętu.
# ---------------------------------------------------------------------- #

def compute_rhythm(turns: list[Turn]) -> dict:
    """Kadencja (skręty/min) i równość rytmu (0-100, wyżej = bardziej miarowo)."""
    if len(turns) < 2:
        return {"cadence_per_min": 0.0, "rhythm_consistency": 0.0}
    intervals = [turns[i + 1].start_t - turns[i].start_t for i in range(len(turns) - 1)]
    mean_iv = sum(intervals) / len(intervals)
    cadence = 60.0 / mean_iv if mean_iv > 0 else 0.0
    variance = sum((iv - mean_iv) ** 2 for iv in intervals) / len(intervals)
    std = math.sqrt(variance)
    consistency = max(0.0, 100.0 - (std / mean_iv * 100.0)) if mean_iv > 0 else 0.0
    return {"cadence_per_min": round(cadence, 1), "rhythm_consistency": round(min(100.0, consistency), 0)}


def compute_symmetry(turns: list[Turn]) -> float:
    """Symetria lewo/prawo (0-100, wyżej = bardziej symetrycznie)."""
    left = [tu.score for tu in turns if tu.direction == "left"]
    right = [tu.score for tu in turns if tu.direction == "right"]
    if not left or not right:
        return 100.0
    diff = abs(sum(left) / len(left) - sum(right) / len(right))
    return round(max(0.0, 100.0 - diff * 2), 0)


def compute_pitch_deg(accel_y: list[float], accel_z: list[float]) -> float:
    """Średni kąt pochylenia przód/tył (pitch) w stopniach, z osi Y/Z akcelerometru."""
    if not accel_y:
        return 0.0
    vals = [math.degrees(math.atan2(y, z)) for y, z in zip(accel_y, accel_z)]
    return round(sum(vals) / len(vals), 1)


def compute_intensity(accel_x: list[float], accel_y: list[float], accel_z: list[float]) -> float:
    """Intensywność/dynamika jazdy (0-100) na podstawie energii sygnału (RMS)."""
    if not accel_x:
        return 0.0
    mags = [math.sqrt(x * x + y * y + (z - 9.81) ** 2) for x, y, z in zip(accel_x, accel_y, accel_z)]
    rms = math.sqrt(sum(m * m for m in mags) / len(mags))
    return round(min(100.0, rms * 25.0), 0)


def compute_vibration(accel_z: list[float]) -> float:
    """Poziom drgań/wibracji terenu (0-100) na podstawie szumu wysokoczęstotliwościowego."""
    if len(accel_z) < 5:
        return 0.0
    filtered = moving_average(accel_z, window=5)
    diffs = [abs(a - f) for a, f in zip(accel_z, filtered)]
    noise = sum(diffs) / len(diffs)
    return round(min(100.0, noise * 40.0), 0)


def classify_style(avg_score: float, intensity: float, vibration: float) -> str:
    """Klasyfikacja regułowa stylu jazdy (bez ML), na podstawie progów."""
    if avg_score >= 75 and vibration < 35:
        return "Zrównoważony"
    if intensity >= 65:
        return "Dynamiczny"
    if avg_score < 50 or vibration >= 55:
        return "Niestabilny"
    return "Zachowawczy"


def full_session_analysis(t: list[float], accel_x: list[float], accel_y: list[float],
                           accel_z: list[float], gyro_z: list[float], turns: list[Turn]) -> dict:
    """Komplet metryk sesji do zakładki 'Raport' (łączy wszystkie powyższe funkcje)."""
    base = session_summary(turns)
    rhythm = compute_rhythm(turns)
    symmetry = compute_symmetry(turns)
    pitch = compute_pitch_deg(accel_y, accel_z)
    intensity = compute_intensity(accel_x, accel_y, accel_z)
    vibration = compute_vibration(accel_z)
    avg_edge_angle = round(sum(tu.max_edge_angle for tu in turns) / len(turns), 1) if turns else 0.0
    style = classify_style(base["avg_score"], intensity, vibration)

    # płynność/stabilność jako procent 0-100 do pasków jakości
    fluency_pct = base["avg_score"]  # już 0-100
    stability_pct = round(max(0.0, 100.0 - vibration), 0)

    result = {
        **base,
        "cadence_per_min": rhythm["cadence_per_min"],
        "rhythm_consistency": rhythm["rhythm_consistency"],
        "symmetry": symmetry,
        "pitch_deg": pitch,
        "intensity": intensity,
        "vibration": vibration,
        "avg_edge_angle": avg_edge_angle,
        "style_label": style,
        "fluency_pct": fluency_pct,
        "stability_pct": stability_pct,
        "duration_s": round(t[-1] - t[0], 1) if t else 0.0,
    }
    result.update(compute_skisense_index(result))
    return result


def compute_skisense_index(a: dict) -> dict:
    """
    SkiSense Index (SSI) -- jeden zbiorczy wskaźnik techniki, inspirowany
    podejściem Carv (Ski:IQ): pojedyncza, łatwa do zapamiętania liczba,
    rozbita na 4 kategorie umiejętności. Skala: ~70 (początkujący) --
    ~160 (bardzo zaawansowany), przeciętny rekreacyjny narciarz ~100-110.
    Własna nazwa i skala -- nie jest to produkt ani znak towarowy Carv.
    """
    balance_pct = a.get("stability_pct", 0.0)
    edge_pct = min(100.0, (a.get("avg_edge_angle", 0.0) / 25.0) * 100.0)
    turn_shape_pct = a.get("fluency_pct", 0.0)
    rhythm_pct = a.get("rhythm_consistency", 0.0)

    composite = balance_pct * 0.25 + edge_pct * 0.25 + turn_shape_pct * 0.30 + rhythm_pct * 0.20
    ssi = round(70 + composite * 0.9)

    return {
        "ssi": ssi,
        "balance_pct": round(balance_pct, 0),
        "edge_pct": round(edge_pct, 0),
        "turn_shape_pct": round(turn_shape_pct, 0),
        "rhythm_pct": round(rhythm_pct, 0),
    }
