"""
ble_source.py

Klient Bluetooth BLE dla ESP32 z firmware'u `stage2_ble.ino`.

Format pakietu (16 bajtów, little-endian), wysyłany jako notify co 20 ms:
    uint32 t_ms          -- millis() z ESP32
    int16  ax, ay, az    -- surowe, 4096 LSB/g   (zakres +-8 g)
    int16  gx, gy, gz    -- surowe, 65.5 LSB/(deg/s), offset już odjęty w ESP32

Tu następuje przeliczenie na m/s^2 i deg/s.

Dlaczego osobny wątek (QThread + asyncio)?
  * `bleak` jest biblioteką asynchroniczną,
  * na Windows backend WinRT nie działa poprawnie w głównym wątku Qt (STA),
    więc BLE musi żyć we własnym wątku z własną pętlą zdarzeń,
  * GUI nigdy nie czeka na skanowanie ani łączenie.

Backend (skanowanie + klient) jest wstrzykiwany, dzięki czemu cały przepływ
(skan -> połączenie -> notify -> utrata połączenia -> ponowne łączenie) da się
przetestować bez sprzętu (patrz tests/test_ble.py).
"""

from __future__ import annotations

import asyncio
import struct
from typing import Optional

from PyQt5.QtCore import QThread, pyqtSignal

SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
CHAR_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"
DEVICE_NAME = "SKI-IMU"

PACKET_FORMAT = "<Ihhhhhh"
PACKET_SIZE = struct.calcsize(PACKET_FORMAT)  # 16

ACC_LSB_PER_G = 4096.0   # zakres +-8 g
GYR_LSB_PER_DPS = 65.5   # zakres +-500 deg/s
G = 9.81

SAMPLE_PERIOD_MS = 20    # 50 Hz, jak w firmware
GAP_THRESHOLD_MS = 30    # odstęp większy niż to = zgubione pakiety


def decode_packet(data: bytes) -> tuple[int, float, float, float, float, float, float]:
    """Dekoduje pakiet z ESP32 -> (t_ms, ax, ay, az [m/s^2], gx, gy, gz [deg/s])."""
    if len(data) != PACKET_SIZE:
        raise ValueError(f"Zła długość pakietu: {len(data)} B (oczekiwano {PACKET_SIZE} B)")
    t_ms, ax, ay, az, gx, gy, gz = struct.unpack(PACKET_FORMAT, bytes(data))
    return (
        t_ms,
        ax / ACC_LSB_PER_G * G,
        ay / ACC_LSB_PER_G * G,
        az / ACC_LSB_PER_G * G,
        gx / GYR_LSB_PER_DPS,
        gy / GYR_LSB_PER_DPS,
        gz / GYR_LSB_PER_DPS,
    )


def encode_packet(t_ms: int, ax: int, ay: int, az: int, gx: int, gy: int, gz: int) -> bytes:
    """Odwrotność dekodera (surowe wartości) -- używana w testach i atrapie ESP32."""
    return struct.pack(PACKET_FORMAT, t_ms & 0xFFFFFFFF, ax, ay, az, gx, gy, gz)


class TimeBase:
    """
    Zamienia millis() z ESP32 na sekundy od pierwszej próbki.
    Obsługuje przepełnienie uint32 (po ok. 49 dniach pracy).
    """

    def __init__(self):
        self._t0: Optional[int] = None
        self._last: Optional[int] = None
        self._wraps = 0

    def to_seconds(self, t_ms: int) -> float:
        if self._last is not None and t_ms < self._last and (self._last - t_ms) > 2 ** 31:
            self._wraps += 1
        self._last = t_ms
        total = t_ms + self._wraps * 2 ** 32
        if self._t0 is None:
            self._t0 = total
        return (total - self._t0) / 1000.0


# -------------------------------------------------------------------- #
# Backend prawdziwy (bleak) -- importowany leniwie, żeby aplikacja działała
# w trybie symulacji nawet bez zainstalowanego bleak.
# -------------------------------------------------------------------- #
class BleakBackend:
    async def find_device(self, name: str, service_uuid: str, timeout: float):
        from bleak import BleakScanner

        wanted_uuid = service_uuid.lower()

        def match(device, adv):
            uuids = [u.lower() for u in (adv.service_uuids or [])]
            dev_name = device.name or adv.local_name
            return wanted_uuid in uuids or dev_name == name

        return await BleakScanner.find_device_by_filter(match, timeout=timeout)

    def make_client(self, device, disconnected_callback):
        from bleak import BleakClient

        return BleakClient(device, disconnected_callback=disconnected_callback)


class BleWorker(QThread):
    """
    Wątek BLE: skanuje, łączy się, subskrybuje notify i emituje próbki.
    Po utracie połączenia sam próbuje połączyć się ponownie, dopóki nie
    zostanie zatrzymany przez request_stop().

    Stany (state_changed): scanning, connecting, streaming, disconnected, stopped.
    """

    sample_ready = pyqtSignal(float, float, float, float, float, float, float)
    state_changed = pyqtSignal(str)
    message = pyqtSignal(str)
    stats_changed = pyqtSignal(int, int)  # (odebrane pakiety, zgubione pakiety)

    def __init__(self, device_name: str = DEVICE_NAME, backend=None,
                 scan_timeout: float = 8.0, connect_timeout: float = 10.0,
                 retry_delay: float = 2.0, parent=None):
        super().__init__(parent)
        self.device_name = device_name
        self.backend = backend or BleakBackend()
        self.scan_timeout = scan_timeout
        self.connect_timeout = connect_timeout
        self.retry_delay = retry_delay

        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._stop_event: Optional[asyncio.Event] = None
        self._stop_requested = False

        self._time = TimeBase()
        self._last_t_ms: Optional[int] = None
        self.received = 0
        self.lost = 0
        self.bad_packets = 0

    # ---------------------------------------------------------------- #
    # API wywoływane z wątku GUI
    # ---------------------------------------------------------------- #
    def request_stop(self):
        self._stop_requested = True
        loop, ev = self._loop, self._stop_event
        if loop is not None and ev is not None:
            loop.call_soon_threadsafe(ev.set)

    # ---------------------------------------------------------------- #
    # Wątek
    # ---------------------------------------------------------------- #
    def run(self):
        try:
            asyncio.run(self._main())
        except Exception as exc:  # np. brak bleak, wyłączony Bluetooth w systemie
            self.message.emit(f"Błąd BLE: {exc}")
        finally:
            self.state_changed.emit("stopped")

    async def _until_stop(self, coro):
        """Czeka na coro, ale przerywa je, gdy ktoś zażąda zatrzymania. Zwraca None po stopie."""
        task = asyncio.ensure_future(coro)
        stop = asyncio.ensure_future(self._stop_event.wait())
        done, _ = await asyncio.wait({task, stop}, return_when=asyncio.FIRST_COMPLETED)
        if task in done:
            stop.cancel()
            return task.result()
        task.cancel()
        try:
            await task
        except (asyncio.CancelledError, Exception):
            pass
        return None

    async def _main(self):
        self._loop = asyncio.get_running_loop()
        self._stop_event = asyncio.Event()
        if self._stop_requested:
            self._stop_event.set()

        while not self._stop_event.is_set():
            self.state_changed.emit("scanning")
            self.message.emit(f"Szukam urządzenia {self.device_name}...")
            try:
                device = await self._until_stop(
                    self.backend.find_device(self.device_name, SERVICE_UUID, self.scan_timeout)
                )
            except Exception as exc:
                self.message.emit(f"Błąd skanowania: {exc}")
                device = None

            if self._stop_event.is_set():
                break
            if device is None:
                self.message.emit("Nie znaleziono urządzenia. Sprawdź, czy ESP32 jest włączone.")
                await self._until_stop(asyncio.sleep(self.retry_delay))
                continue

            try:
                await self._stream(device)
            except Exception as exc:
                self.message.emit(f"Błąd połączenia: {exc}")

            if self._stop_event.is_set():
                break
            self.state_changed.emit("disconnected")
            self.message.emit("Połączenie utracone. Próbuję połączyć ponownie...")
            await self._until_stop(asyncio.sleep(self.retry_delay))

    async def _stream(self, device):
        disconnected = asyncio.Event()

        def on_disconnected(_client):
            self._loop.call_soon_threadsafe(disconnected.set)

        client = self.backend.make_client(device, on_disconnected)
        self.state_changed.emit("connecting")
        self.message.emit("Łączę z urządzeniem...")
        await asyncio.wait_for(client.connect(), timeout=self.connect_timeout)
        try:
            self._last_t_ms = None  # po ponownym połączeniu nie liczymy przerwy jako zgubionych pakietów
            await client.start_notify(CHAR_UUID, self._on_notify)
            self.state_changed.emit("streaming")
            self.message.emit("Połączono. Odbieram dane z czujnika.")
            await self._until_stop(disconnected.wait())
            if client.is_connected:
                try:
                    await client.stop_notify(CHAR_UUID)
                except Exception:
                    pass
        finally:
            try:
                await client.disconnect()
            except Exception:
                pass

    # ---------------------------------------------------------------- #
    # Odbiór pakietów (wywoływane w wątku BLE)
    # ---------------------------------------------------------------- #
    def _on_notify(self, _sender, data):
        try:
            t_ms, ax, ay, az, gx, gy, gz = decode_packet(data)
        except ValueError:
            self.bad_packets += 1
            return

        if self._last_t_ms is not None:
            dt = (t_ms - self._last_t_ms) & 0xFFFFFFFF
            if dt > GAP_THRESHOLD_MS:
                self.lost += max(0, round(dt / SAMPLE_PERIOD_MS) - 1)
        self._last_t_ms = t_ms

        self.received += 1
        self.sample_ready.emit(self._time.to_seconds(t_ms), ax, ay, az, gx, gy, gz)
        if self.received % 50 == 0:
            self.stats_changed.emit(self.received, self.lost)
