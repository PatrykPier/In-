# SkiSense — analiza jazdy na nartach (ESP32 + IMU ICM-20602)

Aplikacja desktopowa (PyQt5) oraz wersja webowa na telefon (Web Bluetooth, Android/Chrome).

## Uruchomienie (Windows / Linux)
```
pip install -r requirements.txt
python main.py
```
Bez sprzętu: w zakładce „Trening” wybierz źródło **Symulacja** albo **Plik CSV** (np. `sample_data/przykladowy_zjazd.csv`).
Z czujnikiem: źródło **BLE** (urządzenie `SKI-IMU`).

## Testy
```
python -m unittest discover -s tests          # 82 testy Pythona
cd web && node --test tests/*.test.mjs        # 27 testów JS
```
Test dymny: `python main.py --smoke-test`.

## Plik .exe (Windows)
Uruchom `build_exe.bat` — tworzy venv, instaluje zależności, odpala testy i buduje `dist\SkiSense\SkiSense.exe`.
Dane użytkownika: `%APPDATA%\SkiSense`.

## Wersja na telefon
Katalog `web/` — patrz `web/README.md` (hosting np. GitHub Pages, wymagany https).

## Kalibracja i osie
Przed jazdą: czujnik nieruchomo ~3 s → „Kalibruj”. Jeśli osie czujnika nie pasują do butu, użyj „Osie…”.

## Ograniczenia
Progi oceny skrętów są heurystyczne (dostrojone na symulatorze) — wymagają walidacji na prawdziwych danych.
Ścieżka BLE nie była jeszcze testowana z fizycznym ESP32.
