// ble.js — połączenie Web Bluetooth z ESP32 (z automatycznym ponawianiem) oraz symulator do trybu demo.
// Wszystko, co dotyka przeglądarki, jest wstrzykiwane (bluetooth, setTimeout), więc da się testować w Node.

import { SERVICE_UUID, CHAR_UUID, DEVICE_NAME, decodePacket, TimeBase, GAP_THRESHOLD_MS, SAMPLE_PERIOD_MS } from "./signal.js";

/**
 * Klient BLE. Zdarzenia: onSample({t, ax..gz}), onState(stan), onMessage(tekst), onStats(odebrane, zgubione).
 * Stany: scanning, connecting, streaming, disconnected, stopped.
 * requestDevice() musi być wywołane z gestu użytkownika (kliknięcie), dlatego start() wołamy z onclick.
 */
export class BleClient {
  constructor({ bluetooth = globalThis.navigator?.bluetooth, retryDelayMs = 2000, connectTimeoutMs = 10000,
                onSample = () => {}, onState = () => {}, onMessage = () => {}, onStats = () => {} } = {}) {
    Object.assign(this, { bluetooth, retryDelayMs, connectTimeoutMs, onSample, onState, onMessage, onStats });
    this.device = null; this.characteristic = null;
    this.stopped = true; this.generation = 0;
    this.received = 0; this.lost = 0; this.bad = 0;
    this.time = new TimeBase(); this.lastTMs = null;
    this._handler = (ev) => this._onNotify(ev);
    this._onGattDisconnected = () => this._lost();
  }

  static supported() { return !!globalThis.navigator?.bluetooth; }

  async start() {
    if (!this.bluetooth) throw new Error("Ta przeglądarka nie obsługuje Web Bluetooth. Użyj Chrome na Androidzie.");
    this.stopped = false;
    const gen = ++this.generation;
    this.received = this.lost = this.bad = 0;
    this.time = new TimeBase(); this.lastTMs = null;
    this.onState("scanning");
    this.onMessage(`Wybierz urządzenie ${DEVICE_NAME} z listy…`);
    try {
      this.device = await this.bluetooth.requestDevice({
        filters: [{ name: DEVICE_NAME }, { services: [SERVICE_UUID] }],
        optionalServices: [SERVICE_UUID],
      });
    } catch (e) {            // użytkownik zamknął okno wyboru
      this.stopped = true;
      this.onState("stopped");
      this.onMessage(e?.name === "NotFoundError" ? "Anulowano wybór urządzenia." : `Błąd: ${e?.message ?? e}`);
      return false;
    }
    this.device.addEventListener("gattserverdisconnected", this._onGattDisconnected);
    await this._connectLoop(gen);
    return true;
  }

  async _connectLoop(gen) {
    while (!this.stopped && gen === this.generation) {
      try {
        this.onState("connecting");
        this.onMessage("Łączę z urządzeniem…");
        const server = await this._withTimeout(this.device.gatt.connect(), this.connectTimeoutMs);
        const service = await server.getPrimaryService(SERVICE_UUID);
        const ch = await service.getCharacteristic(CHAR_UUID);
        if (this.stopped || gen !== this.generation) { try { this.device.gatt.disconnect(); } catch {} return; }
        this.lastTMs = null;     // przerwa po rozłączeniu nie jest zgubionymi pakietami
        ch.addEventListener("characteristicvaluechanged", this._handler);
        await ch.startNotifications();
        this.characteristic = ch;
        this.onState("streaming");
        this.onMessage("Połączono. Odbieram dane z czujnika.");
        return;                  // dalej działa zdarzenie gattserverdisconnected
      } catch (e) {
        if (this.stopped || gen !== this.generation) return;
        this.onMessage(`Błąd połączenia: ${e?.message ?? e}`);
        this.onState("disconnected");
        await this._sleep(this.retryDelayMs);
      }
    }
  }

  _lost() {
    if (this.stopped) return;
    try { this.characteristic?.removeEventListener("characteristicvaluechanged", this._handler); } catch {}
    this.characteristic = null;
    this.onState("disconnected");
    this.onMessage("Połączenie utracone. Próbuję połączyć ponownie…");
    const gen = this.generation;
    this._sleep(this.retryDelayMs).then(() => { if (!this.stopped && gen === this.generation) this._connectLoop(gen); });
  }

  _onNotify(ev) {
    let p;
    try { p = decodePacket(ev.target.value); } catch { this.bad++; return; }
    if (this.lastTMs !== null) {
      const dt = (p.tMs - this.lastTMs) >>> 0;
      if (dt > GAP_THRESHOLD_MS) this.lost += Math.max(0, Math.round(dt / SAMPLE_PERIOD_MS) - 1);
    }
    this.lastTMs = p.tMs;
    this.received++;
    this.onSample({ t: this.time.toSeconds(p.tMs), ax: p.ax, ay: p.ay, az: p.az, gx: p.gx, gy: p.gy, gz: p.gz });
    if (this.received % 50 === 0) this.onStats(this.received, this.lost);
  }

  stop() {
    this.stopped = true;
    this.generation++;
    try { this.characteristic?.removeEventListener("characteristicvaluechanged", this._handler); } catch {}
    try { this.device?.removeEventListener("gattserverdisconnected", this._onGattDisconnected); } catch {}
    try { if (this.device?.gatt?.connected) this.device.gatt.disconnect(); } catch {}
    this.characteristic = null;
    this.onState("stopped");
  }

  _sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
  _withTimeout(p, ms) {
    return Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error("Przekroczono czas łączenia")), ms))]);
  }
}

/** Symulator jazdy slalomem (jak SimulatedDataSource w aplikacji desktopowej) — do testów bez sprzętu. */
export class SimSource {
  constructor({ onSample = () => {}, onState = () => {}, onMessage = () => {}, roughness = 0.15 } = {}) {
    Object.assign(this, { onSample, onState, onMessage, roughness });
    this.timer = null; this.t = 0; this.turnPeriod = 2.2;
  }
  static gauss(sd) {
    const u = 1 - Math.random(), v = Math.random();
    return sd * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }
  start() {
    this.t = 0;
    this.timer = setInterval(() => this._emit(), SAMPLE_PERIOD_MS);
    this.onState("streaming");
    this.onMessage("Tryb demo: generuję sztuczne dane.");
  }
  stop() {
    clearInterval(this.timer); this.timer = null;
    this.onState("stopped");
  }
  _emit() {
    const g = SimSource.gauss, om = (2 * Math.PI) / this.turnPeriod, t = this.t, r = this.roughness;
    const noise = 0.4 + 2.5 * r;
    let lat = 2.2 * Math.sin(om * t) + g(noise);
    const gz = 55 * Math.cos(om * t) + g(noise * 15);
    if (r > 0.3 && Math.random() < 0.02 * r) lat += (Math.random() < 0.5 ? -1 : 1) * (1 + 1.5 * Math.random());
    this.onSample({ t, ax: lat, ay: 0.3 * Math.sin(om * t * 0.5) + g(0.1), az: 9.81 + g(0.2),
                    gx: g(3), gy: g(3), gz });
    this.t += SAMPLE_PERIOD_MS / 1000;
  }
}
