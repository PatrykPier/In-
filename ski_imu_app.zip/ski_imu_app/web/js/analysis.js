// analysis.js — port data_analysis.py (te same reguły i progi co w aplikacji desktopowej).
// Czysty JavaScript bez zależności: działa w przeglądarce i w Node (testy zgodności z Pythonem).

export const G = 9.81;

/** Zaokrąglanie jak w Pythonie (do parzystej przy .5), żeby wyniki zgadzały się z wersją desktopową. */
export function pyRound(x, nd = 0) {
  const f = 10 ** nd;
  const v = x * f;
  const r = Math.round(v);
  const exactHalf = Math.abs(v - Math.trunc(v)) === 0.5;
  const out = exactHalf && r % 2 !== 0 ? r - 1 : r;
  return out / f;
}

export function movingAverage(values, window = 5) {
  if (window <= 1 || values.length < window) return values.slice();
  const out = [];
  let acc = 0;
  for (let i = 0; i < window; i++) acc += values[i];
  for (let i = 0; i < window - 1; i++) out.push(values[i]); // brzeg bez filtracji
  out.push(acc / window);
  for (let i = window; i < values.length; i++) {
    acc += values[i] - values[i - window];
    out.push(acc / window);
  }
  return out;
}

function centeredMovingAverage(values, half) {
  const n = values.length, prefix = [0];
  for (const v of values) prefix.push(prefix[prefix.length - 1] + v);
  const out = new Array(n);
  for (let i = 0; i < n; i++) {
    const lo = Math.max(0, i - half), hi = Math.min(n - 1, i + half);
    out[i] = (prefix[hi + 1] - prefix[lo]) / (hi - lo + 1);
  }
  return out;
}

// Stałe oceny skrętu (heurystyka; te same co w data_analysis.py)
const SMOOTH_WINDOW_S = 0.2;
const ROUGHNESS_FOR_ZERO = 0.4;
const MIN_AMPLITUDE = 1.0;

/** Ocena skrętu 0-100 z chropowatości przyspieszenia bocznego (patrz score_turn w Pythonie). */
export function scoreTurn(segT, segAccX) {
  if (segAccX.length < 3 || segT.length !== segAccX.length) return [0, 0, 0];
  const span = segT[segT.length - 1] - segT[0];
  if (span <= 0) return [0, 0, 0];
  const dt = span / (segT.length - 1);
  const half = Math.max(1, pyRound(SMOOTH_WINDOW_S / dt / 2, 0));
  const smooth = centeredMovingAverage(segAccX, half);
  let sq = 0, maxLat = 0;
  for (let i = 0; i < segAccX.length; i++) {
    sq += (segAccX[i] - smooth[i]) ** 2;
    maxLat = Math.max(maxLat, Math.abs(segAccX[i]));
  }
  const residRms = Math.sqrt(sq / segAccX.length);
  const roughness = residRms / Math.max(maxLat, MIN_AMPLITUDE);
  const score = Math.max(0, Math.min(100, 100 * (1 - roughness / ROUGHNESS_FOR_ZERO)));
  const maxEdge = (Math.atan2(maxLat, G) * 180) / Math.PI;
  return [pyRound(score, 1), pyRound(maxLat, 2), pyRound(maxEdge, 1)];
}

/**
 * Wykrywanie skrętów po zmianie znaku żyroskopu (oś Z), z histerezą:
 * kierunek zmienia się dopiero po przekroczeniu progu +-T przeciwnego znaku.
 * Zwraca [{index,startT,endT,direction,score,maxLateralAccel,maxEdgeAngle}].
 */
export function detectTurns(t, gyroZ, accelX, minTurnDuration = 0.5, minPeakDps = 15.0) {
  const turns = [];
  const n = gyroZ.length;
  if (n < 3 || t.length !== n) return turns;

  const mags = gyroZ.map(Math.abs).sort((a, b) => a - b);
  const p95 = mags[Math.min(n - 1, Math.trunc(0.95 * n))];
  const thr = Math.max(minPeakDps, 0.25 * p95);

  const boundaries = [];
  let curSign = 0;
  let lastCross = 0;
  for (let i = 0; i < n; i++) {
    const g = gyroZ[i];
    if (i > 0 && gyroZ[i - 1] !== 0 && gyroZ[i - 1] > 0 !== g > 0) lastCross = i;
    let newSign;
    if (g >= thr) newSign = 1;
    else if (g <= -thr) newSign = -1;
    else continue;
    if (newSign !== curSign) {
      if (curSign !== 0) boundaries.push(lastCross);
      curSign = newSign;
    }
  }

  let idx = 0;
  for (let k = 0; k < boundaries.length - 1; k++) {
    const iStart = boundaries[k];
    const iEnd = boundaries[k + 1];
    if (iEnd - iStart < 2) continue;
    const startT = t[iStart];
    const endT = t[iEnd];
    if (endT - startT < minTurnDuration) continue;

    const segG = gyroZ.slice(iStart, iEnd + 1);
    let absSum = 0;
    let sum = 0;
    for (const g of segG) { absSum += Math.abs(g); sum += g; }
    if (absSum / segG.length < 0.5 * thr) continue; // szum między pojedynczymi skokami

    const [score, maxLat, maxEdge] = scoreTurn(t.slice(iStart, iEnd + 1), accelX.slice(iStart, iEnd + 1));
    turns.push({
      index: idx++, startT, endT, direction: sum >= 0 ? "right" : "left",
      score, maxLateralAccel: maxLat, maxEdgeAngle: maxEdge,
    });
  }
  return turns;
}

const mean = (a) => a.reduce((x, y) => x + y, 0) / a.length;

export function sessionSummary(turns) {
  if (!turns.length) {
    return { turnCount: 0, avgScore: 0, leftCount: 0, rightCount: 0, avgDuration: 0, maxLateralAccel: 0 };
  }
  const durs = turns.map((tu) => tu.endT - tu.startT);
  return {
    turnCount: turns.length,
    avgScore: pyRound(mean(turns.map((tu) => tu.score)), 1),
    leftCount: turns.filter((tu) => tu.direction === "left").length,
    rightCount: turns.filter((tu) => tu.direction === "right").length,
    avgDuration: pyRound(mean(durs), 2),
    maxLateralAccel: pyRound(Math.max(...turns.map((tu) => tu.maxLateralAccel)), 2),
  };
}

export function computeRhythm(turns) {
  if (turns.length < 2) return { cadencePerMin: 0, rhythmConsistency: 0 };
  const iv = [];
  for (let i = 0; i < turns.length - 1; i++) iv.push(turns[i + 1].startT - turns[i].startT);
  const m = mean(iv);
  const cadence = m > 0 ? 60 / m : 0;
  const std = Math.sqrt(mean(iv.map((x) => (x - m) ** 2)));
  const consistency = m > 0 ? Math.max(0, 100 - (std / m) * 100) : 0;
  return { cadencePerMin: pyRound(cadence, 1), rhythmConsistency: pyRound(Math.min(100, consistency), 0) };
}

export function computeSymmetry(turns) {
  const left = turns.filter((t) => t.direction === "left").map((t) => t.score);
  const right = turns.filter((t) => t.direction === "right").map((t) => t.score);
  if (!left.length || !right.length) return 100;
  const diff = Math.abs(mean(left) - mean(right));
  return pyRound(Math.max(0, 100 - diff * 2), 0);
}

export function computePitchDeg(ay, az) {
  if (!ay.length) return 0;
  return pyRound(mean(ay.map((y, i) => (Math.atan2(y, az[i]) * 180) / Math.PI)), 1);
}

export function computeIntensity(ax, ay, az) {
  if (!ax.length) return 0;
  const sq = ax.map((x, i) => x * x + ay[i] * ay[i] + (az[i] - G) ** 2);
  const rms = Math.sqrt(mean(sq));
  return pyRound(Math.min(100, rms * 25), 0);
}

export function computeVibration(az) {
  if (az.length < 5) return 0;
  const f = movingAverage(az, 5);
  const noise = mean(az.map((a, i) => Math.abs(a - f[i])));
  return pyRound(Math.min(100, noise * 40), 0);
}

export function classifyStyle(avgScore, intensity, vibration) {
  if (avgScore >= 75 && vibration < 35) return "Zrównoważony";
  if (intensity >= 65) return "Dynamiczny";
  if (avgScore < 50 || vibration >= 55) return "Niestabilny";
  return "Zachowawczy";
}

export function computeSkiSenseIndex(a) {
  const balance = a.stabilityPct ?? 0;
  const edge = Math.min(100, ((a.avgEdgeAngle ?? 0) / 25) * 100);
  const shape = a.fluencyPct ?? 0;
  const rhythm = a.rhythmConsistency ?? 0;
  const composite = balance * 0.25 + edge * 0.25 + shape * 0.3 + rhythm * 0.2;
  return {
    ssi: pyRound(70 + composite * 0.9, 0),
    balancePct: pyRound(balance, 0), edgePct: pyRound(edge, 0),
    turnShapePct: pyRound(shape, 0), rhythmPct: pyRound(rhythm, 0),
  };
}

export function fullSessionAnalysis(t, ax, ay, az, gyroZ, turns) {
  const base = sessionSummary(turns);
  const rhythm = computeRhythm(turns);
  const vibration = computeVibration(az);
  const intensity = computeIntensity(ax, ay, az);
  const avgEdgeAngle = turns.length ? pyRound(mean(turns.map((tu) => tu.maxEdgeAngle)), 1) : 0;
  const result = {
    ...base,
    cadencePerMin: rhythm.cadencePerMin,
    rhythmConsistency: rhythm.rhythmConsistency,
    symmetry: computeSymmetry(turns),
    pitchDeg: computePitchDeg(ay, az),
    intensity, vibration, avgEdgeAngle,
    styleLabel: classifyStyle(base.avgScore, intensity, vibration),
    fluencyPct: base.avgScore,
    stabilityPct: pyRound(Math.max(0, 100 - vibration), 0),
    durationS: t.length ? pyRound(t[t.length - 1] - t[0], 1) : 0,
  };
  return { ...result, ...computeSkiSenseIndex(result) };
}

/** Pełna analiza z surowych próbek (te same filtry co LiveTab._save_session). */
export function analyzeSamples(s) {
  const accF = movingAverage(s.ax, 5);
  const gyrF = movingAverage(s.gz, 5);
  const turns = detectTurns(s.t, gyrF, accF);
  return { turns, analysis: fullSessionAnalysis(s.t, s.ax, s.ay, s.az, gyrF, turns) };
}
