// charts.js — lekkie wykresy na <canvas> (bez bibliotek): wykres na żywo i wykres sesji ze skrętami.

export const COLORS = {
  bg: "#121820", grid: "#1f2733", text: "#c7cdd6", muted: "#8b96a5",
  cyan: "#38bdf8", violet: "#a78bfa", green: "#34d399", amber: "#fbbf24",
};

function fit(canvas) {
  const dpr = Math.min(globalThis.devicePixelRatio || 1, 3);
  const w = canvas.clientWidth, h = canvas.clientHeight;
  if (!w || !h) return null;
  if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
    canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
  }
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { ctx, w, h };
}

function niceRange(lo, hi, minSpan) {
  let span = Math.max(hi - lo, minSpan);
  const mid = (hi + lo) / 2;
  span *= 1.15;
  return [mid - span / 2, mid + span / 2];
}

function drawPanel(ctx, box, title, unit, xs, ys, x0, x1, [lo, hi], color, shading = []) {
  const { x, y, w, h } = box;
  ctx.fillStyle = COLORS.text; ctx.font = "600 11px system-ui, sans-serif"; ctx.textAlign = "center";
  ctx.fillText(title, x + w / 2, y - 10);
  ctx.strokeStyle = COLORS.grid; ctx.lineWidth = 1; ctx.fillStyle = COLORS.muted; ctx.font = "10px system-ui, sans-serif";
  ctx.textAlign = "right";
  for (let i = 0; i <= 4; i++) {                        // poziome linie siatki + opisy osi Y
    const v = lo + ((hi - lo) * i) / 4, py = y + h - (h * i) / 4;
    ctx.beginPath(); ctx.moveTo(x, py); ctx.lineTo(x + w, py); ctx.stroke();
    ctx.fillText(Math.abs(v) >= 100 ? v.toFixed(0) : v.toFixed(1), x - 4, py + 3);
  }
  ctx.textAlign = "left"; ctx.fillText(unit, x - 30, y - 10);
  const sx = (t) => x + ((t - x0) / (x1 - x0)) * w, sy = (v) => y + h - ((v - lo) / (hi - lo)) * h;
  for (const s of shading) {                            // zaznaczone skręty
    ctx.fillStyle = s.color; ctx.fillRect(sx(s.from), y, Math.max(1, sx(s.to) - sx(s.from)), h);
  }
  ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
  if (lo < 0 && hi > 0) { ctx.strokeStyle = "#2b3644"; ctx.beginPath(); ctx.moveTo(x, sy(0)); ctx.lineTo(x + w, sy(0)); ctx.stroke(); }
  ctx.strokeStyle = color; ctx.lineWidth = 1.6; ctx.lineJoin = "round"; ctx.beginPath();
  let first = true;
  for (let i = 0; i < xs.length; i++) {
    const px = sx(xs[i]), py = sy(ys[i]);
    if (first) { ctx.moveTo(px, py); first = false; } else ctx.lineTo(px, py);
  }
  ctx.stroke(); ctx.restore();
}

function xLabels(ctx, box, x0, x1) {
  ctx.fillStyle = COLORS.muted; ctx.font = "10px system-ui, sans-serif"; ctx.textAlign = "center";
  const span = x1 - x0, step = span > 120 ? 30 : span > 40 ? 10 : span > 12 ? 2 : 1;
  for (let t = Math.ceil(x0 / step) * step; t <= x1; t += step) {
    const px = box.x + ((t - x0) / span) * box.w;
    ctx.fillText(String(Math.round(t)), px, box.y + box.h + 13);
  }
  ctx.fillText("Czas [s]", box.x + box.w / 2, box.y + box.h + 26);
}

/** Wykres na żywo: bufor pierścieniowy, okno 8 s, rysowanie najwyżej raz na klatkę. */
export class LiveChart {
  constructor(canvas, { windowS = 8, capacity = 1000 } = {}) {
    Object.assign(this, { canvas, windowS, capacity });
    this.t = new Float64Array(capacity); this.a = new Float64Array(capacity); this.g = new Float64Array(capacity);
    this.n = 0; this.dirty = true; this.raf = null; this.ranges = [[-3, 3], [-60, 60]];
  }
  push(t, accel, gyro) {
    if (this.n === this.capacity) {
      this.t.copyWithin(0, 1); this.a.copyWithin(0, 1); this.g.copyWithin(0, 1); this.n--;
    }
    this.t[this.n] = t; this.a[this.n] = accel; this.g[this.n] = gyro; this.n++;
    this.dirty = true;
  }
  reset() { this.n = 0; this.dirty = true; }
  start() {
    if (this.raf) return;
    const loop = () => { if (this.dirty) this.draw(); this.raf = requestAnimationFrame(loop); };
    this.raf = requestAnimationFrame(loop);
  }
  stop() { if (this.raf) cancelAnimationFrame(this.raf); this.raf = null; }
  draw() {
    const f = fit(this.canvas); if (!f) return;
    this.dirty = false;
    const { ctx, w, h } = f;
    ctx.clearRect(0, 0, w, h);
    const pad = { l: 36, r: 8 }, ph = (h - 78) / 2;
    const boxes = [{ x: pad.l, y: 26, w: w - pad.l - pad.r, h: ph }, { x: pad.l, y: 26 + ph + 36, w: w - pad.l - pad.r, h: ph }];
    const n = this.n, last = n ? this.t[n - 1] : 0, x0 = Math.max(0, last - this.windowS), x1 = x0 + this.windowS;
    let i0 = 0; while (i0 < n && this.t[i0] < x0) i0++;
    const xs = this.t.subarray(i0, n), as = this.a.subarray(i0, n), gs = this.g.subarray(i0, n);
    const rng = (arr, prev, minSpan) => {
      if (!arr.length) return prev;
      let lo = Infinity, hi = -Infinity; for (const v of arr) { if (v < lo) lo = v; if (v > hi) hi = v; }
      const [a, b] = niceRange(lo, hi, minSpan);
      return [prev[0] + (a - prev[0]) * 0.3, prev[1] + (b - prev[1]) * 0.3];   // łagodne dopasowanie skali
    };
    this.ranges = [rng(as, this.ranges[0], 4), rng(gs, this.ranges[1], 60)];
    drawPanel(ctx, boxes[0], "Przyspieszenie boczne (oś X)", "m/s²", xs, as, x0, x1, this.ranges[0], COLORS.cyan);
    drawPanel(ctx, boxes[1], "Prędkość kątowa (oś Z)", "°/s", xs, gs, x0, x1, this.ranges[1], COLORS.violet);
    xLabels(ctx, boxes[1], x0, x1);
  }
}

/** Wykres zapisanej sesji ze skrętami (zielone = prawo, pomarańczowe = lewo). */
export function drawSessionChart(canvas, s, turns, maxPoints = 1500) {
  const f = fit(canvas); if (!f) return;
  const { ctx, w, h } = f;
  ctx.clearRect(0, 0, w, h);
  const n = s.t.length; if (!n) return;
  const step = Math.max(1, Math.floor(n / maxPoints));
  const xs = [], ax = [], gz = [];
  for (let i = 0; i < n; i += step) { xs.push(s.t[i]); ax.push(s.ax[i]); gz.push(s.gz[i]); }
  const ph = (h - 78) / 2, x = 36, bw = w - x - 8;
  const x0 = s.t[0], x1 = s.t[n - 1] || x0 + 1;
  const shade = turns.map((t) => ({ from: t.startT, to: t.endT, color: t.direction === "right" ? "rgba(52,211,153,.14)" : "rgba(251,191,36,.14)" }));
  const range = (arr, span) => { let lo = Math.min(...arr), hi = Math.max(...arr); return niceRange(lo, hi, span); };
  drawPanel(ctx, { x, y: 26, w: bw, h: ph }, "Przyspieszenie boczne (oś X)", "m/s²", xs, ax, x0, x1, range(ax, 4), COLORS.cyan, shade);
  const b2 = { x, y: 26 + ph + 36, w: bw, h: ph };
  drawPanel(ctx, b2, "Prędkość kątowa (oś Z)", "°/s", xs, gz, x0, x1, range(gz, 60), COLORS.violet, shade);
  xLabels(ctx, b2, x0, x1);
}
