// app.js — logika aplikacji SkiSense na telefon (Web Bluetooth + analiza w przeglądarce).
import { BleClient, SimSource } from "./ble.js";
import { applyCalibration, calibrateFromRest, defaultCalibration, axisMapValid, isIdentityMap } from "./signal.js";
import { analyzeSamples } from "./analysis.js";
import { openStore, samplesToCsv } from "./store.js";
import { LiveChart, drawSessionChart } from "./charts.js";

const $ = (s) => document.querySelector(s);
const CALIB_SECONDS = 3;
const STATE_TEXT = {
  scanning: "● Szukam urządzenia…", connecting: "● Łączę…", streaming: "● Urządzenie połączone",
  disconnected: "● Połączenie utracone, ponawiam…", stopped: "● Rozłączono",
};

const app = {
  store: null, persistent: true,
  source: null, kind: "sim", active: false, streaming: false, recording: false,
  buf: null, elapsed: 0, recTimer: null, wakeLock: null,
  calibration: defaultCalibration(), calibBuf: null,
  openId: null, openRecord: null,
};

// ---------------------------------------------------------------- pomocnicze
function toast(msg, ms = 2800) {
  const el = $("#toast");
  el.textContent = msg; el.classList.add("show");
  clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove("show"), ms);
}
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtDur = (s) => { const m = Math.floor(s / 60), r = Math.floor(s % 60); return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`; };
const scoreClass = (pct) => (pct >= 70 ? "" : pct >= 45 ? "amber" : "red");
const ssiPct = (ssi) => Math.max(0, Math.min(100, (ssi - 70) / 0.9));

function confirmDialog(title, text, okLabel = "Usuń") {
  return new Promise((resolve) => {
    $("#confirm-title").textContent = title; $("#confirm-text").textContent = text; $("#confirm-ok").textContent = okLabel;
    const dlg = $("#dlg-confirm");
    dlg.addEventListener("close", () => resolve(dlg.returnValue === "ok"), { once: true });
    dlg.showModal();
  });
}

function showView(name) {
  document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === `view-${name}`));
  document.querySelectorAll(".tabbar button").forEach((b) => b.classList.toggle("active", b.dataset.view === name));
  window.scrollTo(0, 0);
  if (name === "history") renderHistory();
  if (name === "results" && app.openRecord) requestAnimationFrame(drawOpenChart);
}

// ---------------------------------------------------------------- kalibracja (zapis lokalny)
function loadCalibration() {
  try {
    const c = JSON.parse(localStorage.getItem("skisense.calibration"));
    if (c && axisMapValid(c.src, c.sign) && c.gyroBias?.length === 3 && c.accelOffset?.length === 3) return c;
  } catch { /* brak/uszkodzone */ }
  return defaultCalibration();
}
function saveCalibration() {
  try { localStorage.setItem("skisense.calibration", JSON.stringify(app.calibration)); } catch { /* tryb prywatny */ }
}
function renderCalibLabel() {
  $("#cal-label").textContent = `Osie: ${isIdentityMap(app.calibration) ? "domyślne" : "zmapowane"} · kalibracja: ${app.calibration.calibrated ? "wykonana" : "brak"}`;
}
function updateCalibButton() {
  $("#btn-calib").disabled = !(app.streaming && app.kind !== "sim" && !app.recording && !app.calibBuf);
}

// ---------------------------------------------------------------- połączenie
const live = new LiveChart($("#live-canvas"));

function setStatus(state) {
  const el = $("#conn-status");
  el.dataset.state = state; el.textContent = STATE_TEXT[state] ?? state;
  app.streaming = state === "streaming";
  const label = app.kind === "sim" ? "Demo" : "ESP32";
  const pill = $("#status-pill");
  pill.dataset.state = app.streaming ? "on" : state === "stopped" ? "off" : "busy";
  pill.querySelector("span").textContent = `${label} · ${app.streaming ? "Połączono" : state === "stopped" ? "Rozłączono" : "Łączenie…"}`;
  $("#btn-record").disabled = !(app.streaming || app.recording);
  updateCalibButton();
}

function createSource() {
  const handlers = {
    onSample, onMessage: (m) => { $("#conn-detail").textContent = m; },
    onState: (s) => { if (app.active || s === "stopped") setStatus(s); },
  };
  if (app.kind === "ble") {
    return new BleClient({
      ...handlers,
      onStats: (r, l) => { $("#conn-detail").textContent = `Odebrane pakiety: ${r}${l ? ` · zgubione: ${l}` : ""}`; },
    });
  }
  return new SimSource({ ...handlers, roughness: Number($("#roughness").value) / 100 });
}

async function toggleConnection() {
  if (app.active) { await disconnect(); return; }
  if (app.kind === "ble" && !BleClient.supported()) { $("#ble-warning").hidden = false; return; }
  app.source = createSource();
  app.active = true;
  $("#btn-connect").textContent = "Rozłącz";
  $("#source").disabled = true;
  live.reset();
  try {
    if (app.kind === "ble") {
      const ok = await app.source.start();    // wywołane z kliknięcia: wymóg Web Bluetooth
      if (!ok) { afterDisconnect(); return; }
    } else {
      app.source.start();
    }
    requestWakeLock();
  } catch (e) {
    toast(e.message || String(e), 5000);
    afterDisconnect();
  }
}

async function disconnect() {
  if (app.recording) await toggleRecording();
  app.source?.stop();
  afterDisconnect();
}

function afterDisconnect() {
  app.active = false; app.calibBuf = null; app.source = null;
  $("#btn-connect").textContent = "Połącz";
  $("#source").disabled = false;
  setStatus("stopped");
  renderCalibLabel();
  releaseWakeLock();
}

async function requestWakeLock() {
  try { app.wakeLock = await navigator.wakeLock?.request("screen"); } catch { /* nieobsługiwane lub odmowa */ }
}
function releaseWakeLock() { try { app.wakeLock?.release(); } catch { } app.wakeLock = null; }
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && app.active) requestWakeLock(); });

// ---------------------------------------------------------------- próbki
function onSample(raw) {
  if (!app.active) return;
  let s = raw;
  if (app.kind !== "sim") {                         // symulator generuje już osie aplikacji
    if (app.calibBuf) {
      app.calibBuf.push(raw);
      if (raw.t - app.calibBuf[0].t >= CALIB_SECONDS) finishCalibration();
    }
    s = applyCalibration(app.calibration, raw);
  }
  live.push(s.t, s.ax, s.gz);
  if (app.recording) {
    const b = app.buf;
    b.t.push(s.t); b.ax.push(s.ax); b.ay.push(s.ay); b.az.push(s.az); b.gx.push(s.gx); b.gy.push(s.gy); b.gz.push(s.gz);
  }
}

function startCalibration() {
  if (!app.streaming || app.recording || app.kind === "sim") return;
  app.calibBuf = [];
  $("#cal-label").textContent = `Kalibracja… trzymaj nartę nieruchomo przez ${CALIB_SECONDS} s`;
  updateCalibButton();
}
function finishCalibration() {
  const samples = app.calibBuf; app.calibBuf = null;
  try {
    app.calibration = calibrateFromRest(samples, app.calibration);
    saveCalibration();
    toast("Kalibracja zakończona.");
  } catch (e) { toast(e.message, 5000); }
  renderCalibLabel(); updateCalibButton();
}

// ---------------------------------------------------------------- osie
function openAxesDialog() {
  if (app.recording) return;
  const names = ["X", "Y", "Z"], roles = ["Bok (lewo/prawo)", "Przód / tył", "Pion"];
  $("#axes-grid").innerHTML = roles.map((r, i) => `
    <label for="ax-src-${i}">${r}</label>
    <select id="ax-src-${i}">${names.map((n, k) => `<option value="${k}" ${app.calibration.src[i] === k ? "selected" : ""}>oś ${n}</option>`).join("")}</select>
    <label><input type="checkbox" id="ax-inv-${i}" ${app.calibration.sign[i] < 0 ? "checked" : ""}> odwróć</label>`).join("");
  $("#axes-error").hidden = true;
  $("#dlg-axes").showModal();
}
$("#axes-ok").addEventListener("click", (e) => {
  const src = [0, 1, 2].map((i) => Number($(`#ax-src-${i}`).value));
  const sign = [0, 1, 2].map((i) => ($(`#ax-inv-${i}`).checked ? -1 : 1));
  if (!axisMapValid(src, sign)) { e.preventDefault(); $("#axes-error").hidden = false; return; }
  app.calibration = { ...defaultCalibration(), src, sign };   // zmiana osi unieważnia kalibrację
  saveCalibration(); renderCalibLabel();
});

// ---------------------------------------------------------------- nagrywanie
async function toggleRecording() {
  app.recording = !app.recording;
  const btn = $("#btn-record");
  if (app.recording) {
    app.buf = { t: [], ax: [], ay: [], az: [], gx: [], gy: [], gz: [] };
    app.elapsed = 0; $("#timer").textContent = "00:00";
    app.recTimer = setInterval(() => { app.elapsed++; $("#timer").textContent = fmtDur(app.elapsed); }, 1000);
    btn.textContent = "Zakończ i zapisz trening"; btn.classList.add("rec");
    updateCalibButton();
  } else {
    clearInterval(app.recTimer);
    btn.textContent = "Rozpocznij trening"; btn.classList.remove("rec");
    btn.disabled = !app.streaming;
    updateCalibButton();
    await saveSession();
  }
}

async function saveSession() {
  const s = app.buf; app.buf = null;
  if (!s || s.t.length < 10) { toast("Nagranie było zbyt krótkie, żeby je zapisać."); return; }
  const { turns, analysis } = analyzeSamples(s);
  const id = await app.store.add({ date: new Date().toISOString().slice(0, 19), samples: s, turns, analysis });
  toast(`Zapisano zjazd #${id}: ${analysis.turnCount} skrętów, SSI ${analysis.ssi}`);
  await openSession(id);
}

// ---------------------------------------------------------------- historia
async function renderHistory() {
  const list = await app.store.list();
  $("#st-count").textContent = list.length;
  $("#st-turns").textContent = list.reduce((a, s) => a + (s.turnCount || 0), 0);
  $("#st-ssi").textContent = list.length ? Math.round(list.reduce((a, s) => a + (s.ssi || 0), 0) / list.length) : 0;
  $("#history-empty").hidden = list.length > 0;
  $("#history-list").innerHTML = list.map((s) => `
    <button class="session" data-id="${s.id}">
      <div class="meta"><b>Zjazd #${s.id}</b>
        <div class="muted tiny">${fmtDur(s.durationS)} · ${s.turnCount} skrętów · ${esc(s.date.slice(5, 16).replace("T", " "))}</div>
        <span class="chip">${esc(s.styleLabel || "—")}</span>
        ${s.notes ? `<span class="snip">📝 ${esc(s.notes.replace(/\n/g, " "))}</span>` : ""}
      </div>
      <div class="badge ${scoreClass(ssiPct(s.ssi))}">${Math.round(s.ssi)}</div>
    </button>`).join("");
}
$("#history-list").addEventListener("click", (e) => {
  const b = e.target.closest(".session");
  if (b) openSession(Number(b.dataset.id));
});

// ---------------------------------------------------------------- wyniki
async function openSession(id) {
  const rec = await app.store.get(id);
  if (!rec) { toast("Ta sesja już nie istnieje."); clearResults(); return; }
  app.openId = id; app.openRecord = rec;
  const a = rec.analysis;
  $("#res-empty").hidden = true; $("#res-body").hidden = false;
  $("#res-title").textContent = `Zjazd #${id}`;
  $("#res-sub").textContent = `${fmtDur(a.durationS)} · ${rec.samples.t.length} próbek · ${a.turnCount} skrętów`;
  renderNotes(rec.notes);
  $("#ssi-value").textContent = Math.round(a.ssi);
  const ring = $("#ring");
  ring.style.strokeDashoffset = String(276.46 * (1 - Math.max(0, Math.min(1, a.ssi / 160))));
  ring.style.stroke = { "": "var(--green)", amber: "var(--amber)", red: "var(--red)" }[scoreClass(ssiPct(a.ssi))];
  $("#style-label").textContent = a.styleLabel;
  $("#bars").innerHTML = [["⚖️ Balans", a.balancePct], ["📐 Kontrola krawędzi", a.edgePct], ["〰️ Kształt skrętu", a.turnShapePct], ["🥁 Rytm", a.rhythmPct]]
    .map(([l, v]) => `<div class="bar"><div class="top"><span>${l}</span><span class="muted">${v}%</span></div><div class="track"><div class="fill ${scoreClass(v)}" style="width:${v}%"></div></div></div>`).join("");
  $("#tiles").innerHTML = [
    ["Liczba skrętów", a.turnCount, ""], ["Kadencja", `${a.cadencePerMin.toFixed(1)} /min`, "var(--cyan)"],
    ["Kąt krawędzi", `${a.avgEdgeAngle.toFixed(1)}°`, ""], ["Pozycja przód/tył", `${(a.pitchDeg + 0).toFixed(1)}°`, "var(--amber)"],
    ["Symetria", `${a.symmetry} /100`, ""], ["Poziom drgań", `${a.vibration} /100`, "var(--red)"],
  ].map(([c, v, col]) => `<div class="tile"><div class="cap">${c}</div><div class="val" style="${col ? `color:${col}` : ""}">${v}</div></div>`).join("");
  $("#turn-count").textContent = rec.turns.length;
  $("#turns-body").innerHTML = rec.turns.map((t) => `<tr><td>${t.index + 1}</td><td>${t.direction === "right" ? "prawo" : "lewo"}</td>
    <td>${t.startT.toFixed(1)} s</td><td>${(t.endT - t.startT).toFixed(2)} s</td><td>${Math.round(t.score)}</td></tr>`).join("");
  showView("results");
  requestAnimationFrame(drawOpenChart);
}
function drawOpenChart() { if (app.openRecord) drawSessionChart($("#sess-canvas"), app.openRecord.samples, app.openRecord.turns); }
function clearResults() { app.openId = null; app.openRecord = null; $("#res-body").hidden = true; $("#res-empty").hidden = false; }
function renderNotes(notes) { const el = $("#res-notes"); el.hidden = !notes; el.textContent = notes ? `📝 ${notes}` : ""; }
window.addEventListener("resize", () => { if ($("#view-results").classList.contains("active")) drawOpenChart(); });

$("#btn-note").addEventListener("click", () => {
  if (app.openId == null) return;
  $("#note-text").value = app.openRecord.notes ?? "";
  const dlg = $("#dlg-note");
  dlg.addEventListener("close", async () => {
    if (dlg.returnValue !== "ok") return;
    await app.store.updateNotes(app.openId, $("#note-text").value);
    app.openRecord.notes = $("#note-text").value.trim() || null;
    renderNotes(app.openRecord.notes);
  }, { once: true });
  dlg.showModal();
});

function download(name, text) {
  const url = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
  const a = Object.assign(document.createElement("a"), { href: url, download: name });
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
$("#btn-csv").addEventListener("click", () => { if (app.openRecord) { download(`zjazd_${app.openId}.csv`, samplesToCsv(app.openRecord.samples)); toast("Plik CSV zapisany w Pobranych."); } });
$("#btn-csv-pl").addEventListener("click", () => { if (app.openRecord) { download(`zjazd_${app.openId}_excel.csv`, samplesToCsv(app.openRecord.samples, true)); toast("Plik CSV zapisany w Pobranych."); } });
$("#btn-delete").addEventListener("click", async () => {
  if (app.openId == null) return;
  if (!(await confirmDialog("Usunąć zjazd?", `Zjazd #${app.openId} zostanie skasowany bez możliwości odzyskania.`))) return;
  await app.store.remove(app.openId);
  clearResults(); toast("Usunięto zjazd."); showView("history");
});

// ---------------------------------------------------------------- start
document.querySelectorAll(".tabbar button").forEach((b) => b.addEventListener("click", () => showView(b.dataset.view)));
$("#btn-connect").addEventListener("click", toggleConnection);
$("#btn-record").addEventListener("click", toggleRecording);
$("#btn-calib").addEventListener("click", startCalibration);
$("#btn-axes").addEventListener("click", openAxesDialog);
$("#roughness").addEventListener("input", (e) => { if (app.source instanceof SimSource) app.source.roughness = Number(e.target.value) / 100; });
$("#source").addEventListener("change", (e) => {
  app.kind = e.target.value;
  $("#sim-card").hidden = app.kind !== "sim";
  $("#cal-card").hidden = app.kind === "sim";
  $("#ble-warning").hidden = app.kind !== "ble" || BleClient.supported();
  $("#conn-detail").textContent = app.kind === "ble" ? "Włącz ESP32, potem kliknij „Połącz” i wybierz SKI-IMU." : "Tryb demo generuje sztuczne dane.";
});

(async function init() {
  app.calibration = loadCalibration();
  renderCalibLabel();
  const { store, persistent } = await openStore();
  app.store = store; app.persistent = persistent;
  $("#storage-warning").hidden = persistent;
  $("#cal-card").hidden = true;
  setStatus("stopped");
  live.start();
  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    navigator.serviceWorker.register("sw.js").catch(() => { /* offline działa tylko po https/localhost */ });
  }
  window.__skisense = app;           // ułatwia diagnostykę i testy w przeglądarce
})();
