// store.js — zapis sesji na telefonie (IndexedDB). Metadane i próbki w osobnych magazynach,
// żeby lista historii nie ładowała tysięcy próbek. MemoryStore ma to samo API (testy, tryb prywatny).

const COLS = ["t", "ax", "ay", "az", "gx", "gy", "gz"];

/** {t:[],ax:[],...} -> jeden Float64Array (kolumna po kolumnie) */
export function packSamples(s) {
  const n = s.t.length;
  const out = new Float64Array(n * 7);
  COLS.forEach((c, k) => out.set(s[c], k * n));
  return out;
}
export function unpackSamples(buf) {
  const n = buf.length / 7;
  const s = {};
  COLS.forEach((c, k) => { s[c] = Array.from(buf.subarray(k * n, (k + 1) * n)); });
  return s;
}

function meta(rec) {
  return {
    date: rec.date, notes: rec.notes ?? null, durationS: rec.analysis.durationS, turnCount: rec.analysis.turnCount,
    ssi: rec.analysis.ssi, styleLabel: rec.analysis.styleLabel, analysis: rec.analysis, turns: rec.turns,
  };
}

export class MemoryStore {
  constructor() { this.meta = new Map(); this.samples = new Map(); this.nextId = 1; }
  async open() { return this; }
  async add(rec) {
    const id = this.nextId++;
    this.meta.set(id, { id, ...meta(rec) });
    this.samples.set(id, packSamples(rec.samples));
    return id;
  }
  async list() { return [...this.meta.values()].sort((a, b) => b.id - a.id).map(({ analysis, turns, ...m }) => m); }
  async get(id) {
    const m = this.meta.get(id);
    return m ? { ...m, samples: unpackSamples(this.samples.get(id)) } : null;
  }
  async updateNotes(id, notes) {
    const m = this.meta.get(id);
    if (m) m.notes = (notes ?? "").trim() || null;
  }
  async remove(id) { this.samples.delete(id); return this.meta.delete(id); }
}

export class IdbStore {
  constructor(name = "skisense", idb = globalThis.indexedDB) { this.name = name; this.idb = idb; this.db = null; }
  open() {
    return new Promise((resolve, reject) => {
      const req = this.idb.open(this.name, 1);
      req.onupgradeneeded = () => {
        req.result.createObjectStore("sessions", { keyPath: "id", autoIncrement: true });
        req.result.createObjectStore("samples");
      };
      req.onsuccess = () => { this.db = req.result; resolve(this); };
      req.onerror = () => reject(req.error);
    });
  }
  _tx(stores, mode, fn) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(stores, mode);
      let result;
      tx.oncomplete = () => resolve(result);
      tx.onerror = tx.onabort = () => reject(tx.error);
      result = fn(tx);
    });
  }
  _req(r) { return new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
  async add(rec) {
    let id;
    await this._tx(["sessions", "samples"], "readwrite", (tx) => {
      const r = tx.objectStore("sessions").add(meta(rec));
      r.onsuccess = () => { id = r.result; tx.objectStore("samples").put(packSamples(rec.samples), id); };
    });
    return id;
  }
  async list() {
    const all = await this._tx(["sessions"], "readonly", (tx) => this._req(tx.objectStore("sessions").getAll()));
    return all.sort((a, b) => b.id - a.id).map(({ analysis, turns, ...m }) => m);
  }
  async get(id) {
    const [m, buf] = await this._tx(["sessions", "samples"], "readonly", (tx) =>
      Promise.all([this._req(tx.objectStore("sessions").get(id)), this._req(tx.objectStore("samples").get(id))]));
    return m ? { ...m, samples: unpackSamples(buf) } : null;
  }
  async updateNotes(id, notes) {
    const m = await this._tx(["sessions"], "readonly", (tx) => this._req(tx.objectStore("sessions").get(id)));
    if (!m) return;
    m.notes = (notes ?? "").trim() || null;
    await this._tx(["sessions"], "readwrite", (tx) => { tx.objectStore("sessions").put(m); });
  }
  async remove(id) {
    await this._tx(["sessions", "samples"], "readwrite", (tx) => {
      tx.objectStore("sessions").delete(id);
      tx.objectStore("samples").delete(id);
    });
    return true;
  }
}

/** IndexedDB, a gdy niedostępne (np. tryb prywatny) — pamięć na czas działania strony. */
export async function openStore() {
  try {
    if (globalThis.indexedDB) return { store: await new IdbStore().open(), persistent: true };
  } catch { /* przechodzimy na pamięć */ }
  return { store: new MemoryStore(), persistent: false };
}

export function samplesToCsv(s, excelPl = false) {
  const sep = excelPl ? ";" : ",";
  const f = (v) => {
    let x = v.toFixed(4).replace(/0+$/, "").replace(/\.$/, "");
    if (x === "" || x === "-0") x = "0";
    return excelPl ? x.replace(".", ",") : x;
  };
  const lines = [["t_s", "ax_ms2", "ay_ms2", "az_ms2", "gx_dps", "gy_dps", "gz_dps"].join(sep)];
  for (let i = 0; i < s.t.length; i++) {
    lines.push([s.t[i], s.ax[i], s.ay[i], s.az[i], s.gx[i], s.gy[i], s.gz[i]].map(f).join(sep));
  }
  return "﻿" + lines.join("\n") + "\n";
}
