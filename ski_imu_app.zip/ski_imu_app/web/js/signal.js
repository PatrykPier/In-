// signal.js — pakiet BLE z ESP32, oś/kalibracja (odpowiednik ble_source.py i signal_tools.py)

export const SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
export const CHAR_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e";
export const DEVICE_NAME = "SKI-IMU";

export const PACKET_SIZE = 16;          // uint32 t_ms + 6 x int16, little-endian
export const ACC_LSB_PER_G = 4096;      // zakres +-8 g
export const GYR_LSB_PER_DPS = 65.5;    // zakres +-500 deg/s
export const G = 9.81;
export const SAMPLE_PERIOD_MS = 20;
export const GAP_THRESHOLD_MS = 30;

/** DataView/ArrayBuffer/Uint8Array -> {tMs, ax..gz} w m/s^2 i deg/s. Rzuca Error przy złej długości. */
export function decodePacket(data) {
  const view = data instanceof DataView ? data
    : new DataView(data.buffer ?? data, data.byteOffset ?? 0, data.byteLength);
  if (view.byteLength !== PACKET_SIZE) {
    throw new Error(`Zła długość pakietu: ${view.byteLength} B (oczekiwano ${PACKET_SIZE} B)`);
  }
  const k = G / ACC_LSB_PER_G;
  return {
    tMs: view.getUint32(0, true),
    ax: view.getInt16(4, true) * k, ay: view.getInt16(6, true) * k, az: view.getInt16(8, true) * k,
    gx: view.getInt16(10, true) / GYR_LSB_PER_DPS, gy: view.getInt16(12, true) / GYR_LSB_PER_DPS,
    gz: view.getInt16(14, true) / GYR_LSB_PER_DPS,
  };
}

export function encodePacket(tMs, ax, ay, az, gx, gy, gz) {
  const buf = new ArrayBuffer(PACKET_SIZE);
  const v = new DataView(buf);
  v.setUint32(0, tMs >>> 0, true);
  [ax, ay, az, gx, gy, gz].forEach((x, i) => v.setInt16(4 + 2 * i, x, true));
  return buf;
}

/** millis() z ESP32 -> sekundy od pierwszej próbki; obsługuje przepełnienie uint32. */
export class TimeBase {
  constructor() { this.t0 = null; this.last = null; this.wraps = 0; }
  toSeconds(tMs) {
    if (this.last !== null && tMs < this.last && this.last - tMs > 2 ** 31) this.wraps++;
    this.last = tMs;
    const total = tMs + this.wraps * 2 ** 32;
    if (this.t0 === null) this.t0 = total;
    return (total - this.t0) / 1000;
  }
}

// ---------------- mapowanie osi i kalibracja ----------------
export function defaultCalibration() {
  return { src: [0, 1, 2], sign: [1, 1, 1], gyroBias: [0, 0, 0], accelOffset: [0, 0, 0], calibrated: false };
}

export function axisMapValid(src, sign) {
  return [...src].sort().join() === "0,1,2" && sign.every((s) => s === 1 || s === -1);
}

export function isIdentityMap(c) {
  return c.src.join() === "0,1,2" && c.sign.join() === "1,1,1";
}

/** Surowe osie czujnika -> osie aplikacji (X bok, Y przód/tył, Z pion), po odjęciu biasu. */
export function applyCalibration(c, s) {
  const a = [0, 1, 2].map((i) => c.sign[i] * [s.ax, s.ay, s.az][c.src[i]]);
  const g = [0, 1, 2].map((i) => c.sign[i] * [s.gx, s.gy, s.gz][c.src[i]]);
  return {
    ...s,
    ax: a[0] - c.accelOffset[0], ay: a[1] - c.accelOffset[1], az: a[2] - c.accelOffset[2],
    gx: g[0] - c.gyroBias[0], gy: g[1] - c.gyroBias[1], gz: g[2] - c.gyroBias[2],
  };
}

const stats = (rows, col) => {
  const m = rows.reduce((a, r) => a + r[col], 0) / rows.length;
  const sd = Math.sqrt(rows.reduce((a, r) => a + (r[col] - m) ** 2, 0) / rows.length);
  return [m, sd];
};

/** samples: [{ax..gz}] surowe, zebrane na postoju. Rzuca Error, gdy czujnik się ruszał / za mało próbek. */
export function calibrateFromRest(samples, base = defaultCalibration(), minSamples = 25) {
  if (samples.length < minSamples) throw new Error(`Za mało próbek do kalibracji (${samples.length} < ${minSamples}).`);
  const rows = samples.map((s) => {
    const m = applyCalibration({ ...base, gyroBias: [0, 0, 0], accelOffset: [0, 0, 0] }, s);
    return [m.ax, m.ay, m.az, m.gx, m.gy, m.gz];
  });
  const st = [0, 1, 2, 3, 4, 5].map((c) => stats(rows, c));
  if (Math.max(st[3][1], st[4][1], st[5][1]) > 5 || Math.max(st[0][1], st[1][1], st[2][1]) > 1) {
    throw new Error("Czujnik się poruszał podczas kalibracji. Ustaw nartę nieruchomo i spróbuj ponownie.");
  }
  return {
    src: base.src.slice(), sign: base.sign.slice(),
    gyroBias: [st[3][0], st[4][0], st[5][0]],
    accelOffset: [st[0][0], st[1][0], 0],
    calibrated: true,
  };
}
