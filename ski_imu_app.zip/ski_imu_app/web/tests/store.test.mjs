import test from "node:test";
import assert from "node:assert/strict";
import { MemoryStore, packSamples, unpackSamples, samplesToCsv } from "../js/store.js";

const samples = (n = 30) => {
  const s = { t: [], ax: [], ay: [], az: [], gx: [], gy: [], gz: [] };
  for (let i = 0; i < n; i++) { s.t.push(i * 0.02); s.ax.push(Math.sin(i)); s.ay.push(0.1); s.az.push(9.81); s.gx.push(1); s.gy.push(2); s.gz.push(i); }
  return s;
};
const rec = (extra = {}) => ({ date: "2026-10-12T10:00:00", samples: samples(),
  analysis: { durationS: 0.6, turnCount: 3, ssi: 111, styleLabel: "Zachowawczy" }, turns: [{ index: 0 }], ...extra });

test("pack/unpack próbek jest bezstratne", () => {
  const s = samples(17);
  const back = unpackSamples(packSamples(s));
  for (const k of Object.keys(s)) assert.deepEqual(back[k], s[k]);
});

test("MemoryStore: dodawanie, lista (bez próbek), pobieranie, notatka, usuwanie", async () => {
  const st = new MemoryStore();
  const a = await st.add(rec()), b = await st.add(rec({ notes: "x" }));
  const list = await st.list();
  assert.deepEqual(list.map((r) => r.id), [b, a]);           // najnowsza pierwsza
  assert.equal(list[0].samples, undefined);
  assert.equal(list[0].turns, undefined);
  const full = await st.get(a);
  assert.equal(full.samples.t.length, 30);
  assert.equal(full.analysis.ssi, 111);
  await st.updateNotes(a, "  Kasprowy ");
  assert.equal((await st.get(a)).notes, "Kasprowy");
  await st.updateNotes(a, "   ");
  assert.equal((await st.get(a)).notes, null);
  assert.equal(await st.remove(a), true);
  assert.equal(await st.get(a), null);
  assert.equal((await st.list()).length, 1);
});

test("CSV: nagłówek, precyzja czasu, wersja dla polskiego Excela", () => {
  const s = samples(3); s.t = [3600, 3600.02, 3600.04];
  const std = samplesToCsv(s).replace("﻿", "").trim().split("\n");
  assert.equal(std[0], "t_s,ax_ms2,ay_ms2,az_ms2,gx_dps,gy_dps,gz_dps");
  assert.equal(std[2].split(",")[0], "3600.02");
  const pl = samplesToCsv(s, true).replace("﻿", "").trim().split("\n");
  assert.equal(pl[0].split(";").length, 7);
  assert.equal(pl[2].split(";")[0], "3600,02");
  assert.ok(!pl[2].includes("."));
  assert.ok(std[1].startsWith("3600,"));
});
