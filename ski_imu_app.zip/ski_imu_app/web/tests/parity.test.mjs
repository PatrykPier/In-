// Zgodność analizy JS z Pythonem (wzorce z tests/make_web_fixtures.py).
//   node --test web/tests/
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { analyzeSamples, pyRound, movingAverage } from "../js/analysis.js";

const fixtures = JSON.parse(readFileSync(new URL("./fixtures/parity.json", import.meta.url)));

const KEYS = {
  turn_count: "turnCount", avg_score: "avgScore", left_count: "leftCount", right_count: "rightCount",
  avg_duration: "avgDuration", max_lateral_accel: "maxLateralAccel", cadence_per_min: "cadencePerMin",
  rhythm_consistency: "rhythmConsistency", symmetry: "symmetry", pitch_deg: "pitchDeg", intensity: "intensity",
  vibration: "vibration", avg_edge_angle: "avgEdgeAngle", style_label: "styleLabel", fluency_pct: "fluencyPct",
  stability_pct: "stabilityPct", duration_s: "durationS", ssi: "ssi", balance_pct: "balancePct",
  edge_pct: "edgePct", turn_shape_pct: "turnShapePct", rhythm_pct: "rhythmPct",
};

for (const [name, fx] of Object.entries(fixtures)) {
  test(`analiza zgodna z Pythonem: ${name}`, () => {
    const { turns, analysis } = analyzeSamples(fx.samples);

    assert.equal(turns.length, fx.turns.length, "liczba skrętów");
    turns.forEach((tu, i) => {
      const e = fx.turns[i];
      assert.equal(tu.direction, e.direction);
      assert.ok(Math.abs(tu.startT - e.startT) < 1e-9);
      assert.ok(Math.abs(tu.endT - e.endT) < 1e-9);
      assert.ok(Math.abs(tu.score - e.score) <= 0.11, `ocena skrętu ${i}: ${tu.score} vs ${e.score}`);
      assert.ok(Math.abs(tu.maxLateralAccel - e.maxLateralAccel) <= 0.011);
      assert.ok(Math.abs(tu.maxEdgeAngle - e.maxEdgeAngle) <= 0.11);
    });

    for (const [py, js] of Object.entries(KEYS)) {
      const exp = fx.analysis[py];
      const got = analysis[js];
      if (typeof exp === "string") assert.equal(got, exp, py);
      else assert.ok(Math.abs(got - exp) <= (Number.isInteger(exp) ? 1 : 0.11), `${py}: JS ${got} vs Python ${exp}`);
    }
  });
}

test("pyRound zaokrągla do parzystej jak Python", () => {
  assert.equal(pyRound(0.5), 0);
  assert.equal(pyRound(1.5), 2);
  assert.equal(pyRound(2.5), 2);
  assert.equal(pyRound(-0.5), -0);
  assert.equal(pyRound(2.675, 2), 2.68);   // JS: 267.49999... -> 267 (Python też daje 2.67 lub 2.68; różnica <= 0.01)
});

test("movingAverage: brzeg bez filtracji i krótkie wejście", () => {
  assert.deepEqual(movingAverage([1, 2, 3], 5), [1, 2, 3]);
  const out = movingAverage([1, 2, 3, 4, 5, 6], 3);
  assert.deepEqual(out.slice(0, 2), [1, 2]);
  assert.equal(out[2], 2);
  assert.equal(out[5], 5);
});
