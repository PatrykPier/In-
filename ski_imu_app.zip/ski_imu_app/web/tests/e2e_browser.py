"""
Test end-to-end w prawdziwej przeglądarce (Chromium, widok telefonu).
Web Bluetooth jest zastąpiony atrapą ESP32 wstrzykniętą do strony.

    python web/tests/e2e_browser.py            # z katalogu projektu
Zrzuty ekranu trafiają do katalogu podanego w SHOTS (domyślnie /tmp/skisense_shots).
"""
import csv
import functools
import http.server
import io
import os
import sys
import threading

from playwright.sync_api import sync_playwright, expect

WEB = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOTS = os.environ.get("SHOTS", "/tmp/skisense_shots")
os.makedirs(SHOTS, exist_ok=True)

FAKE_BLE = r"""
(() => {
  const SERVICE = "6e400001-b5a3-f393-e0a9-e50e24dcca9e", CHAR = "6e400003-b5a3-f393-e0a9-e50e24dcca9e";
  const enc = (t, ax, ay, az, gx, gy, gz) => {
    const b = new ArrayBuffer(16), v = new DataView(b);
    v.setUint32(0, t >>> 0, true);
    [ax, ay, az, gx, gy, gz].forEach((x, i) => v.setInt16(4 + 2 * i, Math.round(x), true));
    return b;
  };
  const K = 4096 / 9.81, GK = 65.5;
  const fake = window.__fake = { tMs: 1000000, n: 0, connects: 0, mode: "rest", timer: null, requests: [] };
  const dev = new EventTarget();
  dev.name = "SKI-IMU";
  const char = new EventTarget();
  char.startNotifications = async () => {
    clearInterval(fake.timer);
    fake.timer = setInterval(() => {
      if (!dev.gatt.connected) return;
      fake.tMs += 20; fake.n++;
      const x = fake.n * 0.02, om = 2 * Math.PI / 2.2, r = () => (Math.random() - 0.5) * 0.1;
      let ax = 0.4 + r(), gz = 2.5 + r() * 3;
      if (fake.mode === "ride") { ax += 2.2 * Math.sin(om * x); gz += 55 * Math.cos(om * x); }
      const ev = new Event("characteristicvaluechanged");
      Object.defineProperty(ev, "target", { value: { value: new DataView(enc(fake.tMs, ax * K, -0.2 * K, 9.81 * K + r() * K, 1.5 * GK, -0.7 * GK, gz * GK)) } });
      char.dispatchEvent(ev);
    }, 20);
  };
  dev.gatt = {
    connected: false,
    connect: async () => {
      fake.connects++;
      dev.gatt.connected = true;
      return { getPrimaryService: async (u) => { if (u !== SERVICE) throw new Error("bad service"); return { getCharacteristic: async (c) => { if (c !== CHAR) throw new Error("bad char"); return char; } }; } };
    },
    disconnect: () => { dev.gatt.connected = false; clearInterval(fake.timer); },
  };
  fake.drop = () => { dev.gatt.connected = false; clearInterval(fake.timer); dev.dispatchEvent(new Event("gattserverdisconnected")); };
  Object.defineProperty(navigator, "bluetooth", { configurable: true, value: { requestDevice: async (o) => { fake.requests.push(o); return dev; } } });
})();
"""


def serve():
    class Quiet(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a, **k):
            pass

    handler = functools.partial(Quiet, directory=WEB)
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}/"


def main():
    srv, url = serve()
    errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True,
                                  has_touch=True, accept_downloads=True)
        ctx.add_init_script(FAKE_BLE)
        page = ctx.new_page()
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
        page.on("pageerror", lambda e: errors.append(str(e)))

        def shot(name):
            page.screenshot(path=os.path.join(SHOTS, name + ".png"))

        page.goto(url)
        expect(page.locator("#conn-status")).to_contain_text("Rozłączono")
        assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth"), "poziome przewijanie"
        page.wait_for_function("navigator.serviceWorker.controller !== null || true")
        shot("01_start")

        # ---------------- tryb demo: połącz, nagraj, wyniki ----------------
        page.click("#btn-connect")
        expect(page.locator("#conn-status")).to_contain_text("połączone")
        expect(page.locator("#btn-record")).to_be_enabled()
        page.wait_for_timeout(1500)
        px = page.evaluate("""() => { const c = document.querySelector('#live-canvas'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
          let n = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 0) n++; return n; }""")
        assert px > 5000, f"wykres na żywo jest pusty ({px})"
        shot("02_demo_live")
        page.click("#btn-record")
        page.wait_for_timeout(11000)
        assert page.inner_text("#timer") >= "00:10"
        shot("03_recording")
        page.click("#btn-record")
        expect(page.locator("#res-body")).to_be_visible()
        expect(page.locator("#res-title")).to_have_text("Zjazd #1")
        assert int(page.inner_text("#ssi-value")) > 70
        n_turns = int(page.inner_text("#turn-count"))
        assert n_turns >= 6, n_turns
        page.wait_for_timeout(800)
        shot("04_results")
        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        shot("05_results_bottom")
        page.click(".tabbar button[data-view=train]")
        page.click("#btn-connect")          # rozłącz
        expect(page.locator("#conn-status")).to_contain_text("Rozłączono")

        # ---------------- historia i trwałość po przeładowaniu ----------------
        page.reload()
        page.click(".tabbar button[data-view=history]")
        expect(page.locator("#history-list .session")).to_have_count(1)
        assert page.inner_text("#st-count") == "1"
        shot("06_history")

        # notatka
        page.click("#history-list .session")
        page.click("#btn-note")
        page.fill("#note-text", "Kasprowy <twardy> śnieg & wiatr")
        page.click("#note-ok")
        expect(page.locator("#res-notes")).to_contain_text("Kasprowy <twardy> śnieg & wiatr")
        shot("07_note")

        # eksport CSV: pobrany plik da się wczytać, czas rośnie co 20 ms
        with page.expect_download() as dl:
            page.click("#btn-csv")
        path = dl.value.path()
        rows = list(csv.reader(io.StringIO(open(path, encoding="utf-8-sig").read())))
        assert rows[0] == ["t_s", "ax_ms2", "ay_ms2", "az_ms2", "gx_dps", "gy_dps", "gz_dps"], rows[0]
        assert len(rows) > 400, len(rows)
        assert abs(float(rows[2][0]) - float(rows[1][0]) - 0.02) < 0.005
        with page.expect_download() as dl2:
            page.click("#btn-csv-pl")
        pl = open(dl2.value.path(), encoding="utf-8-sig").read().splitlines()
        assert pl[0].count(";") == 6 and "." not in pl[2]

        # ---------------- ESP32 przez (atrapę) Web Bluetooth ----------------
        page.click(".tabbar button[data-view=train]")
        page.select_option("#source", "ble")
        expect(page.locator("#cal-card")).to_be_visible()
        expect(page.locator("#sim-card")).to_be_hidden()
        page.click("#btn-connect")
        expect(page.locator("#conn-status")).to_contain_text("połączone", timeout=5000)
        reqs = page.evaluate("window.__fake.requests")
        assert reqs[0]["filters"][0] == {"name": "SKI-IMU"}, reqs
        expect(page.locator("#status-pill")).to_contain_text("ESP32")
        expect(page.locator("#btn-calib")).to_be_enabled()
        page.click("#btn-calib")
        expect(page.locator("#cal-label")).to_contain_text("Kalibracja…")
        expect(page.locator("#cal-label")).to_contain_text("kalibracja: wykonana", timeout=8000)
        bias = page.evaluate("window.__skisense.calibration.gyroBias")
        assert abs(bias[0] - 1.5) < 0.1 and abs(bias[1] + 0.7) < 0.1 and abs(bias[2] - 2.5) < 0.3, bias
        shot("08_ble_calibrated")

        # krótkie nagranie na postoju: po kalibracji sygnał powinien być wyzerowany
        page.click("#btn-record")
        page.wait_for_timeout(1500)
        page.click("#btn-record")
        expect(page.locator("#res-title")).to_have_text("Zjazd #2")
        stats = page.evaluate("""() => { const s = window.__skisense.openRecord.samples; const m = (a) => a.reduce((x, y) => x + y, 0) / a.length;
          return { gx: m(s.gx), gz: m(s.gz), ax: m(s.ax), az: m(s.az), n: s.t.length, dt: s.t[2] - s.t[1] }; }""")
        assert abs(stats["gx"]) < 0.2 and abs(stats["gz"]) < 0.3 and abs(stats["ax"]) < 0.1, stats
        assert abs(stats["az"] - 9.81) < 0.2 and stats["n"] > 40 and abs(stats["dt"] - 0.02) < 1e-6, stats

        # zerwanie połączenia -> samo wraca
        page.click(".tabbar button[data-view=train]")
        connects = page.evaluate("window.__fake.connects")
        page.evaluate("window.__fake.drop()")
        expect(page.locator("#conn-status")).to_contain_text("utracone", timeout=3000)
        shot("09_ble_lost")
        expect(page.locator("#conn-status")).to_contain_text("połączone", timeout=6000)
        assert page.evaluate("window.__fake.connects") == connects + 1

        # jazda przez BLE -> skręty wykryte
        page.evaluate("window.__fake.mode = 'ride'")
        page.click("#btn-record")
        page.wait_for_timeout(10000)
        page.click("#btn-record")
        expect(page.locator("#res-title")).to_have_text("Zjazd #3")
        assert int(page.inner_text("#turn-count")) >= 6
        page.click(".tabbar button[data-view=train]")
        page.click("#btn-connect")
        expect(page.locator("#conn-status")).to_contain_text("Rozłączono")

        # ---------------- osie ----------------
        page.click("#btn-axes")
        page.select_option("#ax-src-0", "1")                # X i Y wskazują oś Y -> błąd
        page.click("#axes-ok")
        expect(page.locator("#axes-error")).to_be_visible()
        shot("10_axes_error")
        page.select_option("#ax-src-1", "0")
        page.check("#ax-inv-2")
        page.click("#axes-ok")
        expect(page.locator("#cal-label")).to_contain_text("zmapowane")
        expect(page.locator("#cal-label")).to_contain_text("kalibracja: brak")
        page.reload()                                        # zapisane w localStorage
        page.select_option("#source", "ble")
        expect(page.locator("#cal-label")).to_contain_text("zmapowane")

        # ---------------- usuwanie z potwierdzeniem ----------------
        page.click(".tabbar button[data-view=history]")
        expect(page.locator("#history-list .session")).to_have_count(3)
        page.click("#history-list .session >> nth=2")        # najstarszy (#1)
        page.click("#btn-delete")
        expect(page.locator("#dlg-confirm")).to_be_visible()
        shot("11_confirm")
        page.click("#dlg-confirm button[value=cancel]")
        assert page.evaluate("window.__skisense.store.list().then(l => l.length)") == 3
        page.click("#btn-delete")
        page.click("#confirm-ok")
        expect(page.locator("#history-list .session")).to_have_count(2)

        # ---------------- Service Worker / offline ----------------
        page.wait_for_function("navigator.serviceWorker.getRegistration().then(r => !!r && !!r.active)")
        page.reload()
        page.wait_for_function("!!navigator.serviceWorker.controller")
        ctx.set_offline(True)
        page.reload()
        expect(page.locator(".brand b")).to_have_text("SkiSense")
        page.click(".tabbar button[data-view=history]")
        expect(page.locator("#history-list .session")).to_have_count(2)
        ctx.set_offline(False)
        browser.close()

    srv.shutdown()
    errors = [e for e in errors if "Failed to load resource" not in e]
    assert not errors, errors
    print("E2E OK, zrzuty:", SHOTS)


if __name__ == "__main__":
    main()
