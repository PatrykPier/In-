import test from "node:test";
import assert from "node:assert/strict";
import {
  decodePacket, encodePacket, TimeBase, PACKET_SIZE, applyCalibration, calibrateFromRest,
  defaultCalibration, axisMapValid, isIdentityMap, CHAR_UUID, SERVICE_UUID,
} from "../js/signal.js";
import { BleClient } from "../js/ble.js";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, ms = 3000) {
  const end = Date.now() + ms;
  while (Date.now() < end) { if (cond()) return true; await sleep(5); }
  return false;
}

// ---------- dekoder ----------
test("pakiet ma 16 B i skalowanie jak w Pythonie", () => {
  assert.equal(PACKET_SIZE, 16);
  const p = decodePacket(encodePacket(123456, 4096, -4096, 2048, 655, -655, 131));
  assert.equal(p.tMs, 123456);
  assert.ok(Math.abs(p.ax - 9.81) < 1e-9);
  assert.ok(Math.abs(p.ay + 9.81) < 1e-9);
  assert.ok(Math.abs(p.az - 4.905) < 1e-9);
  assert.ok(Math.abs(p.gx - 10) < 1e-9);
  assert.ok(Math.abs(p.gz - 2) < 1e-9);
});

test("skrajne wartości int16 i uint32", () => {
  const p = decodePacket(encodePacket(2 ** 32 - 1, -32768, 32767, 0, 0, 0, 0));
  assert.equal(p.tMs, 2 ** 32 - 1);
  assert.ok(Math.abs(p.ax - (-32768 / 4096) * 9.81) < 1e-9);
});

test("zła długość pakietu zgłasza błąd, Uint8Array z przesunięciem działa", () => {
  assert.throws(() => decodePacket(new ArrayBuffer(15)));
  assert.throws(() => decodePacket(new ArrayBuffer(17)));
  const big = new Uint8Array(32);
  big.set(new Uint8Array(encodePacket(777, 0, 0, 4096, 0, 0, 0)), 8);
  const p = decodePacket(new Uint8Array(big.buffer, 8, 16));
  assert.equal(p.tMs, 777);
});

test("TimeBase: start od zera i przepełnienie uint32", () => {
  let tb = new TimeBase();
  assert.equal(tb.toSeconds(1000), 0);
  assert.ok(Math.abs(tb.toSeconds(1020) - 0.02) < 1e-12);
  tb = new TimeBase();
  tb.toSeconds(2 ** 32 - 20);
  assert.ok(Math.abs(tb.toSeconds(0) - 0.02) < 1e-12);
  assert.ok(Math.abs(tb.toSeconds(20) - 0.04) < 1e-12);
});

// ---------- kalibracja ----------
test("mapowanie osi zamienia i odwraca akcelerometr i żyroskop", () => {
  const c = { ...defaultCalibration(), src: [1, 0, 2], sign: [-1, 1, 1] };
  const o = applyCalibration(c, { ax: 1, ay: 2, az: 3, gx: 10, gy: 20, gz: 30 });
  assert.deepEqual([o.ax, o.ay, o.az, o.gx, o.gy, o.gz], [-2, 1, 3, -20, 10, 30]);
  assert.ok(axisMapValid([1, 0, 2], [1, 1, 1]));
  assert.ok(!axisMapValid([0, 0, 2], [1, 1, 1]));
  assert.ok(!axisMapValid([0, 1, 2], [1, 2, 1]));
  assert.ok(isIdentityMap(defaultCalibration()));
});

test("kalibracja zeruje bias na postoju, odrzuca ruch i za mało próbek", () => {
  const rest = Array.from({ length: 100 }, (_, i) => ({
    ax: 0.4 + 0.01 * Math.sin(i), ay: -0.2, az: 9.81, gx: 1.5, gy: -0.7 + 0.01 * Math.cos(i), gz: 0.3,
  }));
  const cal = calibrateFromRest(rest);
  const out = applyCalibration(cal, rest[0]);
  assert.ok(Math.abs(out.gx) < 0.05 && Math.abs(out.ax) < 0.05);
  assert.ok(Math.abs(out.az - 9.81) < 0.01);       // grawitacja zostaje
  assert.ok(cal.calibrated);
  const moving = rest.map((s, i) => ({ ...s, gx: 100 * Math.sin(i) }));
  assert.throws(() => calibrateFromRest(moving), /poruszał/);
  assert.throws(() => calibrateFromRest(rest.slice(0, 5)), /Za mało/);
});

// ---------- atrapa Web Bluetooth ----------
class FakeChar extends EventTarget {
  constructor(dev) { super(); this.dev = dev; }
  async startNotifications() { this.dev.startPump(this); }
}
class FakeDevice extends EventTarget {
  constructor(opts) {
    super(); Object.assign(this, { name: "SKI-IMU", packetsPerConnection: 1e9, dropAfter: false, failConnects: 0, gap: null, bad: null }, opts);
    this.connects = 0; this.tMs = 5_000_000; this.sent = 0;
    const dev = this;
    this.gatt = {
      connected: false,
      async connect() {
        dev.connects++;
        if (dev.failConnects > 0) { dev.failConnects--; throw new Error("GATT Server is disconnected"); }
        this.connected = true;
        return { async getPrimaryService(u) { assert.equal(u, SERVICE_UUID); return { async getCharacteristic(c) { assert.equal(c, CHAR_UUID); dev.char = new FakeChar(dev); return dev.char; } }; } };
      },
      disconnect() { this.connected = false; dev.stopPump(); },
    };
  }
  startPump(ch) {
    this.stopPump();
    let n = 0;
    this.pump = setInterval(() => {
      if (!this.gatt.connected) return;
      this.tMs += 20; this.sent++;
      if (this.gap && this.sent === this.gap) this.tMs += 80;
      const buf = this.bad && this.sent === this.bad ? new ArrayBuffer(3) : encodePacket(this.tMs, 100, -200, 4096, 0, 0, 655);
      const ev = new Event("characteristicvaluechanged"); Object.defineProperty(ev, "target", { value: { value: new DataView(buf) } });
      ch.dispatchEvent(ev);
      if (++n >= this.packetsPerConnection && this.dropAfter) {
        this.gatt.connected = false; this.stopPump();
        this.dispatchEvent(new Event("gattserverdisconnected"));
      }
    }, 2);
  }
  stopPump() { clearInterval(this.pump); }
}
const fakeBluetooth = (dev, calls = []) => ({ async requestDevice(opts) { calls.push(opts); if (dev instanceof Error) throw dev; return dev; } });

function client(dev, extra = {}) {
  const log = { samples: [], states: [], msgs: [], stats: [] };
  const calls = [];
  const c = new BleClient({
    bluetooth: fakeBluetooth(dev, calls), retryDelayMs: 20, connectTimeoutMs: 500,
    onSample: (s) => log.samples.push(s), onState: (s) => log.states.push(s),
    onMessage: (m) => log.msgs.push(m), onStats: (r, l) => log.stats.push([r, l]), ...extra,
  });
  return { c, log, calls };
}

test("BLE: łączy się, przelicza próbki, czas zaczyna od 0, filtr po nazwie i UUID", async () => {
  const dev = new FakeDevice();
  const { c, log, calls } = client(dev);
  assert.equal(await c.start(), true);
  assert.ok(await until(() => log.samples.length >= 60));
  c.stop();
  assert.deepEqual(log.states.slice(0, 3), ["scanning", "connecting", "streaming"]);
  assert.equal(log.states.at(-1), "stopped");
  assert.equal(log.samples[0].t, 0);
  assert.ok(Math.abs(log.samples[10].t - 0.2) < 1e-9);
  assert.ok(Math.abs(log.samples[0].az - 9.81) < 1e-9);
  assert.ok(Math.abs(log.samples[0].gz - 10) < 1e-9);
  assert.deepEqual(calls[0].filters, [{ name: "SKI-IMU" }, { services: [SERVICE_UUID] }]);
  assert.deepEqual(calls[0].optionalServices, [SERVICE_UUID]);
  assert.ok(log.stats.length >= 1);
});

test("BLE: po zerwaniu łączy ponownie, czas rośnie, brak zgubionych przez rozłączenie", async () => {
  const dev = new FakeDevice({ packetsPerConnection: 30, dropAfter: true });
  const { c, log } = client(dev);
  await c.start();
  assert.ok(await until(() => log.samples.length >= 90, 5000), "brak ponownego połączenia");
  c.stop();
  assert.ok(dev.connects >= 3);
  assert.ok(log.states.filter((s) => s === "streaming").length >= 3);
  assert.ok(log.states.includes("disconnected"));
  const ts = log.samples.map((s) => s.t);
  assert.deepEqual(ts, [...ts].sort((a, b) => a - b));
  assert.equal(c.lost, 0);
});

test("BLE: wylicza liczbę zgubionych pakietów", async () => {
  const dev = new FakeDevice({ gap: 20 });
  const { c, log } = client(dev);
  await c.start();
  assert.ok(await until(() => log.samples.length >= 50));
  c.stop();
  assert.equal(c.lost, 4);
  assert.equal(c.bad, 0);
});

test("BLE: uszkodzony pakiet jest pomijany i liczony jako zgubiony", async () => {
  const dev = new FakeDevice({ bad: 30 });
  const { c, log } = client(dev);
  await c.start();
  assert.ok(await until(() => log.samples.length >= 50));
  c.stop();
  assert.equal(c.bad, 1);
  assert.equal(c.lost, 1);   // brakująca próbka widoczna jako dziura w czasie
});

test("BLE: ponawia nieudane łączenie", async () => {
  const dev = new FakeDevice({ failConnects: 3 });
  const { c, log } = client(dev);
  await c.start();
  assert.ok(await until(() => log.states.includes("streaming"), 3000));
  c.stop();
  assert.equal(dev.connects, 4);
  assert.ok(log.msgs.some((m) => m.includes("Błąd połączenia")));
});

test("BLE: stop w trakcie ponawiania kończy pracę i nie łączy dalej", async () => {
  const dev = new FakeDevice({ failConnects: 1e9 });
  const { c, log } = client(dev);
  c.start();
  await until(() => dev.connects >= 2);
  c.stop();
  const n = dev.connects;
  await sleep(120);
  assert.equal(dev.connects, n);
  assert.equal(log.states.at(-1), "stopped");
});

test("BLE: anulowanie okna wyboru urządzenia kończy w stanie stopped", async () => {
  const err = Object.assign(new Error("User cancelled"), { name: "NotFoundError" });
  const { c, log } = client(err);
  assert.equal(await c.start(), false);
  assert.equal(log.states.at(-1), "stopped");
  assert.ok(log.msgs.at(-1).includes("Anulowano"));
});

test("BLE: przeglądarka bez Web Bluetooth daje czytelny błąd", async () => {
  const c = new BleClient({ bluetooth: undefined });
  await assert.rejects(() => c.start(), /Web Bluetooth/);
});

test("BLE: po stop() nie spływają już próbki", async () => {
  const dev = new FakeDevice();
  const { c, log } = client(dev);
  await c.start();
  await until(() => log.samples.length >= 10);
  c.stop();
  await sleep(30);
  const n = log.samples.length;
  await sleep(60);
  assert.equal(log.samples.length, n);
});
