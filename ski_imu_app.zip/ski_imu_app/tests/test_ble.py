"""
Testy klienta BLE bez sprzętu: atrapa ESP32 wysyła prawdziwe 16-bajtowe pakiety.

Uruchomienie (z folderu projektu):
    python -m unittest discover -s tests -v
"""

import asyncio
import os
import sys
import time
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt5.QtCore import QCoreApplication
from PyQt5.QtWidgets import QApplication

from ble_source import (
    BleWorker, TimeBase, decode_packet, encode_packet, PACKET_SIZE, CHAR_UUID,
)
from data_source import ESP32BLEDataSource

_app = QApplication.instance() or QApplication([])


def wait_for(cond, timeout=5.0):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        QCoreApplication.processEvents()
        if cond():
            return True
        time.sleep(0.005)
    return False


# -------------------------------------------------------------------- #
# Atrapa ESP32
# -------------------------------------------------------------------- #
class FakeClient:
    """Udaje BleakClient: po start_notify wysyła pakiety, opcjonalnie zrywa połączenie."""

    def __init__(self, backend, disconnected_callback):
        self.backend = backend
        self._cb = disconnected_callback
        self.is_connected = False
        self._pump_task = None

    async def connect(self):
        self.is_connected = True

    async def disconnect(self):
        self.is_connected = False
        if self._pump_task:
            self._pump_task.cancel()

    async def start_notify(self, char, handler):
        assert char == CHAR_UUID
        self._pump_task = asyncio.ensure_future(self._pump(handler))

    async def stop_notify(self, char):
        pass

    async def _pump(self, handler):
        be = self.backend
        for i in range(be.packets_per_connection):
            t_ms = be.next_t_ms()
            handler(None, be.make_packet(t_ms, i))
            await asyncio.sleep(0.002)
        if be.drop_after_packets:
            self.is_connected = False
            self._cb(self)  # symulacja utraty połączenia


class FakeBackend:
    def __init__(self, packets_per_connection=100000, drop_after_packets=False,
                 scan_misses=0, gap_at=None, bad_packet_at=None):
        self.packets_per_connection = packets_per_connection
        self.drop_after_packets = drop_after_packets
        self.scan_misses = scan_misses
        self.gap_at = gap_at              # numer pakietu, po którym dodajemy dziurę 80 ms
        self.bad_packet_at = bad_packet_at
        self.clients_created = 0
        self.scans = 0
        self._t_ms = 1_000_000
        self._sent = 0

    def next_t_ms(self):
        self._t_ms += 20
        self._sent += 1
        if self.gap_at is not None and self._sent == self.gap_at:
            self._t_ms += 80  # 4 pakiety "zgubione" (100 ms = 5 okresów, 4 zgubione)
        return self._t_ms

    def make_packet(self, t_ms, i):
        if self.bad_packet_at is not None and self._sent == self.bad_packet_at:
            return b"\x00\x01\x02"
        # az = 4096 LSB = 1 g = 9.81 m/s^2; gz = 655 LSB = 10 deg/s
        return encode_packet(t_ms, 100, -200, 4096, 0, 0, 655)

    async def find_device(self, name, service_uuid, timeout):
        self.scans += 1
        await asyncio.sleep(0.005)
        if self.scan_misses > 0:
            self.scan_misses -= 1
            return None
        return "fake-device"

    def make_client(self, device, disconnected_callback):
        self.clients_created += 1
        return FakeClient(self, disconnected_callback)


def make_worker(backend):
    w = BleWorker("SKI-IMU", backend=backend, scan_timeout=0.1, connect_timeout=1.0, retry_delay=0.05)
    samples, states, messages = [], [], []
    w.sample_ready.connect(lambda *a: samples.append(a))
    w.state_changed.connect(states.append)
    w.message.connect(messages.append)
    return w, samples, states, messages


def stop_worker(w):
    w.request_stop()
    ok = w.wait(5000)
    QCoreApplication.processEvents()
    return ok


# -------------------------------------------------------------------- #
# Testy dekodera
# -------------------------------------------------------------------- #
class DecodeTests(unittest.TestCase):
    def test_packet_is_16_bytes(self):
        self.assertEqual(PACKET_SIZE, 16)
        self.assertEqual(len(encode_packet(1, 0, 0, 0, 0, 0, 0)), 16)

    def test_scaling(self):
        t_ms, ax, ay, az, gx, gy, gz = decode_packet(encode_packet(123456, 4096, -4096, 2048, 655, -655, 131))
        self.assertEqual(t_ms, 123456)
        self.assertAlmostEqual(ax, 9.81, places=3)
        self.assertAlmostEqual(ay, -9.81, places=3)
        self.assertAlmostEqual(az, 4.905, places=3)
        self.assertAlmostEqual(gx, 10.0, places=3)
        self.assertAlmostEqual(gy, -10.0, places=3)
        self.assertAlmostEqual(gz, 2.0, places=3)

    def test_negative_extremes(self):
        _, ax, *_ = decode_packet(encode_packet(0, -32768, 0, 0, 0, 0, 0))
        self.assertAlmostEqual(ax, -32768 / 4096 * 9.81, places=3)

    def test_wrong_length_raises(self):
        with self.assertRaises(ValueError):
            decode_packet(b"\x00" * 15)
        with self.assertRaises(ValueError):
            decode_packet(b"\x00" * 17)

    def test_timebase_starts_at_zero_and_unwraps(self):
        tb = TimeBase()
        self.assertEqual(tb.to_seconds(1000), 0.0)
        self.assertAlmostEqual(tb.to_seconds(1020), 0.020)
        tb = TimeBase()
        tb.to_seconds(2 ** 32 - 20)
        self.assertAlmostEqual(tb.to_seconds(0), 0.020)   # przepełnienie uint32
        self.assertAlmostEqual(tb.to_seconds(20), 0.040)


# -------------------------------------------------------------------- #
# Testy wątku BLE
# -------------------------------------------------------------------- #
class WorkerTests(unittest.TestCase):
    def test_streams_and_converts_samples(self):
        w, samples, states, _ = make_worker(FakeBackend())
        w.start()
        self.assertTrue(wait_for(lambda: len(samples) >= 50), "brak próbek")
        self.assertTrue(stop_worker(w), "wątek nie zatrzymał się w 5 s")

        t0, ax, ay, az, gx, gy, gz = samples[0]
        self.assertEqual(t0, 0.0)
        self.assertAlmostEqual(az, 9.81, places=2)
        self.assertAlmostEqual(gz, 10.0, places=2)
        self.assertAlmostEqual(samples[10][0], 0.2, places=3)  # co 20 ms
        self.assertEqual(states[:3], ["scanning", "connecting", "streaming"])
        self.assertEqual(states[-1], "stopped")

    def test_reconnects_after_connection_loss(self):
        be = FakeBackend(packets_per_connection=30, drop_after_packets=True)
        w, samples, states, _ = make_worker(be)
        w.start()
        self.assertTrue(wait_for(lambda: len(samples) >= 80, 8.0), "nie odzyskano połączenia")
        stop_worker(w)
        self.assertGreaterEqual(be.clients_created, 3)
        self.assertGreaterEqual(states.count("streaming"), 3)
        self.assertIn("disconnected", states)
        # czas rośnie monotonicznie także po ponownym połączeniu
        times = [s[0] for s in samples]
        self.assertEqual(times, sorted(times))

    def test_keeps_scanning_when_device_not_found_and_stops_fast(self):
        be = FakeBackend(scan_misses=10 ** 6)
        w, samples, states, messages = make_worker(be)
        w.start()
        self.assertTrue(wait_for(lambda: be.scans >= 3), "skaner nie ponawia prób")
        started = time.monotonic()
        self.assertTrue(stop_worker(w))
        self.assertLess(time.monotonic() - started, 2.0)
        self.assertEqual(samples, [])
        self.assertTrue(any("Nie znaleziono" in m for m in messages))

    def test_finds_device_after_a_few_misses(self):
        w, samples, *_ = make_worker(FakeBackend(scan_misses=3))
        w.start()
        self.assertTrue(wait_for(lambda: len(samples) >= 10))
        stop_worker(w)

    def test_counts_lost_packets(self):
        be = FakeBackend(packets_per_connection=60, gap_at=20)
        w, samples, *_ = make_worker(be)
        w.start()
        self.assertTrue(wait_for(lambda: len(samples) >= 60))
        stop_worker(w)
        self.assertEqual(w.lost, 4)

    def test_bad_packet_is_ignored(self):
        be = FakeBackend(packets_per_connection=40, bad_packet_at=10)
        w, samples, *_ = make_worker(be)
        w.start()
        self.assertTrue(wait_for(lambda: len(samples) >= 39))
        stop_worker(w)
        self.assertEqual(w.bad_packets, 1)
        self.assertEqual(w.received, 39)

    def test_stop_requested_before_loop_starts(self):
        w, samples, states, _ = make_worker(FakeBackend())
        w.request_stop()
        w.start()
        self.assertTrue(w.wait(5000))
        self.assertEqual(samples, [])


# -------------------------------------------------------------------- #
# Test źródła danych używanego przez GUI
# -------------------------------------------------------------------- #
class DataSourceTests(unittest.TestCase):
    def test_source_emits_connected_and_samples_then_stops(self):
        src = ESP32BLEDataSource(backend=FakeBackend())
        samples, conn = [], []
        src.sample_ready.connect(lambda *a: samples.append(a))
        src.connected.connect(conn.append)
        src.start()
        self.assertTrue(wait_for(lambda: len(samples) >= 20))
        self.assertIn(True, conn)
        src.stop()
        self.assertEqual(conn[-1], False)
        wait_for(lambda: False, 0.1)   # ogon próbek, które były już w kolejce Qt
        n = len(samples)
        wait_for(lambda: False, 0.3)   # a potem nic nowego nie może dochodzić
        self.assertEqual(len(samples), n)


if __name__ == "__main__":
    unittest.main(verbosity=2)
