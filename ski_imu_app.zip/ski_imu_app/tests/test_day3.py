"""Testy Dnia 3: baza (notatki, usuwanie, migracja), eksport CSV/PDF, historia, porównanie sesji."""

import math
import os
import random
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QMessageBox, QInputDialog

import export
import main_window
from csv_import import parse_csv_file
from data_analysis import moving_average, detect_turns, full_session_analysis
from database import Database
from session_service import load_session

app = QApplication.instance() or QApplication([])
app.setStyleSheet(main_window.APP_QSS)


def make_session(db, uid, duration=30.0, noise=0.4, amp=55.0, seed=1, notes=None):
    """Zapisuje sesję tak, jak robi to LiveTab._save_session."""
    rnd = random.Random(seed)
    om = 2 * math.pi / 2.2
    rows = []
    for i in range(int(duration * 50)):
        t = i * 0.02
        rows.append((t, 2.2 * math.sin(om * t) + rnd.gauss(0, noise), rnd.gauss(0, .1), 9.81 + rnd.gauss(0, .2),
                     rnd.gauss(0, 3), rnd.gauss(0, 3), amp * math.cos(om * t) + rnd.gauss(0, noise * 15)))
    sid = db.create_session(uid)
    db.insert_sensor_batch(sid, rows)
    t = [r[0] for r in rows]
    ax = moving_average([r[1] for r in rows], 5)
    gz = moving_average([r[6] for r in rows], 5)
    turns = detect_turns(t, gz, ax)
    db.insert_turns(sid, [{"turn_index": x.index, "start_t": x.start_t, "end_t": x.end_t, "direction": x.direction,
                           "score": x.score, "max_lateral_accel": x.max_lateral_accel,
                           "max_edge_angle": x.max_edge_angle} for x in turns])
    a = full_session_analysis(t, [r[1] for r in rows], [r[2] for r in rows], [r[3] for r in rows], gz, turns)
    db.update_session_summary(sid, a["duration_s"], a["turn_count"], a["ssi"], a["style_label"])
    if notes:
        db.update_notes(sid, notes)
    return sid


class TempDirCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = self.tmp.name

    def tearDown(self):
        self.tmp.cleanup()


class DatabaseTests(TempDirCase):
    def setUp(self):
        super().setUp()
        self.db = Database(os.path.join(self.dir, "a.db"))
        self.uid = self.db.get_or_create_user("u")
        self.addCleanup(self.db.close)

    def test_delete_removes_session_data_and_turns_only_for_that_session(self):
        a = make_session(self.db, self.uid, seed=1)
        b = make_session(self.db, self.uid, seed=2)
        n_b = len(self.db.get_sensor_data(b))
        self.assertTrue(self.db.delete_session(a))
        self.assertIsNone(self.db.get_session(a))
        self.assertEqual(self.db.get_sensor_data(a), [])
        self.assertEqual(self.db.get_turns(a), [])
        self.assertEqual(len(self.db.get_sensor_data(b)), n_b)
        self.assertGreater(len(self.db.get_turns(b)), 0)
        self.assertFalse(self.db.delete_session(a))   # drugi raz: nic do usunięcia

    def test_notes_roundtrip_and_blank_clears(self):
        sid = make_session(self.db, self.uid)
        self.db.update_notes(sid, "  Kasprowy, twardo\nwiatr ")
        self.assertEqual(self.db.get_session(sid)["notes"], "Kasprowy, twardo\nwiatr")
        self.db.update_notes(sid, "   ")
        self.assertIsNone(self.db.get_session(sid)["notes"])

    def test_get_session_unknown_returns_none(self):
        self.assertIsNone(self.db.get_session(999))
        self.assertIsNone(load_session(self.db, 999))

    def test_migration_adds_missing_columns_and_keeps_data(self):
        path = os.path.join(self.dir, "old.db")
        con = sqlite3.connect(path)
        con.executescript("""
            CREATE TABLE USER (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE);
            CREATE TABLE TRAINING_SESSION (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
                date TEXT NOT NULL, sensor_placement TEXT DEFAULT 'boot_shin');
            INSERT INTO USER (username) VALUES ('stary');
            INSERT INTO TRAINING_SESSION (user_id, date) VALUES (1, '2026-01-01T10:00:00');
        """)
        con.commit(); con.close()
        db = Database(path)
        self.addCleanup(db.close)
        s = db.get_session(1)
        self.assertEqual(s["date"], "2026-01-01T10:00:00")
        self.assertIsNone(s["notes"])
        self.assertEqual(s["turn_count"], 0)
        db.update_notes(1, "działa")
        self.assertEqual(db.get_session(1)["notes"], "działa")

    def test_load_session_session_without_samples(self):
        sid = self.db.create_session(self.uid)
        loaded = load_session(self.db, sid)
        self.assertIsNone(loaded["analysis"])
        self.assertEqual(loaded["t"], [])


class ExportTests(TempDirCase):
    def setUp(self):
        super().setUp()
        self.db = Database(os.path.join(self.dir, "a.db"))
        self.addCleanup(self.db.close)
        self.uid = self.db.get_or_create_user("u")
        self.sid = make_session(self.db, self.uid, duration=40, notes="Śnieg <twardy> & mgła: żółć")
        self.loaded = load_session(self.db, self.sid)

    def test_raw_csv_roundtrips_through_importer(self):
        path = os.path.join(self.dir, "raw.csv")
        n = export.export_raw_csv(path, self.loaded["data"])
        self.assertEqual(n, 2000)
        back = parse_csv_file(path)
        self.assertEqual(len(back), 2000)
        orig = self.loaded["data"]
        for k in (0, 777, 1999):
            for a, b in zip(orig[k], back[k]):
                self.assertAlmostEqual(a, b, places=3)

    def test_raw_csv_excel_pl_uses_semicolon_and_decimal_comma_and_reimports(self):
        path = os.path.join(self.dir, "pl.csv")
        export.export_raw_csv(path, self.loaded["data"][:100], "excel_pl")
        with open(path, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
        self.assertEqual(lines[0].count(";"), 6)
        self.assertIn(",", lines[2])           # ułamki z przecinkiem
        self.assertNotIn(".", lines[2])
        back = parse_csv_file(path)
        self.assertEqual(len(back), 100)
        self.assertAlmostEqual(back[50][0], self.loaded["data"][50][0], places=3)

    def test_long_recording_keeps_time_resolution(self):
        rows = [(3600.0 + i * 0.02, 0, 0, 9.81, 0, 0, 0) for i in range(5)]
        path = os.path.join(self.dir, "long.csv")
        export.export_raw_csv(path, rows)
        back = parse_csv_file(path)
        self.assertEqual(len({round(r[0], 4) for r in back}), 5)
        self.assertAlmostEqual(back[1][0] - back[0][0], 0.02, places=4)

    def test_turns_csv(self):
        path = os.path.join(self.dir, "turns.csv")
        n = export.export_turns_csv(path, self.loaded["turns"])
        self.assertEqual(n, len(self.loaded["turns"]))
        with open(path, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
        self.assertEqual(len(lines), n + 1)
        self.assertTrue(lines[0].startswith("turn,direction"))
        self.assertEqual(lines[1].split(",")[0], "1")

    def test_pdf_is_valid_multipage_with_polish_text(self):
        path = os.path.join(self.dir, "r.pdf")
        export.export_report_pdf(path, self.loaded, "Patryk")
        with open(path, "rb") as f:
            head = f.read(5)
        self.assertEqual(head, b"%PDF-")
        self.assertGreater(os.path.getsize(path), 20_000)
        if shutil.which("pdftotext"):
            text = subprocess.run(["pdftotext", "-layout", path, "-"], capture_output=True, text=True).stdout
            self.assertIn("SkiSense Index", text)
            self.assertIn("Śnieg <twardy> & mgła: żółć", text)    # znaki specjalne i polskie litery
            self.assertIn("Strona 1", text)
            self.assertIn("Skręty", text)

    def test_pdf_for_session_without_data_raises(self):
        empty = self.db.create_session(self.uid)
        with self.assertRaises(ValueError):
            export.export_report_pdf(os.path.join(self.dir, "x.pdf"), load_session(self.db, empty))

    def test_pdf_with_no_turns(self):
        sid = self.db.create_session(self.uid)
        self.db.insert_sensor_batch(sid, [(i * 0.02, 0, 0, 9.81, 0, 0, 0) for i in range(200)])
        path = os.path.join(self.dir, "flat.pdf")
        export.export_report_pdf(path, load_session(self.db, sid))
        self.assertGreater(os.path.getsize(path), 5000)


class GuiDay3Tests(TempDirCase):
    def setUp(self):
        super().setUp()
        self.saves = []
        self.next_path = None
        self.w = main_window.MainWindow(db_path=os.path.join(self.dir, "g.db"),
                                        save_path_provider=self._provide)
        self.w.resize(560, 900)
        self.w.show()
        self.db, self.uid = self.w.db, self.w.user_id
        self.hist, self.res = self.w.history_tab, self.w.results_tab

    def tearDown(self):
        self.w.close()
        super().tearDown()

    def _provide(self, kind, default_name):
        self.saves.append((kind, default_name))
        return self.next_path

    def select(self, *ids):
        self.hist.list_widget.clearSelection()
        for i in range(self.hist.list_widget.count()):
            it = self.hist.list_widget.item(i)
            if it.data(Qt.UserRole) in ids:
                it.setSelected(True)

    def test_history_button_states_follow_selection(self):
        a = make_session(self.db, self.uid, seed=1)
        b = make_session(self.db, self.uid, seed=2)
        self.hist.refresh()
        self.select()
        self.assertFalse(self.hist.open_btn.isEnabled())
        self.assertFalse(self.hist.compare_btn.isEnabled())
        self.assertFalse(self.hist.delete_btn.isEnabled())
        self.select(a)
        self.assertTrue(self.hist.open_btn.isEnabled())
        self.assertFalse(self.hist.compare_btn.isEnabled())
        self.assertTrue(self.hist.delete_btn.isEnabled())
        self.select(a, b)
        self.assertFalse(self.hist.open_btn.isEnabled())
        self.assertTrue(self.hist.compare_btn.isEnabled())
        self.assertEqual(self.hist.delete_btn.text(), "Usuń (2)")

    def test_open_selected_shows_results(self):
        a = make_session(self.db, self.uid)
        self.hist.refresh()
        self.select(a)
        self.hist.open_btn.click()
        self.assertEqual(self.res.session_id, a)
        self.assertEqual(self.res.title_label.text(), f"Zjazd #{a}")
        self.assertTrue(self.res.export_btn.isEnabled())
        self.assertTrue(self.res.note_btn.isEnabled())

    def test_delete_asks_for_confirmation_and_clears_open_results(self):
        a = make_session(self.db, self.uid, seed=1)
        b = make_session(self.db, self.uid, seed=2)
        self.hist.refresh()
        self.w._show_results(a)

        self.select(a)
        with mock.patch.object(QMessageBox, "question", return_value=QMessageBox.No):
            self.hist.delete_btn.click()
        self.assertIsNotNone(self.db.get_session(a))

        with mock.patch.object(QMessageBox, "question", return_value=QMessageBox.Yes):
            self.hist.delete_btn.click()
        self.assertIsNone(self.db.get_session(a))
        self.assertIsNotNone(self.db.get_session(b))
        self.assertEqual(self.hist.list_widget.count(), 1)
        self.assertIsNone(self.res.session_id)
        self.assertFalse(self.res.export_btn.isEnabled())
        self.assertEqual(self.hist.tile_count.value_label.text(), "1")

    def test_delete_many_keeps_open_results_of_other_session(self):
        ids = [make_session(self.db, self.uid, seed=s) for s in (1, 2, 3)]
        self.hist.refresh()
        self.w._show_results(ids[2])
        self.select(ids[0], ids[1])
        with mock.patch.object(QMessageBox, "question", return_value=QMessageBox.Yes):
            self.hist.delete_btn.click()
        self.assertEqual(self.res.session_id, ids[2])
        self.assertEqual([s[0] for s in self.db.list_sessions(self.uid)], [ids[2]])

    def test_note_is_saved_shown_and_listed(self):
        a = make_session(self.db, self.uid)
        self.hist.refresh()
        self.w._show_results(a)
        with mock.patch.object(QInputDialog, "getMultiLineText", return_value=("Mgła, twardy śnieg", True)):
            self.res.note_btn.click()
        self.assertEqual(self.db.get_session(a)["notes"], "Mgła, twardy śnieg")
        self.assertTrue(self.res.notes_label.isVisible())
        self.assertIn("Mgła", self.res.notes_label.text())
        labels = [l.text() for l in self.hist.list_widget.itemWidget(self.hist.list_widget.item(0)).findChildren(
            main_window.QLabel)]
        self.assertTrue(any("Mgła" in t for t in labels))

        # anulowanie nie zmienia notatki, puste ją usuwa
        with mock.patch.object(QInputDialog, "getMultiLineText", return_value=("zmiana", False)):
            self.res.note_btn.click()
        self.assertEqual(self.db.get_session(a)["notes"], "Mgła, twardy śnieg")
        with mock.patch.object(QInputDialog, "getMultiLineText", return_value=("  ", True)):
            self.res.note_btn.click()
        self.assertIsNone(self.db.get_session(a)["notes"])
        self.assertFalse(self.res.notes_label.isVisible())

    def test_export_writes_files_via_menu_actions(self):
        a = make_session(self.db, self.uid, duration=20)
        self.w._show_results(a)
        actions = {act.text(): act for act in self.res.export_btn.menu().actions()}
        self.assertEqual(len(actions), 4)
        with mock.patch.object(QMessageBox, "information") as info:
            for text, ext in (("Raport PDF", ".pdf"), ("Dane surowe CSV", ".csv"),
                              ("Dane surowe CSV (polski Excel)", "_pl.csv"), ("Skręty CSV", "_t.csv")):
                self.next_path = os.path.join(self.dir, "out" + ext)
                actions[text].trigger()
                self.assertTrue(os.path.getsize(self.next_path) > 100, text)
            self.assertEqual(info.call_count, 4)
        self.assertEqual([k for k, _ in self.saves], ["pdf", "raw", "raw_pl", "turns"])
        self.assertEqual(self.saves[0][1], f"zjazd_{a}.pdf")

    def test_export_cancelled_and_failing_paths(self):
        a = make_session(self.db, self.uid, duration=10)
        self.w._show_results(a)
        self.next_path = ""
        with mock.patch.object(QMessageBox, "information") as info, mock.patch.object(QMessageBox, "warning") as warn:
            self.res.export("raw")
            self.assertFalse(info.called or warn.called)
            self.next_path = os.path.join(self.dir, "nie_ma_takiego_folderu", "x.csv")
            self.res.export("raw")
            self.assertTrue(warn.called)
            self.assertFalse(info.called)

    def test_compare_dialog_orders_sessions_and_colours_changes(self):
        good = make_session(self.db, self.uid, noise=0.1, seed=1)
        bad = make_session(self.db, self.uid, noise=2.0, amp=25.0, seed=2)
        self.hist.refresh()
        self.select(bad, good)
        captured = {}

        def fake_exec(dlg):
            captured["dlg"] = dlg
            return 0

        with mock.patch.object(main_window.CompareDialog, "exec_", fake_exec):
            self.hist.compare_btn.click()
        dlg = captured["dlg"]
        self.assertEqual(dlg.name_a, f"Zjazd #{good}")      # starsza (niższe id) po lewej
        self.assertEqual(dlg.name_b, f"Zjazd #{bad}")
        self.assertEqual(dlg.table.rowCount(), len(dlg.METRICS))
        ssi_a = int(dlg.table.item(0, 1).text())
        ssi_b = int(dlg.table.item(0, 2).text())
        self.assertEqual(dlg.table.item(0, 3).text(), ("+" if ssi_b > ssi_a else "") + str(ssi_b - ssi_a))
        # SSI spadło -> czerwona zmiana
        if ssi_b < ssi_a:
            self.assertEqual(dlg.table.item(0, 3).foreground().color().name(), main_window.C_RED)
        # drgania: wzrost = źle (czerwony), spadek = dobrze (zielony)
        row = [m[0] for m in dlg.METRICS].index("vibration")
        va, vb = float(dlg.table.item(row, 1).text()), float(dlg.table.item(row, 2).text())
        if vb > va:
            self.assertEqual(dlg.table.item(row, 3).foreground().color().name(), main_window.C_RED)
        elif vb < va:
            self.assertEqual(dlg.table.item(row, 3).foreground().color().name(), main_window.C_GREEN)

    def test_compare_real_dialog_renders(self):
        a = make_session(self.db, self.uid, seed=1)
        b = make_session(self.db, self.uid, seed=2)
        dlg = main_window.CompareDialog(load_session(self.db, a), load_session(self.db, b))
        dlg.show()
        app.processEvents()
        dlg.grab()
        dlg.close()

    def test_compare_session_without_data_warns(self):
        a = make_session(self.db, self.uid)
        empty = self.db.create_session(self.uid)
        self.hist.refresh()
        self.select(a, empty)
        with mock.patch.object(QMessageBox, "warning") as warn, \
                mock.patch.object(main_window.CompareDialog, "exec_") as ex:
            self.hist.compare_btn.click()
        self.assertTrue(warn.called)
        self.assertFalse(ex.called)

    def test_showing_deleted_session_does_not_crash(self):
        self.res.show_session(12345)
        self.assertIsNone(self.res.session_id)
        self.assertIn("nie istnieje", self.res.subtitle_label.text())


if __name__ == "__main__":
    unittest.main(verbosity=2)
