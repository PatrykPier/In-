"""Testy GUI: odtwarzanie CSV, kalibracja postoju i okno mapowania osi."""

import math
import os
import random
import sys
import tempfile
import unittest
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt5.QtWidgets import QApplication, QMessageBox

import main_window
from signal_tools import AxisMap, load_calibration
from test_gui import spin

app = QApplication.instance() or QApplication([])


def write_csv(path, rest_s=0.0, ride_s=20.0, gyro_bias=0.0, header=True):
    rnd = random.Random(5)
    om = 2 * math.pi / 2.2
    lines = ["t_ms,ax,ay,az,gx,gy,gz"] if header else []
    n_rest, n_ride = int(rest_s * 50), int(ride_s * 50)
    for i in range(n_rest + n_ride):
        t = i * 20
        if i < n_rest:
            ax, gz = 0.3, gyro_bias
        else:
            x = (i - n_rest) * 0.02
            ax, gz = 0.3 + 2.2 * math.sin(om * x), gyro_bias + 55 * math.cos(om * x)
        lines.append(f"{t},{ax + rnd.gauss(0, .03):.3f},{rnd.gauss(0, .03):.3f},{9.81 + rnd.gauss(0, .03):.3f},"
                     f"{rnd.gauss(0, .1):.2f},{rnd.gauss(0, .1):.2f},{gz + rnd.gauss(0, .1):.2f}")
    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")


class CsvGuiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmp.name, "t.db")
        self.csv_path = os.path.join(self.tmp.name, "ride.csv")

    def tearDown(self):
        self.tmp.cleanup()

    def make_window(self, path):
        w = main_window.MainWindow(db_path=self.db_path, csv_path_provider=lambda: path)
        app.setStyleSheet(main_window.APP_QSS)
        w.show()
        live = w.live_tab
        live.source_combo.setCurrentIndex(live.source_combo.findData("csv"))
        live.speed_combo.setCurrentIndex(live.speed_combo.findData(10.0))
        return w, live

    def test_replay_records_and_auto_saves_at_end_of_file(self):
        write_csv(self.csv_path, ride_s=24)
        w, live = self.make_window(self.csv_path)
        self.assertTrue(live.csv_card.isVisible())
        self.assertFalse(live.sim_card.isVisible())

        live.connect_btn.click()
        self.assertTrue(spin(until=lambda: live.streaming))
        with mock.patch.object(QMessageBox, "information") as info:
            live.record_btn.click()
            self.assertTrue(spin(until=lambda: not live.active, timeout=10), "odtwarzanie się nie skończyło")
        self.assertTrue(info.called)
        sessions = w.db.list_sessions(w.user_id)
        self.assertEqual(len(sessions), 1)
        data = w.db.get_sensor_data(sessions[0][0])
        self.assertGreater(len(data), 300)
        self.assertTrue(w.top_bar.status_text.text().startswith("Plik CSV"))
        self.assertTrue(live.source_combo.isEnabled())
        w.close()

    def test_replay_can_be_run_twice(self):
        write_csv(self.csv_path, ride_s=5)
        w, live = self.make_window(self.csv_path)
        for _ in range(2):
            live.connect_btn.click()
            self.assertTrue(spin(until=lambda: live.streaming))
            self.assertTrue(spin(until=lambda: not live.active, timeout=10))
        w.close()

    def test_bad_file_shows_warning_and_does_not_connect(self):
        with open(self.csv_path, "w") as f:
            f.write("to nie są dane\n")
        w, live = self.make_window(self.csv_path)
        with mock.patch.object(QMessageBox, "warning") as warn:
            live.connect_btn.click()
        self.assertTrue(warn.called)
        self.assertFalse(live.active)
        w.close()

    def test_cancelled_file_dialog_does_not_connect(self):
        w, live = self.make_window("")
        live.connect_btn.click()
        self.assertFalse(live.active)
        w.close()

    def test_calibration_removes_bias_and_is_persisted(self):
        write_csv(self.csv_path, rest_s=15, ride_s=5, gyro_bias=4.0)
        w, live = self.make_window(self.csv_path)
        self.assertFalse(live.calib_btn.isEnabled())
        live.connect_btn.click()
        self.assertTrue(spin(until=lambda: live.streaming))
        self.assertTrue(live.calib_btn.isEnabled())
        live.calib_btn.click()
        self.assertTrue(spin(until=lambda: live.calibration.calibrated, timeout=6), "kalibracja nie zakończyła się")
        self.assertAlmostEqual(live.calibration.gyro_bias[2], 4.0, delta=0.3)
        self.assertAlmostEqual(live.calibration.accel_offset[0], 0.3, delta=0.1)
        self.assertIn("wykonana", live.calib_label.text())
        saved = load_calibration(os.path.join(self.tmp.name, "calibration.json"))
        self.assertTrue(saved.calibrated)
        live.connect_btn.click()
        w.close()

        # po ponownym uruchomieniu aplikacji kalibracja jest wczytana
        w2 = main_window.MainWindow(db_path=self.db_path)
        self.assertTrue(w2.live_tab.calibration.calibrated)
        w2.close()

    def test_calibration_while_moving_is_rejected(self):
        write_csv(self.csv_path, rest_s=0, ride_s=20)   # jedzie od początku
        w, live = self.make_window(self.csv_path)
        live.connect_btn.click()
        self.assertTrue(spin(until=lambda: live.streaming))
        with mock.patch.object(QMessageBox, "warning") as warn:
            live.calib_btn.click()
            self.assertTrue(spin(until=lambda: warn.called, timeout=6))
        self.assertFalse(live.calibration.calibrated)
        self.assertTrue(spin(until=lambda: live.calib_btn.isEnabled() or not live.active, timeout=6))
        live.connect_btn.click() if live.active else None
        w.close()

    def test_calibration_aborted_by_disconnect_resets_state(self):
        write_csv(self.csv_path, rest_s=30, ride_s=1)
        w, live = self.make_window(self.csv_path)
        live.speed_combo.setCurrentIndex(0)          # 1x, żeby nie skończyło się samo
        live.connect_btn.click()
        spin(until=lambda: live.streaming)
        live.calib_btn.click()
        self.assertIsNotNone(live._calib_buf)
        live.connect_btn.click()                      # rozłączamy w trakcie kalibracji
        self.assertIsNone(live._calib_buf)
        self.assertNotIn("Kalibracja…", live.calib_label.text())
        w.close()

    def test_axis_mapping_is_applied_to_recorded_data(self):
        write_csv(self.csv_path, ride_s=6)
        w, live = self.make_window(self.csv_path)
        live.calibration = live.calibration.with_axis_map(AxisMap(src=[1, 0, 2], sign=[1, 1, 1]))
        live.connect_btn.click()
        spin(until=lambda: live.streaming)
        with mock.patch.object(QMessageBox, "information"):
            live.record_btn.click()
            spin(until=lambda: not live.active, timeout=10)
        sid = w.db.list_sessions(w.user_id)[0][0]
        data = w.db.get_sensor_data(sid)
        # oś X czujnika (boczna, rozbujana) trafiła na Y, więc nowe X to szum o średniej ~0
        xs = [r[1] for r in data]
        ys = [r[2] for r in data]
        self.assertLess(max(abs(x) for x in xs), 0.5)
        self.assertGreater(max(abs(y) for y in ys), 1.5)
        w.close()

    def test_axis_dialog_validation(self):
        dlg = main_window.AxisMapDialog(AxisMap())
        dlg.combos[0].setCurrentIndex(1)           # X i Y wskazują tę samą oś czujnika
        dlg._accept()
        self.assertIn("tylko raz", dlg.warn.text())
        self.assertEqual(dlg.result(), 0)
        dlg.combos[1].setCurrentIndex(0)           # zamiana X<->Y jest poprawna
        dlg.checks[2].setChecked(True)
        self.assertEqual(dlg.axis_map().src, [1, 0, 2])
        self.assertEqual(dlg.axis_map().sign, [1, 1, -1])
        dlg._accept()
        self.assertEqual(dlg.result(), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
