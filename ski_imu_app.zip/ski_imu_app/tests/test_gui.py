"""
Test całego GUI bez sprzętu: symulator i atrapa ESP32 po BLE.

    python -m unittest discover -s tests -v
"""

import os
import sys
import tempfile
import time
import unittest
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt5.QtWidgets import QApplication, QMessageBox

import main_window
from test_ble import FakeBackend

app = QApplication.instance() or QApplication([])
app.setStyleSheet(main_window.APP_QSS)


def spin(seconds=0.0, until=None, timeout=8.0):
    end = time.monotonic() + (timeout if until else seconds)
    while time.monotonic() < end:
        app.processEvents()
        if until and until():
            return True
        time.sleep(0.005)
    return not until


class GuiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmp.name, "test.db")

    def tearDown(self):
        self.tmp.cleanup()

    def make_window(self, backend=None):
        w = main_window.MainWindow(ble_backend=backend, db_path=self.db_path)
        w.resize(520, 900)
        w.show()
        return w

    def test_simulation_flow_record_save_and_show_results(self):
        w = self.make_window()
        live = w.live_tab
        self.assertFalse(live.record_btn.isEnabled())
        live.connect_btn.click()
        self.assertTrue(spin(until=lambda: live.streaming))
        self.assertTrue(live.record_btn.isEnabled())
        self.assertIn("Symulacja", w.top_bar.status_text.text())
        spin(1.0)
        from test_chart import drawn_pixels
        self.assertGreater(drawn_pixels(live.chart), 1000, "wykres na żywo jest pusty po połączeniu")

        with mock.patch.object(QMessageBox, "information") as info:
            live.record_btn.click()
            spin(4.0)  # ok. 4 s * 50 Hz
            live.record_btn.click()
            self.assertTrue(info.called)
            self.assertIn("Zapisano sesję", info.call_args[0][2])

        sessions = w.db.list_sessions(w.user_id)
        self.assertEqual(len(sessions), 1)
        self.assertGreater(len(w.db.get_sensor_data(sessions[0][0])), 100)

        w._show_results(sessions[0][0])
        spin(0.1)
        live.connect_btn.click()
        self.assertFalse(live.active)
        w.close()

    def test_ble_source_with_fake_esp32(self):
        w = self.make_window(backend=FakeBackend())
        live = w.live_tab
        live.source_combo.setCurrentIndex(1)  # ESP32 BLE
        self.assertFalse(live.sim_card.isVisible())
        self.assertEqual(live.source_kind, "ble")

        live.connect_btn.click()
        self.assertTrue(spin(until=lambda: live.streaming), "BLE nie wystartowało")
        self.assertIn("ESP32", w.top_bar.status_text.text())
        self.assertIn("połączone", live.status_label.text())
        self.assertTrue(live.record_btn.isEnabled())
        self.assertFalse(live.source_combo.isEnabled())  # nie zmieniamy źródła w trakcie

        with mock.patch.object(QMessageBox, "information"):
            live.record_btn.click()
            spin(1.0)
            live.record_btn.click()
        self.assertEqual(len(w.db.list_sessions(w.user_id)), 1)

        live.connect_btn.click()  # rozłącz
        self.assertFalse(live.streaming)
        self.assertEqual(w.top_bar.status_text.text(), "ESP32 · Rozłączono")
        self.assertTrue(live.source_combo.isEnabled())
        w.close()

    def test_connection_loss_during_recording_keeps_stop_button_enabled(self):
        be = FakeBackend(packets_per_connection=60, drop_after_packets=True)
        w = self.make_window(backend=be)
        live = w.live_tab
        live.source_combo.setCurrentIndex(1)
        live.connect_btn.click()
        self.assertTrue(spin(until=lambda: live.streaming))
        live.record_btn.click()  # start nagrywania
        self.assertTrue(live.recording)
        # czekamy, aż połączenie zostanie zerwane...
        self.assertTrue(spin(until=lambda: not live.streaming), "połączenie nie zostało zerwane")
        self.assertTrue(live.record_btn.isEnabled(), "nie da się zakończyć nagrywania po utracie połączenia")
        # ...i odzyskane
        self.assertTrue(spin(until=lambda: live.streaming), "brak ponownego połączenia")
        with mock.patch.object(QMessageBox, "information"):
            live.record_btn.click()
        self.assertEqual(len(w.db.list_sessions(w.user_id)), 1)
        live.connect_btn.click()
        w.close()

    def test_close_window_while_streaming_stops_thread(self):
        w = self.make_window(backend=FakeBackend())
        live = w.live_tab
        live.source_combo.setCurrentIndex(1)
        live.connect_btn.click()
        self.assertTrue(spin(until=lambda: live.streaming))
        worker = live.source._worker
        w.close()
        self.assertTrue(worker.wait(5000))
        self.assertFalse(worker.isRunning())

    def test_short_recording_is_not_saved(self):
        w = self.make_window()
        live = w.live_tab
        live.connect_btn.click()
        spin(until=lambda: live.streaming)
        with mock.patch.object(QMessageBox, "information") as info:
            live.record_btn.click()
            live.record_btn.click()
            self.assertIn("za mało", info.call_args[0][1].lower())
        self.assertEqual(len(w.db.list_sessions(w.user_id)), 0)
        live.connect_btn.click()
        w.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
