"""Regresja: wykres na żywo musi się rysować także po wyczyszczeniu bufora (reset)."""

import math
import os
import sys
import time
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt5.QtWidgets import QApplication

from charts import LiveChart

app = QApplication.instance() or QApplication([])


def drawn_pixels(widget):
    img = widget.grab().toImage()
    bg = img.pixel(2, 2)
    return sum(1 for x in range(0, img.width(), 3) for y in range(0, img.height(), 3) if img.pixel(x, y) != bg)


def pump(seconds):
    end = time.time() + seconds
    while time.time() < end:
        app.processEvents()
        time.sleep(0.005)


class LiveChartTests(unittest.TestCase):
    def test_chart_draws_after_reset(self):
        c = LiveChart()
        c.resize(600, 400)
        c.show()
        pump(0.2)
        c.reset()
        for i in range(300):
            c.add_sample(i * 0.02, 2 * math.sin(i * 0.1), 50 * math.cos(i * 0.1))
        pump(0.4)
        self.assertGreater(drawn_pixels(c), 1000, "wykres jest pusty po reset()")
        self.assertEqual(c._n, 300)
        c.reset()
        self.assertEqual(c._n, 0)
        c.close()

    def test_ring_buffer_keeps_last_samples(self):
        c = LiveChart()
        for i in range(LiveChart.CAPACITY + 50):
            c.add_sample(i * 0.02, 0, 0)
        self.assertEqual(c._n, LiveChart.CAPACITY)
        self.assertAlmostEqual(c._t[-1], (LiveChart.CAPACITY + 49) * 0.02)


if __name__ == "__main__":
    unittest.main(verbosity=2)
