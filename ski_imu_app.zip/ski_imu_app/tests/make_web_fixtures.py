"""
Generuje wzorcowe wyniki analizy z Pythona dla testów zgodności wersji webowej (web/tests/parity.test.mjs).

    python tests/make_web_fixtures.py
"""
import json
import math
import os
import random
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from data_analysis import moving_average, detect_turns, full_session_analysis


def make(seed, duration, amp, noise, period=2.2, drift=0.0, offset_z=0.0):
    rnd = random.Random(seed)
    om = 2 * math.pi / period
    t, ax, ay, az, gx, gy, gz = [], [], [], [], [], [], []
    for i in range(int(duration * 50)):
        x = i * 0.02
        t.append(round(x, 4))
        ax.append(round(2.2 * math.sin(om * x) + rnd.gauss(0, noise), 4))
        ay.append(round(0.3 * math.sin(om * x * 0.5) + rnd.gauss(0, 0.1), 4))
        az.append(round(9.81 + offset_z + rnd.gauss(0, 0.2 + noise / 4), 4))
        gx.append(round(rnd.gauss(0, 3), 3))
        gy.append(round(rnd.gauss(0, 3), 3))
        gz.append(round(amp * math.cos(om * x) + drift + rnd.gauss(0, noise * 15), 3))
    return dict(t=t, ax=ax, ay=ay, az=az, gx=gx, gy=gy, gz=gz)


CASES = {
    "clean": make(1, 60, 55, 0.1),
    "noisy": make(2, 60, 55, 0.5),
    "gentle": make(3, 45, 25, 0.2, period=3.0),
    "rough": make(4, 40, 55, 1.2),
    "tilted": make(5, 30, 55, 0.2, offset_z=-1.5),
    "still": make(6, 20, 0.0, 0.1),
    "short": make(7, 1.5, 55, 0.1),
}

out = {}
for name, d in CASES.items():
    accf = moving_average(d["ax"], 5)
    gyrf = moving_average(d["gz"], 5)
    turns = detect_turns(d["t"], gyrf, accf)
    a = full_session_analysis(d["t"], d["ax"], d["ay"], d["az"], gyrf, turns)
    out[name] = {
        "samples": d,
        "turns": [{"index": x.index, "startT": x.start_t, "endT": x.end_t, "direction": x.direction,
                   "score": x.score, "maxLateralAccel": x.max_lateral_accel, "maxEdgeAngle": x.max_edge_angle}
                  for x in turns],
        "analysis": a,
    }

dest = os.path.join(ROOT, "web", "tests", "fixtures", "parity.json")
os.makedirs(os.path.dirname(dest), exist_ok=True)
with open(dest, "w") as f:
    json.dump(out, f)
print("zapisano", dest, {k: len(v["turns"]) for k, v in out.items()})
