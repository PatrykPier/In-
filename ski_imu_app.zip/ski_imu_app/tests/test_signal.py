"""Testy importu CSV, kalibracji/mapowania osi i wykrywania skrętów (bez GUI i sprzętu)."""

import math
import os
import random
import sys
import tempfile
import unittest
import unittest.mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from csv_import import parse_csv_text, parse_csv_file, CsvFormatError
from signal_tools import (
    AxisMap, Calibration, calibrate_from_rest, save_calibration, load_calibration,
)
from data_analysis import detect_turns, moving_average
from ble_source import encode_packet, decode_packet


def sine_signal(duration=60.0, amp=55.0, period=2.2, noise=0.0, seed=1):
    rnd = random.Random(seed)
    om = 2 * math.pi / period
    t = [i * 0.02 for i in range(int(duration * 50))]
    gz = [amp * math.cos(om * x) + rnd.gauss(0, noise) for x in t]
    ax = [2.2 * math.sin(om * x) + rnd.gauss(0, noise / 15) for x in t]
    return t, ax, gz


class CsvTests(unittest.TestCase):
    def test_header_ms_si_units(self):
        text = "t_ms,ax,ay,az,gx,gy,gz\n1000,0.1,0.2,9.8,1,2,3\n1020,0.2,0.3,9.7,1,2,4\n1040,0,0,9.8,0,0,0\n"
        rows = parse_csv_text(text)
        self.assertEqual(len(rows), 3)
        self.assertAlmostEqual(rows[1][0], 0.02)
        self.assertAlmostEqual(rows[0][3], 9.8)
        self.assertEqual(rows[1][6], 4)

    def test_seconds_and_semicolons_with_decimal_comma(self):
        text = "czas;ax;ay;az;gx;gy;gz\n0,00;0,5;0;9,81;0;0;1\n0,02;0,6;0;9,80;0;0;2\n"
        rows = parse_csv_text(text)
        self.assertAlmostEqual(rows[1][0], 0.02)
        self.assertAlmostEqual(rows[0][1], 0.5)

    def test_raw_lsb_detected_and_scaled(self):
        text = "0 100 -200 4096 0 0 655\n20 100 -200 4096 0 0 655\n"
        rows = parse_csv_text(text)
        self.assertAlmostEqual(rows[0][3], 9.81, places=2)
        self.assertAlmostEqual(rows[0][6], 10.0, places=2)

    def test_matches_ble_decoder(self):
        pkt = encode_packet(500, 123, -456, 4000, 70, -80, 655)
        t_ms, *vals = decode_packet(pkt)
        text = "500 123 -456 4000 70 -80 655\n520 123 -456 4000 70 -80 655\n"
        row = parse_csv_text(text)[0]
        for a, b in zip(vals, row[1:]):
            self.assertAlmostEqual(a, b, places=6)

    def test_six_columns_get_50hz_time(self):
        rows = parse_csv_text("0 0 9.8 0 0 1\n0 0 9.8 0 0 2\n0 0 9.8 0 0 3\n")
        self.assertAlmostEqual(rows[2][0], 0.04)

    def test_serial_monitor_junk_is_skipped(self):
        text = "ESP32 start\nMPU OK\n# komentarz\n0,0,0,9.8,0,0,0\nbłąd odczytu\n20,0,0,9.8,0,0,0\n"
        self.assertEqual(len(parse_csv_text(text)), 2)

    def test_time_reset_stays_monotonic(self):
        text = "1000 0 0 9.8 0 0 0\n1020 0 0 9.8 0 0 0\n0 0 0 9.8 0 0 0\n20 0 0 9.8 0 0 0\n"
        times = [r[0] for r in parse_csv_text(text)]
        self.assertEqual(times, sorted(times))
        self.assertEqual(len(set(times)), 4)

    def test_uint32_wrap(self):
        text = f"{2**32 - 20} 0 0 9.8 0 0 0\n0 0 0 9.8 0 0 0\n20 0 0 9.8 0 0 0\n"
        times = [r[0] for r in parse_csv_text(text)]
        self.assertAlmostEqual(times[2], 0.04)

    def test_errors(self):
        with self.assertRaises(CsvFormatError):
            parse_csv_text("nic tu nie ma\n")
        with self.assertRaises(CsvFormatError):
            parse_csv_text("1 2 3\n4 5 6\n")

    def test_file_with_polish_encoding(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "a.csv")
            with open(p, "wb") as f:
                f.write("Błąd\n0 0 0 9.8 0 0 0\n20 0 0 9.8 0 0 0\n".encode("cp1250"))
            self.assertEqual(len(parse_csv_file(p)), 2)


class CalibrationTests(unittest.TestCase):
    def rest_samples(self, bias_g=(1.5, -0.7, 0.3), off_a=(0.4, -0.2, 0.0), n=100, noise=0.05):
        rnd = random.Random(3)
        return [(i * 0.02, off_a[0] + rnd.gauss(0, noise), off_a[1] + rnd.gauss(0, noise), 9.81 + rnd.gauss(0, noise),
                 bias_g[0] + rnd.gauss(0, noise), bias_g[1] + rnd.gauss(0, noise), bias_g[2] + rnd.gauss(0, noise))
                for i in range(n)]

    def test_calibration_zeroes_rest_signal(self):
        samples = self.rest_samples()
        cal = calibrate_from_rest(samples)
        out = [cal.apply(*s[1:]) for s in samples]
        for k in (0, 1, 3, 4, 5):
            self.assertAlmostEqual(sum(o[k] for o in out) / len(out), 0.0, places=6)
        self.assertAlmostEqual(sum(o[2] for o in out) / len(out), 9.81, places=1)  # grawitacja zostaje
        self.assertTrue(cal.calibrated)

    def test_rejects_motion_and_too_few_samples(self):
        moving = [(i * 0.02, 0, 0, 9.81, 100 * math.sin(i), 0, 0) for i in range(100)]
        with self.assertRaises(ValueError):
            calibrate_from_rest(moving)
        with self.assertRaises(ValueError):
            calibrate_from_rest(self.rest_samples(n=5))

    def test_axis_map_swaps_and_flips_both_sensors(self):
        am = AxisMap(src=[1, 0, 2], sign=[-1, 1, 1])
        cal = Calibration(axis_map=am)
        ax, ay, az, gx, gy, gz = cal.apply(1, 2, 3, 10, 20, 30)
        self.assertEqual((ax, ay, az), (-2, 1, 3))
        self.assertEqual((gx, gy, gz), (-20, 10, 30))

    def test_axis_map_validation(self):
        self.assertTrue(AxisMap().is_valid())
        self.assertFalse(AxisMap(src=[0, 0, 2]).is_valid())
        self.assertFalse(AxisMap(sign=[1, 2, 1]).is_valid())

    def test_calibration_uses_axis_map(self):
        am = AxisMap(src=[1, 0, 2])
        samples = [(i * 0.02, 0.0, 2.0, 9.81, 0.0, 0.0, 0.0) for i in range(60)]
        cal = calibrate_from_rest(samples, am)
        self.assertAlmostEqual(cal.apply(0.0, 2.0, 9.81, 0, 0, 0)[0], 0.0)   # oś Y czujnika -> X aplikacji

    def test_changing_axes_resets_calibration(self):
        cal = calibrate_from_rest(self.rest_samples())
        self.assertFalse(cal.with_axis_map(AxisMap(src=[2, 1, 0])).calibrated)

    def test_save_load_roundtrip_and_bad_file(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "c.json")
            cal = calibrate_from_rest(self.rest_samples(), AxisMap([1, 0, 2], [1, -1, 1]))
            save_calibration(cal, p)
            self.assertEqual(load_calibration(p).to_dict(), cal.to_dict())
            with open(p, "w") as f:
                f.write("{nie json")
            self.assertFalse(load_calibration(p).calibrated)
            self.assertFalse(load_calibration(os.path.join(d, "brak.json")).calibrated)
            self.assertFalse(load_calibration(None).calibrated)


class TurnDetectionTests(unittest.TestCase):
    def detect(self, **kw):
        t, ax, gz = sine_signal(**kw)
        return detect_turns(t, moving_average(gz, 5), moving_average(ax, 5))

    def test_clean_slalom_count_and_alternating_directions(self):
        turns = self.detect(duration=60)
        self.assertTrue(52 <= len(turns) <= 55, len(turns))
        dirs = [tu.direction for tu in turns]
        self.assertTrue(all(a != b for a, b in zip(dirs, dirs[1:])))

    def test_noisy_signal_still_detected(self):
        turns = self.detect(duration=60, noise=40)
        self.assertTrue(48 <= len(turns) <= 56, len(turns))

    def test_slow_gentle_turns_detected(self):
        turns = self.detect(duration=60, amp=25, noise=10)
        self.assertGreater(len(turns), 45)

    def test_standing_still_with_sensor_noise_gives_no_turns(self):
        false = 0
        for seed in range(30):
            rnd = random.Random(seed)
            t = [i * 0.02 for i in range(1500)]
            g = moving_average([rnd.gauss(0, 6) for _ in t], 5)
            false += len(detect_turns(t, g, g))
        self.assertEqual(false, 0)

    def test_dithering_around_zero_does_not_split_a_turn(self):
        # jeden długi półcykl z drżeniem przy przejściu przez zero nie może dać wielu skrętów
        t = [i * 0.02 for i in range(400)]
        g = []
        for x in t:
            base = 50 * math.sin(2 * math.pi * x / 4.0)          # okres 4 s -> półcykle po 2 s
            jitter = 6 * math.sin(x * 90) if abs(base) < 6 else 0
            g.append(base + jitter)
        turns = detect_turns(t, g, [0] * len(t))
        # 4 półcykle; pierwszy i ostatni nie mają granicy z obu stron, więc zostają 2 pełne skręty
        self.assertEqual(len(turns), 2)
        self.assertNotEqual(turns[0].direction, turns[1].direction)

    def test_degenerate_inputs(self):
        self.assertEqual(detect_turns([], [], []), [])
        self.assertEqual(detect_turns([0, 1], [1, 2], [0, 0]), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)


class TurnScoringTests(unittest.TestCase):
    """Ocena skrętu ma zależeć od chropowatości sygnału, a nie od tempa próbkowania czy siły skrętu."""

    @staticmethod
    def arc(n, amp, hz, noise=0.0, seed=1):
        from data_analysis import score_turn
        rnd = random.Random(seed)
        t = [i / hz for i in range(n)]
        x = [amp * math.sin(math.pi * i / (n - 1)) + rnd.gauss(0, noise) for i in range(n)]
        return score_turn(t, x)[0]

    def test_clean_arc_scores_high(self):
        self.assertGreater(self.arc(56, 2.2, 50), 85)

    def test_score_falls_monotonically_with_noise(self):
        # średnia z 20 losowań, żeby pojedynczy szczęśliwy szum nie psuł porównania
        scores = [sum(self.arc(56, 2.2, 50, noise=s, seed=k) for k in range(20)) / 20 for s in (0.0, 0.2, 0.5, 1.0, 2.0)]
        self.assertEqual(scores, sorted(scores, reverse=True))
        self.assertGreater(scores[0] - scores[-1], 50)
        self.assertLess(scores[-1], 30)

    def test_independent_of_sampling_rate(self):
        a, b = self.arc(56, 2.2, 50), self.arc(111, 2.2, 100)
        self.assertLess(abs(a - b), 3)

    def test_independent_of_turn_strength_for_same_relative_noise(self):
        weak, strong = self.arc(56, 1.5, 50, noise=0.15), self.arc(56, 4.5, 50, noise=0.45)
        self.assertLess(abs(weak - strong), 10)

    def test_degenerate_segments(self):
        from data_analysis import score_turn
        self.assertEqual(score_turn([0.0, 0.02], [1.0, 2.0])[0], 0.0)
        self.assertEqual(score_turn([0.0, 0.0, 0.0], [1.0, 2.0, 1.0])[0], 0.0)
        self.assertEqual(score_turn([0.0, 0.02, 0.04], [0.0, 0.0, 0.0])[1], 0.0)


class DataDirTests(unittest.TestCase):
    def test_source_run_keeps_db_next_to_program(self):
        import database
        self.assertEqual(os.path.dirname(database.DB_PATH), os.path.dirname(os.path.abspath(database.__file__)))

    def test_frozen_run_uses_appdata(self):
        import database
        with tempfile.TemporaryDirectory() as d, \
                unittest.mock.patch.object(sys, "frozen", True, create=True), \
                unittest.mock.patch.dict(os.environ, {"APPDATA": d}):
            path = database.app_data_dir()
        self.assertEqual(path, os.path.join(d, "SkiSense"))
