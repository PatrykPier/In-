# -*- mode: python ; coding: utf-8 -*-
# Specyfikacja PyInstaller dla SkiSense (tryb "onedir": folder z SkiSense.exe).
#   pyinstaller --noconfirm skisense.spec
import sys
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

hidden = ["matplotlib.backends.backend_qt5agg"]
hidden += collect_submodules("bleak")             # backendy BLE ładowane dynamicznie (Windows: WinRT)
try:
    hidden += collect_submodules("winrt")         # bleak >= 1.0 na Windows
except Exception:
    pass

datas = [("sample_data", "sample_data")]
datas += collect_data_files("pyqtgraph")

a = Analysis(
    ["main.py"],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hidden,
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter", "PyQt6", "PySide2", "PySide6", "IPython", "notebook", "pytest",
              "scipy", "pandas", "PyQt5.QtWebEngineCore", "PyQt5.QtWebEngineWidgets", "PyQt5.QtQml", "PyQt5.QtQuick"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="SkiSense",
    console=False,                                 # bez okna konsoli
    icon="assets/skisense.ico" if sys.platform == "win32" else None,
    upx=False,                                     # UPX zwiększa liczbę fałszywych alarmów antywirusa
)
coll = COLLECT(exe, a.binaries, a.datas, name="SkiSense", upx=False)
